const mongoose = require('mongoose');
require('dotenv').config();

// Import models
const CrewMember = require('../models/CrewMember');
const Driver = require('../models/Driver');
const Booking = require('../models/Booking');

async function setupMongoDB() {
  try {
    console.log('🚀 Setting up MongoDB for Crew Cab...');
    
    // Check if MONGODB_URI is provided
    if (!process.env.MONGODB_URI || process.env.MONGODB_URI.includes('username:password')) {
      console.log('\n❌ MongoDB URI not configured properly.');
      console.log('\n📋 To set up MongoDB:');
      console.log('1. Create a MongoDB Atlas account at https://cloud.mongodb.com/');
      console.log('2. Create a new cluster (free tier available)');
      console.log('3. Create a database user');
      console.log('4. Get your connection string');
      console.log('5. Replace the MONGODB_URI in your .env file');
      console.log('\nExample connection string:');
      console.log('mongodb+srv://username:password@cluster.mongodb.net/crew-cab?retryWrites=true&w=majority');
      console.log('\n🔧 Or provide your MongoDB details and I\'ll help you connect!');
      return;
    }

    console.log('🔄 Connecting to MongoDB Atlas...');
    console.log('📍 Using connection string:', process.env.MONGODB_URI.replace(/\/\/([^:]+):([^@]+)@/, '//***:***@'));
    
    // Close any existing connections first
    if (mongoose.connection.readyState !== 0) {
      await mongoose.disconnect();
    }
    
    // Connect to MongoDB
    await mongoose.connect(process.env.MONGODB_URI, {
      serverSelectionTimeoutMS: 10000,
      socketTimeoutMS: 45000,
      connectTimeoutMS: 10000,
      bufferCommands: false,
      maxPoolSize: 5,
      minPoolSize: 1,
      maxIdleTimeMS: 30000,
      retryWrites: true
    });
    
    console.log('✅ Connected to MongoDB');

    // Create indexes for better performance
    await createIndexes();
    
    // Create sample data for testing
    await createSampleData();
    
    console.log('✅ MongoDB setup complete!');
    console.log('\n📱 Your system is ready for testing!');
    console.log('WhatsApp Number: +44 7520 643511');
    console.log('Test commands:');
    console.log('• "crew signup" - Register as crew member');
    console.log('• "join driver" - Apply as driver');
    console.log('• "Pickup from Marina at 3:30AM" - Book a ride');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ MongoDB setup failed:', error.message);
    
    if (error.message.includes('authentication failed')) {
      console.log('\n🔧 Authentication Error:');
      console.log('• Check your username and password in the connection string');
      console.log('• Make sure the database user has read/write permissions');
      console.log('• Verify the database name matches your cluster');
    } else if (error.message.includes('ENOTFOUND')) {
      console.log('\n🔧 Connection Error:');
      console.log('• Check your internet connection');
      console.log('• Verify the cluster hostname in your connection string');
      console.log('• Try using a different DNS server (8.8.8.8)');
    } else if (error.message.includes('IP') || error.message.includes('whitelist')) {
      console.log('\n🔧 IP Whitelist Error:');
      console.log('• Go to https://cloud.mongodb.com/ → Network Access');
      console.log('• Ensure 0.0.0.0/0 is in the IP whitelist');
      console.log('• Wait 5-10 minutes for changes to propagate');
      console.log('• Restart this script after waiting');
      console.log('\n⏳ If you just added the IP, please wait and try again...');
    } else if (error.message.includes('Could not connect to any servers')) {
      console.log('\n🔧 Server Connection Error:');
      console.log('• This usually means IP whitelist changes are still propagating');
      console.log('• Wait 5-10 minutes and try again');
      console.log('• Verify your internet connection is stable');
      console.log('• Check if your firewall blocks outbound port 27017');
    }
    
    console.log('\n💡 If the issue persists:');
    console.log('• Try connecting from a different network');
    console.log('• Contact MongoDB Atlas support');
    console.log('• Provide your MongoDB details for further assistance');
    process.exit(1);
  }
}

async function createIndexes() {
  console.log('📊 Creating database indexes...');
  
  try {
    // CrewMember indexes
    await CrewMember.collection.createIndex({ phoneNumber: 1 }, { unique: true });
    await CrewMember.collection.createIndex({ crewId: 1 }, { unique: true });
    await CrewMember.collection.createIndex({ isActive: 1 });
    
    // Driver indexes
    await Driver.collection.createIndex({ phoneNumber: 1 }, { unique: true });
    await Driver.collection.createIndex({ approvalStatus: 1 });
    await Driver.collection.createIndex({ status: 1 });
    await Driver.collection.createIndex({ preferredAreas: 1 });
    
    // Booking indexes
    await Booking.collection.createIndex({ bookingId: 1 }, { unique: true });
    await Booking.collection.createIndex({ crewMember: 1 });
    await Booking.collection.createIndex({ driver: 1 });
    await Booking.collection.createIndex({ status: 1 });
    await Booking.collection.createIndex({ scheduledPickupTime: 1 });
    await Booking.collection.createIndex({ paymentStatus: 1 });
    
    console.log('✅ Indexes created successfully');
  } catch (error) {
    console.log('⚠️ Some indexes may already exist:', error.message);
  }
}

async function createSampleData() {
  console.log('📝 Creating sample data for testing...');
  
  try {
    // Sample crew member
    const existingCrew = await CrewMember.findOne({ phoneNumber: '+971501234567' });
    if (!existingCrew) {
      const sampleCrew = new CrewMember({
        phoneNumber: '+971501234567',
        name: 'Sarah Ahmed',
        crewId: 'EK12345',
        airline: 'Emirates',
        homeAddress: 'Dubai Marina, Dubai, UAE',
        homeCoordinates: { lat: 25.0657, lng: 55.1713 },
        preferredPickupArea: 'marina',
        prepaidBalance: 0,
        preferences: {
          reminderTime: 60,
          allowPooling: true,
          preferredPaymentMethod: 'per_ride',
          acPreference: 'on',
          musicPreference: 'off',
          smallTalkPreference: 'no'
        }
      });
      
      await sampleCrew.save();
      console.log('✅ Sample crew member created: Sarah Ahmed (EK12345)');
    } else {
      console.log('✅ Sample crew member already exists');
    }
    
    // Sample driver
    const existingDriver = await Driver.findOne({ phoneNumber: '+971509876543' });
    if (!existingDriver) {
      const sampleDriver = new Driver({
        phoneNumber: '+971509876543',
        name: 'Ahmed Hassan',
        email: 'ahmed.hassan@email.com',
        licenseNumber: 'DL123456789',
        carModel: 'Toyota Camry 2022',
        plateNumber: 'A12345',
        carColor: 'White',
        rating: 4.8,
        status: 'active',
        approvalStatus: 'approved',
        preferredAreas: ['marina', 'downtown', 'business bay'],
        currentLocation: {
          lat: 25.0657,
          lng: 55.1713,
          lastUpdated: new Date()
        },
        bankDetails: {
          accountNumber: '1234567890',
          bankName: 'Emirates NBD',
          accountHolderName: 'Ahmed Hassan'
        },
        documents: {
          license: { verified: true, verifiedAt: new Date() },
          car: { verified: true, verifiedAt: new Date() }
        },
        onboardingStep: 3,
        reliabilityMetrics: {
          lateIncidents: 0,
          onTimePercentage: 100,
          punctualityScore: 100
        }
      });
      
      await sampleDriver.save();
      console.log('✅ Sample driver created: Ahmed Hassan (A12345)');
    } else {
      console.log('✅ Sample driver already exists');
    }
    
    console.log('✅ Sample data setup complete');
  } catch (error) {
    console.log('⚠️ Sample data creation error:', error.message);
  }
}

// Run setup
setupMongoDB();