const express = require('express');
const router = express.Router();

// Enhanced admin dashboard with AI insights
// Mock admin dashboard data
const getMockDashboardData = () => {
  return {
    overview: {
      totalBookings: 1247,
      totalCrewMembers: 89,
      totalDrivers: 23,
      activeDrivers: 18,
      todayBookings: 34,
      revenue: 15680,
      completionRate: 94,
      aiAccuracy: 94,
      rosterProcessed: 156,
      locationVerifications: 234
    },
    recentBookings: [
      {
        id: 'RIDE123456',
        crewName: 'Sarah Ahmed',
        driverName: 'Ahmed Hassan',
        route: 'Marina → DXB Airport',
        status: 'completed',
        price: 60,
        time: '2024-01-15T03:30:00Z'
      },
      {
        id: 'RIDE123457',
        crewName: 'Maria Santos',
        driverName: 'Mohammed Ali',
        route: 'Downtown → DXB Airport',
        status: 'in_progress',
        price: 52,
        time: '2024-01-15T05:15:00Z'
      }
    ],
    popularRoutes: [
      { route: 'Marina → DXB Airport', count: 156, avgPrice: 60 },
      { route: 'Downtown → DXB Airport', count: 134, avgPrice: 52 },
      { route: 'Deira → DXB Airport', count: 98, avgPrice: 36 },
      { route: 'Jumeirah → DXB Airport', count: 87, avgPrice: 68 }
    ],
    hourlyBookings: [
      { hour: '00:00', bookings: 5 },
      { hour: '01:00', bookings: 8 },
      { hour: '02:00', bookings: 12 },
      { hour: '03:00', bookings: 23 },
      { hour: '04:00', bookings: 31 },
      { hour: '05:00', bookings: 28 },
      { hour: '06:00', bookings: 19 }
    ]
  };
};

// AI Insights endpoint
router.get('/ai-insights', (req, res) => {
  try {
    const insights = [
      {
        type: 'success',
        message: 'Successfully processed roster upload for Sarah Ahmed - 8 flights extracted',
        timestamp: '2 minutes ago',
        confidence: 0.98
      },
      {
        type: 'success',
        message: 'Intent recognition: "Pickup from Marina at 3:30AM" → Booking created',
        timestamp: '5 minutes ago',
        confidence: 0.95
      },
      {
        type: 'warning',
        message: 'Location "JLT Tower 5" not recognized - added to learning queue',
        timestamp: '8 minutes ago',
        confidence: 0.67
      },
      {
        type: 'success',
        message: 'Context memory: User referenced "same place" → Marina location confirmed',
        timestamp: '12 minutes ago',
        confidence: 0.92
      },
      {
        type: 'error',
        message: 'Failed to extract time from message "pick me up tomorrow" - asked for clarification',
        timestamp: '15 minutes ago',
        confidence: 0.45
      }
    ];
    
    res.json({ insights });
  } catch (error) {
    console.error('Error fetching AI insights:', error);
    res.status(500).json({ error: 'Failed to fetch AI insights' });
  }
});

// Conversations endpoint
router.get('/conversations', (req, res) => {
  try {
    const conversations = [
      {
        id: 'conv_001',
        phoneNumber: '+971501234567',
        userType: 'crew',
        messages: [
          {
            sender: 'user',
            message: 'I have a flight tomorrow, can you pick me up at 06:10?',
            timestamp: '10:30 AM',
            intent: 'booking_request',
            confidence: 0.95
          },
          {
            sender: 'bot',
            message: '✈️ Got it! Flight 06:10 AM tomorrow. Where should we pick you up from?',
            timestamp: '10:30 AM'
          },
          {
            sender: 'user',
            message: 'Marina',
            timestamp: '10:31 AM',
            intent: 'location_provided',
            confidence: 0.92
          },
          {
            sender: 'bot',
            message: '✅ Perfect! Booking confirmed for 06:10 AM pickup from Dubai Marina to Emirates HQ. AED 60.',
            timestamp: '10:31 AM'
          }
        ],
        status: 'completed',
        bookingCreated: true
      },
      {
        id: 'conv_002',
        phoneNumber: '+971509876543',
        userType: 'driver',
        messages: [
          {
            sender: 'user',
            message: 'CrewCab#pickup#RIDE123456',
            timestamp: '11:15 AM',
            intent: 'pickup_confirmation',
            confidence: 0.99
          },
          {
            sender: 'bot',
            message: '✅ Pickup confirmed for ride RIDE123456. Don\'t forget to confirm dropoff when complete.',
            timestamp: '11:15 AM'
          }
        ],
        status: 'active',
        bookingCreated: false
      }
    ];
    
    res.json({ conversations });
  } catch (error) {
    console.error('Error fetching conversations:', error);
    res.status(500).json({ error: 'Failed to fetch conversations' });
  }
});

// Roster AI analytics
router.get('/roster-analytics', (req, res) => {
  try {
    const analytics = {
      totalProcessed: 156,
      ocrAccuracy: 98,
      flightsExtracted: 1247,
      avgProcessingTime: 2.3,
      recentUploads: [
        {
          crew: 'Sarah Ahmed',
          flights: 8,
          accuracy: 98,
          status: 'completed',
          timestamp: '2024-01-15T10:30:00Z'
        },
        {
          crew: 'Maria Santos',
          flights: 6,
          accuracy: 95,
          status: 'completed',
          timestamp: '2024-01-15T09:45:00Z'
        }
      ]
    };
    
    res.json(analytics);
  } catch (error) {
    console.error('Error fetching roster analytics:', error);
    res.status(500).json({ error: 'Failed to fetch roster analytics' });
  }
});

// Location AI analytics
router.get('/location-analytics', (req, res) => {
  try {
    const analytics = {
      recognitionRate: 89,
      checkpointsVerified: 234,
      newLocationsLearned: 12,
      popularLocations: [
        { location: 'Dubai Marina', count: 156, accuracy: 95 },
        { location: 'Downtown Dubai', count: 134, accuracy: 92 },
        { location: 'Emirates HQ', count: 98, accuracy: 99 },
        { location: 'Jumeirah Lakes Towers', count: 87, accuracy: 88 }
      ]
    };
    
    res.json(analytics);
  } catch (error) {
    console.error('Error fetching location analytics:', error);
    res.status(500).json({ error: 'Failed to fetch location analytics' });
  }
});

// Dashboard overview
router.get('/dashboard', (req, res) => {
  try {
    const dashboardData = getMockDashboardData();
    
    console.log('📊 Admin dashboard data requested');
    
    res.json(dashboardData);
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    res.status(500).json({ error: 'Failed to fetch dashboard data' });
  }
});

// Analytics endpoints
router.get('/analytics/bookings', (req, res) => {
  try {
    const { period = '7' } = req.query;
    
    // Mock booking analytics
    const analytics = {
      period: parseInt(period),
      totalBookings: 1247,
      completedBookings: 1173,
      cancelledBookings: 74,
      revenue: 15680,
      averageRideValue: 58.5,
      completionRate: 94.1,
      dailyBreakdown: [
        { date: '2024-01-09', bookings: 45, revenue: 2340 },
        { date: '2024-01-10', bookings: 52, revenue: 2704 },
        { date: '2024-01-11', bookings: 38, revenue: 1976 },
        { date: '2024-01-12', bookings: 61, revenue: 3172 },
        { date: '2024-01-13', bookings: 47, revenue: 2444 },
        { date: '2024-01-14', bookings: 55, revenue: 2860 },
        { date: '2024-01-15', bookings: 34, revenue: 1768 }
      ]
    };
    
    res.json(analytics);
  } catch (error) {
    console.error('Error fetching booking analytics:', error);
    res.status(500).json({ error: 'Failed to fetch booking analytics' });
  }
});

router.get('/analytics/drivers', (req, res) => {
  try {
    const driverAnalytics = [
      {
        id: 'DRV001',
        name: 'Ahmed Hassan',
        totalRides: 156,
        completionRate: 98.7,
        rating: 4.8,
        earnings: 7800,
        status: 'active'
      },
      {
        id: 'DRV002',
        name: 'Mohammed Ali',
        totalRides: 203,
        completionRate: 96.5,
        rating: 4.9,
        earnings: 10150,
        status: 'active'
      }
    ];
    
    res.json(driverAnalytics);
  } catch (error) {
    console.error('Error fetching driver analytics:', error);
    res.status(500).json({ error: 'Failed to fetch driver analytics' });
  }
});

router.get('/analytics/crew', (req, res) => {
  try {
    const crewAnalytics = [
      {
        id: 'CREW001',
        name: 'Sarah Ahmed',
        airline: 'Emirates',
        totalBookings: 23,
        totalSpent: 1380,
        averageRideValue: 60,
        registeredAt: '2024-01-10T00:00:00Z'
      },
      {
        id: 'CREW002',
        name: 'Maria Santos',
        airline: 'Etihad',
        totalBookings: 15,
        totalSpent: 780,
        averageRideValue: 52,
        registeredAt: '2024-01-12T00:00:00Z'
      }
    ];
    
    res.json(crewAnalytics);
  } catch (error) {
    console.error('Error fetching crew analytics:', error);
    res.status(500).json({ error: 'Failed to fetch crew analytics' });
  }
});

// System health check
router.get('/health', (req, res) => {
  try {
    const health = {
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        whatsapp: 'operational',
        payments: 'operational',
        database: 'operational',
        automation: 'operational'
      },
      metrics: {
        uptime: '99.9%',
        responseTime: '120ms',
        errorRate: '0.1%'
      },
      alerts: []
    };
    
    res.json(health);
  } catch (error) {
    console.error('Error fetching system health:', error);
    res.status(500).json({ error: 'Failed to fetch system health' });
  }
});

// Test endpoint
router.post('/test', (req, res) => {
  console.log('🧪 Admin test endpoint called:', req.body);
  res.json({ 
    success: true, 
    message: 'Admin service is working!',
    timestamp: new Date().toISOString()
  });
});

module.exports = router;