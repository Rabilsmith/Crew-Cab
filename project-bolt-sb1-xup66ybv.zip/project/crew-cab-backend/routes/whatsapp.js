const express = require('express');
const router = express.Router();
const whatsappService = require('../services/whatsappService');
const aiChatbotService = require('../services/aiChatbotService');

// Main WhatsApp webhook endpoint
router.post('/webhook', async (req, res) => {
  try {
    await whatsappService.handleWebhook(req, res);
  } catch (error) {
    console.error('❌ WhatsApp webhook error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// Webhook verification for Meta API
router.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  
  if (mode === 'subscribe' && token === process.env.META_WEBHOOK_VERIFY_TOKEN) {
    console.log('✅ Webhook verified');
    res.status(200).send(challenge);
  } else {
    res.status(403).send('Forbidden');
  }
});

// Test WhatsApp connection
router.get('/test-connection', async (req, res) => {
  try {
    const result = await whatsappService.testConnection();
    res.json(result);
  } catch (error) {
    console.error('Connection test error:', error);
    res.status(500).json({ error: 'Connection test failed' });
  }
});

// Send test message
router.post('/test-message', async (req, res) => {
  try {
    const { phoneNumber, message } = req.body;
    
    if (!phoneNumber || !message) {
      return res.status(400).json({ 
        error: 'phoneNumber and message are required' 
      });
    }
    
    const result = await whatsappService.sendMessage(phoneNumber, message);
    res.json({ success: true, result });
  } catch (error) {
    console.error('Test message error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Test AI chatbot directly
router.post('/test-ai', async (req, res) => {
  try {
    const { phoneNumber, message } = req.body;
    
    if (!phoneNumber || !message) {
      return res.status(400).json({ 
        error: 'phoneNumber and message are required' 
      });
    }
    
    const response = await aiChatbotService.processMessage(phoneNumber, message);
    
    res.json({
      success: true,
      input: { phoneNumber, message },
      response,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('AI test error:', error);
    res.status(500).json({ error: 'AI processing failed' });
  }
});

// Get conversation context for debugging
router.get('/context/:phoneNumber', (req, res) => {
  try {
    const { phoneNumber } = req.params;
    const context = aiChatbotService.getUserContext(phoneNumber);
    
    res.json({
      phoneNumber,
      context: {
        userType: context.userType,
        currentBooking: context.currentBooking,
        waitingFor: context.waitingFor,
        messageCount: context.messageHistory.length,
        lastMessage: context.messageHistory[context.messageHistory.length - 1],
        preferences: context.preferences
      }
    });
  } catch (error) {
    console.error('Error getting context:', error);
    res.status(500).json({ error: 'Failed to get context' });
  }
});

// Clear conversation context
router.delete('/context/:phoneNumber', (req, res) => {
  try {
    const { phoneNumber } = req.params;
    aiChatbotService.userContexts.delete(phoneNumber);
    
    res.json({
      success: true,
      message: `Context cleared for ${phoneNumber}`
    });
  } catch (error) {
    console.error('Error clearing context:', error);
    res.status(500).json({ error: 'Failed to clear context' });
  }
});

// Simulate conversation for testing
router.post('/simulate', async (req, res) => {
  try {
    const { phoneNumber, conversation } = req.body;
    
    if (!phoneNumber || !Array.isArray(conversation)) {
      return res.status(400).json({ 
        error: 'phoneNumber and conversation array are required' 
      });
    }
    
    const results = [];
    
    for (const message of conversation) {
      const response = await aiChatbotService.processMessage(phoneNumber, message);
      results.push({
        input: message,
        output: response,
        timestamp: new Date().toISOString()
      });
      
      // Small delay to simulate real conversation
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    res.json({
      success: true,
      phoneNumber,
      conversation: results,
      finalContext: aiChatbotService.getUserContext(phoneNumber)
    });
  } catch (error) {
    console.error('Simulation error:', error);
    res.status(500).json({ error: 'Simulation failed' });
  }
});

module.exports = router;