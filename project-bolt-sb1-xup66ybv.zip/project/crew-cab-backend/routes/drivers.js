const express = require('express');
const router = express.Router();

// Mock drivers data
let mockDrivers = [
  {
    id: 'DRV001',
    name: 'Ahmed Hassan',
    phone: '+971509876543',
    carModel: 'Toyota Camry 2022',
    plateNumber: 'A12345',
    rating: 4.8,
    status: 'active',
    approvalStatus: 'approved',
    totalRides: 156,
    earnings: 7800,
    joinedAt: '2024-01-01T00:00:00Z'
  },
  {
    id: 'DRV002',
    name: 'Mohammed Ali',
    phone: '+971501111111',
    carModel: 'Honda Accord 2021',
    plateNumber: 'B67890',
    rating: 4.9,
    status: 'active',
    approvalStatus: 'approved',
    totalRides: 203,
    earnings: 10150,
    joinedAt: '2024-01-05T00:00:00Z'
  }
];

// Get all drivers
router.get('/', (req, res) => {
  try {
    const { status, approvalStatus, page = 1, limit = 20 } = req.query;
    
    let filteredDrivers = mockDrivers;
    
    if (status) {
      filteredDrivers = filteredDrivers.filter(d => d.status === status);
    }
    
    if (approvalStatus) {
      filteredDrivers = filteredDrivers.filter(d => d.approvalStatus === approvalStatus);
    }
    
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + parseInt(limit);
    const paginatedDrivers = filteredDrivers.slice(startIndex, endIndex);
    
    res.json({
      drivers: paginatedDrivers,
      total: filteredDrivers.length,
      page: parseInt(page),
      totalPages: Math.ceil(filteredDrivers.length / limit)
    });
  } catch (error) {
    console.error('Error fetching drivers:', error);
    res.status(500).json({ error: 'Failed to fetch drivers' });
  }
});

// Create new driver
router.post('/', (req, res) => {
  try {
    const {
      name,
      phone,
      carModel,
      plateNumber
    } = req.body;
    
    const newDriver = {
      id: 'DRV' + Date.now().toString().slice(-6),
      name,
      phone,
      carModel,
      plateNumber,
      rating: 5.0,
      status: 'offline',
      approvalStatus: 'pending',
      totalRides: 0,
      earnings: 0,
      joinedAt: new Date().toISOString()
    };
    
    mockDrivers.push(newDriver);
    
    console.log('✅ New driver application:', newDriver);
    
    res.status(201).json(newDriver);
  } catch (error) {
    console.error('Error creating driver:', error);
    res.status(500).json({ error: 'Failed to create driver' });
  }
});

// Update driver approval status
router.patch('/:driverId/approval', (req, res) => {
  try {
    const { driverId } = req.params;
    const { approvalStatus } = req.body;
    
    const driver = mockDrivers.find(d => d.id === driverId);
    
    if (!driver) {
      return res.status(404).json({ error: 'Driver not found' });
    }
    
    driver.approvalStatus = approvalStatus;
    if (approvalStatus === 'approved') {
      driver.status = 'active';
    }
    
    console.log(`✅ Driver ${driver.name} approval status: ${approvalStatus}`);
    
    res.json(driver);
  } catch (error) {
    console.error('Error updating driver approval:', error);
    res.status(500).json({ error: 'Failed to update driver approval' });
  }
});

// Update driver status
router.patch('/:driverId/status', (req, res) => {
  try {
    const { driverId } = req.params;
    const { status } = req.body;
    
    const driver = mockDrivers.find(d => d.id === driverId);
    
    if (!driver) {
      return res.status(404).json({ error: 'Driver not found' });
    }
    
    driver.status = status;
    
    console.log(`✅ Driver ${driver.name} status: ${status}`);
    
    res.json(driver);
  } catch (error) {
    console.error('Error updating driver status:', error);
    res.status(500).json({ error: 'Failed to update driver status' });
  }
});

// Get driver by phone
router.get('/phone/:phoneNumber', (req, res) => {
  try {
    const { phoneNumber } = req.params;
    
    const driver = mockDrivers.find(d => d.phone === phoneNumber);
    
    if (!driver) {
      return res.status(404).json({ error: 'Driver not found' });
    }
    
    res.json(driver);
  } catch (error) {
    console.error('Error fetching driver:', error);
    res.status(500).json({ error: 'Failed to fetch driver' });
  }
});

// Test endpoint
router.post('/test', (req, res) => {
  console.log('🧪 Drivers test endpoint called:', req.body);
  res.json({ 
    success: true, 
    message: 'Drivers service is working!',
    totalDrivers: mockDrivers.length,
    activeDrivers: mockDrivers.filter(d => d.status === 'active').length,
    timestamp: new Date().toISOString()
  });
});

module.exports = router;