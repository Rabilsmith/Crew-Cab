const express = require('express');
const router = express.Router();

// Mock Stripe service for testing
const mockStripeService = {
  createCheckoutSession: async (bookingData) => {
    const sessionId = 'cs_mock_' + Date.now();
    return {
      id: sessionId,
      url: `https://checkout.stripe.com/pay/${sessionId}`,
      payment_status: 'unpaid'
    };
  },
  
  handleWebhook: async (payload, signature) => {
    console.log('💳 Mock Stripe webhook received');
    return {
      type: 'checkout.session.completed',
      data: {
        object: {
          id: 'cs_mock_' + Date.now(),
          payment_status: 'paid',
          metadata: {
            booking_id: 'RIDE123456',
            crew_phone: '+971501234567'
          }
        }
      }
    };
  }
};

// Stripe webhook endpoint
router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    console.log('💳 Stripe webhook received');
    
    // Mock successful payment
    const mockEvent = {
      type: 'checkout.session.completed',
      data: {
        object: {
          id: 'cs_mock_' + Date.now(),
          payment_status: 'paid',
          amount_total: 6000, // AED 60.00 in cents
          metadata: {
            booking_id: 'RIDE' + Date.now().toString().slice(-6),
            crew_phone: '+971501234567'
          }
        }
      }
    };
    
    await handlePaymentSuccess(mockEvent.data.object);
    
    res.status(200).json({ received: true });
  } catch (error) {
    console.error('❌ Stripe webhook error:', error);
    res.status(400).json({ error: 'Webhook processing failed' });
  }
});

// Handle successful payment
async function handlePaymentSuccess(session) {
  const { metadata } = session;
  const bookingId = metadata.booking_id;
  const crewPhone = metadata.crew_phone;
  
  console.log(`✅ Payment successful for booking ${bookingId}`);
  
  // Mock driver assignment
  const driverName = 'Ahmed Hassan';
  const carModel = 'Toyota Camry 2022';
  const plateNumber = 'A12345';
  const driverPhone = '+971509876543';
  
  // Send confirmation to crew member
  const crewMessage = `✅ *Payment Confirmed!*\n\nYour ride is confirmed!\n\n🚗 *Driver Details:*\nName: ${driverName}\nCar: ${carModel}\nPlate: ${plateNumber}\nPhone: ${driverPhone}\n\n📍 Driver will contact you 15 minutes before pickup.\n\nBooking ID: ${bookingId}`;
  
  console.log(`📱 [MOCK] Sending to crew ${crewPhone}: ${crewMessage}`);
  
  // Send assignment to driver
  const driverMessage = `🚗 *New Ride Assignment*\n\nBooking ID: ${bookingId}\nPassenger: Crew Member\nPickup: Marina\nTime: 3:30 AM\nDestination: Dubai Airport\n\nPayout: AED 50\n\nConfirm pickup: CrewCab#pickup#${bookingId}\n\nPassenger contact: ${crewPhone}`;
  
  console.log(`📱 [MOCK] Sending to driver ${driverPhone}: ${driverMessage}`);
}

// Create checkout session
router.post('/create-checkout-session', async (req, res) => {
  try {
    const { bookingId, amount, crewPhone } = req.body;
    
    const session = await mockStripeService.createCheckoutSession({
      bookingId,
      amount,
      crewPhone
    });
    
    res.json({ url: session.url });
  } catch (error) {
    console.error('Error creating checkout session:', error);
    res.status(500).json({ error: 'Failed to create checkout session' });
  }
});

// Test endpoint
router.post('/test', (req, res) => {
  console.log('🧪 Payments test endpoint called:', req.body);
  res.json({ 
    success: true, 
    message: 'Payment service is working!',
    timestamp: new Date().toISOString()
  });
});

module.exports = router;