const express = require('express');
const router = express.Router();

// Mock crew members data
let mockCrewMembers = [
  {
    id: 'CREW001',
    name: 'Sarah Ahmed',
    phone: '+971501234567',
    airline: 'Emirates',
    crewId: 'EK12345',
    homeAddress: 'Dubai Marina',
    totalRides: 23,
    registeredAt: '2024-01-10T00:00:00Z'
  },
  {
    id: 'CREW002',
    name: 'Maria Santos',
    phone: '+971502222222',
    airline: 'Etihad',
    crewId: 'EY67890',
    homeAddress: 'Downtown Dubai',
    totalRides: 15,
    registeredAt: '2024-01-12T00:00:00Z'
  }
];

// Get all crew members
router.get('/', (req, res) => {
  try {
    const { airline, page = 1, limit = 20 } = req.query;
    
    let filteredCrew = mockCrewMembers;
    
    if (airline) {
      filteredCrew = filteredCrew.filter(c => c.airline.toLowerCase() === airline.toLowerCase());
    }
    
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + parseInt(limit);
    const paginatedCrew = filteredCrew.slice(startIndex, endIndex);
    
    res.json({
      crewMembers: paginatedCrew,
      total: filteredCrew.length,
      page: parseInt(page),
      totalPages: Math.ceil(filteredCrew.length / limit)
    });
  } catch (error) {
    console.error('Error fetching crew members:', error);
    res.status(500).json({ error: 'Failed to fetch crew members' });
  }
});

// Create new crew member
router.post('/', (req, res) => {
  try {
    const {
      name,
      phone,
      airline = 'Emirates',
      crewId,
      homeAddress
    } = req.body;
    
    const newCrewMember = {
      id: 'CREW' + Date.now().toString().slice(-6),
      name,
      phone,
      airline,
      crewId,
      homeAddress,
      totalRides: 0,
      registeredAt: new Date().toISOString()
    };
    
    mockCrewMembers.push(newCrewMember);
    
    console.log('✅ New crew member registered:', newCrewMember);
    
    res.status(201).json(newCrewMember);
  } catch (error) {
    console.error('Error creating crew member:', error);
    res.status(500).json({ error: 'Failed to create crew member' });
  }
});

// Get crew member by phone
router.get('/phone/:phoneNumber', (req, res) => {
  try {
    const { phoneNumber } = req.params;
    
    const crewMember = mockCrewMembers.find(c => c.phone === phoneNumber);
    
    if (!crewMember) {
      return res.status(404).json({ error: 'Crew member not found' });
    }
    
    res.json(crewMember);
  } catch (error) {
    console.error('Error fetching crew member:', error);
    res.status(500).json({ error: 'Failed to fetch crew member' });
  }
});

// Update crew member
router.patch('/:crewId', (req, res) => {
  try {
    const { crewId } = req.params;
    const updates = req.body;
    
    const crewMember = mockCrewMembers.find(c => c.id === crewId);
    
    if (!crewMember) {
      return res.status(404).json({ error: 'Crew member not found' });
    }
    
    Object.assign(crewMember, updates);
    crewMember.updatedAt = new Date().toISOString();
    
    console.log(`✅ Crew member ${crewMember.name} updated`);
    
    res.json(crewMember);
  } catch (error) {
    console.error('Error updating crew member:', error);
    res.status(500).json({ error: 'Failed to update crew member' });
  }
});

// Test endpoint
router.post('/test', (req, res) => {
  console.log('🧪 Crew test endpoint called:', req.body);
  res.json({ 
    success: true, 
    message: 'Crew service is working!',
    totalCrewMembers: mockCrewMembers.length,
    airlines: [...new Set(mockCrewMembers.map(c => c.airline))],
    timestamp: new Date().toISOString()
  });
});

module.exports = router;