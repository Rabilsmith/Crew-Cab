const express = require('express');
const router = express.Router();

// Mock bookings data
let mockBookings = [
  {
    id: 'RIDE123456',
    crewPhone: '+971501234567',
    driverPhone: '+971509876543',
    pickupLocation: 'Dubai Marina',
    dropoffLocation: 'Dubai Airport Terminal 3',
    scheduledTime: '2024-01-15T03:30:00Z',
    status: 'confirmed',
    price: 60,
    createdAt: new Date().toISOString()
  }
];

// Get all bookings
router.get('/', (req, res) => {
  try {
    const { status, crewPhone, page = 1, limit = 20 } = req.query;
    
    let filteredBookings = mockBookings;
    
    if (status) {
      filteredBookings = filteredBookings.filter(b => b.status === status);
    }
    
    if (crewPhone) {
      filteredBookings = filteredBookings.filter(b => b.crewPhone === crewPhone);
    }
    
    const startIndex = (page - 1) * limit;
    const endIndex = startIndex + parseInt(limit);
    const paginatedBookings = filteredBookings.slice(startIndex, endIndex);
    
    res.json({
      bookings: paginatedBookings,
      total: filteredBookings.length,
      page: parseInt(page),
      totalPages: Math.ceil(filteredBookings.length / limit)
    });
  } catch (error) {
    console.error('Error fetching bookings:', error);
    res.status(500).json({ error: 'Failed to fetch bookings' });
  }
});

// Create new booking
router.post('/', (req, res) => {
  try {
    const {
      crewPhone,
      pickupLocation,
      dropoffLocation = 'Dubai Airport',
      scheduledTime,
      price = 60
    } = req.body;
    
    const newBooking = {
      id: 'RIDE' + Date.now().toString().slice(-6),
      crewPhone,
      pickupLocation,
      dropoffLocation,
      scheduledTime,
      price,
      status: 'pending_payment',
      createdAt: new Date().toISOString()
    };
    
    mockBookings.push(newBooking);
    
    console.log('✅ New booking created:', newBooking);
    
    res.status(201).json(newBooking);
  } catch (error) {
    console.error('Error creating booking:', error);
    res.status(500).json({ error: 'Failed to create booking' });
  }
});

// Update booking status
router.patch('/:bookingId/status', (req, res) => {
  try {
    const { bookingId } = req.params;
    const { status } = req.body;
    
    const booking = mockBookings.find(b => b.id === bookingId);
    
    if (!booking) {
      return res.status(404).json({ error: 'Booking not found' });
    }
    
    booking.status = status;
    booking.updatedAt = new Date().toISOString();
    
    console.log(`✅ Booking ${bookingId} status updated to: ${status}`);
    
    res.json(booking);
  } catch (error) {
    console.error('Error updating booking:', error);
    res.status(500).json({ error: 'Failed to update booking' });
  }
});

// Get booking by ID
router.get('/:bookingId', (req, res) => {
  try {
    const { bookingId } = req.params;
    
    const booking = mockBookings.find(b => b.id === bookingId);
    
    if (!booking) {
      return res.status(404).json({ error: 'Booking not found' });
    }
    
    res.json(booking);
  } catch (error) {
    console.error('Error fetching booking:', error);
    res.status(500).json({ error: 'Failed to fetch booking' });
  }
});

// Test endpoint
router.post('/test', (req, res) => {
  console.log('🧪 Bookings test endpoint called:', req.body);
  res.json({ 
    success: true, 
    message: 'Bookings service is working!',
    totalBookings: mockBookings.length,
    timestamp: new Date().toISOString()
  });
});

module.exports = router;