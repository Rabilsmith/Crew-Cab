const mongoose = require('mongoose');

const driverSchema = new mongoose.Schema({
  phoneNumber: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  name: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    trim: true,
    lowercase: true
  },
  licenseNumber: {
    type: String,
    required: true,
    trim: true
  },
  carModel: {
    type: String,
    required: true,
    trim: true
  },
  plateNumber: {
    type: String,
    required: true,
    trim: true,
    uppercase: true
  },
  carColor: {
    type: String,
    trim: true
  },
  profilePhoto: {
    type: String, // URL to photo
    trim: true
  },
  licensePhoto: {
    type: String, // URL to license photo
    trim: true
  },
  carPhoto: {
    type: String, // URL to car photo
    trim: true
  },
  rating: {
    type: Number,
    default: 5.0,
    min: 1,
    max: 5
  },
  totalRides: {
    type: Number,
    default: 0
  },
  completedRides: {
    type: Number,
    default: 0
  },
  cancelledRides: {
    type: Number,
    default: 0
  },
  status: {
    type: String,
    enum: ['active', 'busy', 'offline', 'suspended'],
    default: 'offline'
  },
  approvalStatus: {
    type: String,
    enum: ['pending', 'approved', 'rejected'],
    default: 'pending'
  },
  preferredAreas: [{
    type: String,
    trim: true
  }],
  currentLocation: {
    lat: Number,
    lng: Number,
    lastUpdated: {
      type: Date,
      default: Date.now
    }
  },
  pendingPayout: {
    type: Number,
    default: 0
  },
  totalEarnings: {
    type: Number,
    default: 0
  },
  bankDetails: {
    accountNumber: String,
    routingNumber: String,
    bankName: String,
    accountHolderName: String
  },
  documents: {
    license: {
      verified: { type: Boolean, default: false },
      verifiedAt: Date,
      verifiedBy: String
    },
    car: {
      verified: { type: Boolean, default: false },
      verifiedAt: Date,
      verifiedBy: String
    }
  },
  onboardingStep: {
    type: Number,
    default: 0 // 0: not started, 1: basic info, 2: documents, 3: completed
  },
  isActive: {
    type: Boolean,
    default: true
  },
  registrationDate: {
    type: Date,
    default: Date.now
  },
  lastActivity: {
    type: Date,
    default: Date.now
  },
  // Driver reliability tracking
  reliabilityMetrics: {
    lateIncidents: {
      type: Number,
      default: 0
    },
    onTimePercentage: {
      type: Number,
      default: 100
    },
    lastLateIncident: Date,
    isBlocked: {
      type: Boolean,
      default: false
    },
    blockReason: String,
    punctualityScore: {
      type: Number,
      default: 100
    }
  }
}, {
  timestamps: true
});

// Indexes
driverSchema.index({ phoneNumber: 1 });
driverSchema.index({ approvalStatus: 1 });
driverSchema.index({ status: 1 });
driverSchema.index({ preferredAreas: 1 });
driverSchema.index({ 'currentLocation.lat': 1, 'currentLocation.lng': 1 });

module.exports = mongoose.model('Driver', driverSchema);