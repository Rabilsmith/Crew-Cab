const mongoose = require('mongoose');

const crewMemberSchema = new mongoose.Schema({
  phoneNumber: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  name: {
    type: String,
    required: true,
    trim: true
  },
  crewId: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  airline: {
    type: String,
    default: 'Emirates',
    trim: true
  },
  homeAddress: {
    type: String,
    trim: true
  },
  homeCoordinates: {
    lat: Number,
    lng: Number
  },
  preferredPickupArea: {
    type: String,
    trim: true
  },
  prepaidBalance: {
    type: Number,
    default: 0
  },
  totalRides: {
    type: Number,
    default: 0
  },
  isActive: {
    type: Boolean,
    default: true
  },
  registrationDate: {
    type: Date,
    default: Date.now
  },
  lastActivity: {
    type: Date,
    default: Date.now
  },
  preferences: {
    reminderTime: {
      type: Number,
      default: 60 // minutes before pickup
    },
    allowPooling: {
      type: Boolean,
      default: true
    },
    preferredPaymentMethod: {
      type: String,
      enum: ['per_ride', 'bundle'],
      default: 'per_ride'
    },
    // Passenger preferences for ride experience
    acPreference: {
      type: String,
      enum: ['on', 'off'],
      default: 'on'
    },
    musicPreference: {
      type: String,
      enum: ['on', 'off'],
      default: 'off'
    },
    smallTalkPreference: {
      type: String,
      enum: ['yes', 'no'],
      default: 'no'
    }
  },
  stripeCustomerId: {
    type: String,
    sparse: true
  }
}, {
  timestamps: true
});

// Indexes
crewMemberSchema.index({ phoneNumber: 1 });
crewMemberSchema.index({ crewId: 1 });
crewMemberSchema.index({ isActive: 1 });

module.exports = mongoose.model('CrewMember', crewMemberSchema);