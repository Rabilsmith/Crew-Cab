const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  bookingId: {
    type: String,
    required: true,
    unique: true
  },
  crewMember: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'CrewMember',
    required: true
  },
  crewPhoneNumber: {
    type: String,
    required: true
  },
  driver: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Driver'
  },
  driverPhoneNumber: {
    type: String
  },
  pickupLocation: {
    address: {
      type: String,
      required: true
    },
    coordinates: {
      lat: Number,
      lng: Number
    },
    area: String
  },
  dropoffLocation: {
    address: {
      type: String,
      required: true
    },
    coordinates: {
      lat: Number,
      lng: Number
    },
    area: String
  },
  scheduledPickupTime: {
    type: Date,
    required: true
  },
  actualPickupTime: {
    type: Date
  },
  actualDropoffTime: {
    type: Date
  },
  rideType: {
    type: String,
    enum: ['to_hq', 'from_hq'],
    required: true
  },
  pricing: {
    careemPrice: Number,
    crewCabPrice: {
      type: Number,
      required: true
    },
    platformFee: {
      type: Number,
      default: 10
    },
    driverPayout: Number,
    currency: {
      type: String,
      default: 'AED'
    }
  },
  status: {
    type: String,
    enum: [
      'pending_payment',
      'payment_failed', 
      'confirmed',
      'driver_assigned',
      'driver_en_route',
      'picked_up',
      'in_progress',
      'completed',
      'cancelled',
      'no_show'
    ],
    default: 'pending_payment'
  },
  paymentStatus: {
    type: String,
    enum: ['pending', 'paid', 'failed', 'refunded'],
    default: 'pending'
  },
  paymentIntentId: {
    type: String
  },
  isFromRoster: {
    type: Boolean,
    default: false
  },
  isPooled: {
    type: Boolean,
    default: false
  },
  pooledWith: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Booking'
  }],
  flightNumber: {
    type: String,
    trim: true
  },
  specialInstructions: {
    type: String,
    trim: true
  },
  rating: {
    score: {
      type: Number,
      min: 1,
      max: 5
    },
    comment: String,
    ratedAt: Date
  },
  timeline: [{
    status: String,
    timestamp: {
      type: Date,
      default: Date.now
    },
    note: String
  }],
  distance: {
    type: Number // in kilometers
  },
  estimatedDuration: {
    type: Number // in minutes
  },
  actualDuration: {
    type: Number // in minutes
  },
  cancellationReason: {
    type: String,
    trim: true
  },
  cancelledBy: {
    type: String,
    enum: ['crew', 'driver', 'admin']
  },
  cancelledAt: {
    type: Date
  },
  // Passenger preferences for this ride
  passengerPreferences: {
    acPreference: {
      type: String,
      enum: ['on', 'off'],
      default: 'on'
    },
    musicPreference: {
      type: String,
      enum: ['on', 'off'],
      default: 'off'
    },
    smallTalkPreference: {
      type: String,
      enum: ['yes', 'no'],
      default: 'no'
    }
  },
  // Reliability tracking
  driverLateness: {
    type: Number, // minutes late (0 = on time)
    default: 0
  },
  punctualityRating: {
    type: Number, // 1-5 stars for punctuality
    min: 1,
    max: 5
  }
}, {
  timestamps: true,
  bufferTimeoutMS: 60000
});

// Indexes
bookingSchema.index({ bookingId: 1 });
bookingSchema.index({ crewMember: 1 });
bookingSchema.index({ driver: 1 });
bookingSchema.index({ status: 1 });
bookingSchema.index({ scheduledPickupTime: 1 });
bookingSchema.index({ paymentStatus: 1 });
bookingSchema.index({ isPooled: 1 });

// Pre-save middleware to generate booking ID
bookingSchema.pre('save', function(next) {
  if (!this.bookingId) {
    this.bookingId = 'RIDE' + Date.now().toString().slice(-6);
  }
  next();
});

module.exports = mongoose.model('Booking', bookingSchema);