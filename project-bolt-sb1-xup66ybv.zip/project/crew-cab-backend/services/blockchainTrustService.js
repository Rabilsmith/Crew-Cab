// Blockchain-based Trust & Reputation System

class BlockchainTrustService {
  constructor() {
    this.trustChain = new Map(); // Simplified blockchain simulation
    this.reputationScores = new Map();
    this.verificationRecords = new Map();
    this.trustMetrics = new Map();
  }

  /**
   * Create immutable trust record for completed rides
   */
  async createTrustRecord(rideData) {
    try {
      const trustRecord = {
        id: this.generateTrustId(),
        timestamp: new Date(),
        rideId: rideData.rideId,
        crewPhone: rideData.crewPhone,
        driverPhone: rideData.driverPhone,
        trustMetrics: {
          punctuality: rideData.punctuality,
          professionalism: rideData.professionalism,
          vehicleCondition: rideData.vehicleCondition,
          communication: rideData.communication,
          safety: rideData.safety
        },
        verificationHash: this.generateVerificationHash(rideData),
        previousHash: this.getLastHash(),
        blockNumber: this.getNextBlockNumber()
      };

      // Add to blockchain
      this.addToTrustChain(trustRecord);
      
      // Update reputation scores
      await this.updateReputationScores(trustRecord);
      
      return {
        success: true,
        trustRecordId: trustRecord.id,
        blockNumber: trustRecord.blockNumber,
        verificationHash: trustRecord.verificationHash
      };
    } catch (error) {
      console.error('Trust record creation error:', error);
      throw error;
    }
  }

  /**
   * Verify driver credentials and create verification record
   */
  async verifyDriverCredentials(driverPhone, credentials) {
    try {
      const verificationRecord = {
        id: this.generateVerificationId(),
        timestamp: new Date(),
        driverPhone,
        credentials: {
          license: await this.verifyLicense(credentials.license),
          vehicle: await this.verifyVehicle(credentials.vehicle),
          insurance: await this.verifyInsurance(credentials.insurance),
          background: await this.verifyBackground(credentials.background)
        },
        verificationLevel: 'pending',
        verifiedBy: 'system',
        expiryDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000) // 1 year
      };

      // Calculate verification level
      verificationRecord.verificationLevel = this.calculateVerificationLevel(verificationRecord.credentials);
      
      // Store verification
      this.verificationRecords.set(driverPhone, verificationRecord);
      
      // Create blockchain record
      await this.createVerificationBlockchainRecord(verificationRecord);
      
      return {
        success: true,
        verificationLevel: verificationRecord.verificationLevel,
        verificationId: verificationRecord.id,
        expiryDate: verificationRecord.expiryDate,
        trustScore: this.calculateInitialTrustScore(verificationRecord)
      };
    } catch (error) {
      console.error('Driver verification error:', error);
      throw error;
    }
  }

  /**
   * Calculate dynamic trust score based on multiple factors
   */
  async calculateTrustScore(userPhone, userType) {
    try {
      const trustHistory = this.getTrustHistory(userPhone);
      const verificationRecord = this.verificationRecords.get(userPhone);
      const recentPerformance = await this.getRecentPerformance(userPhone);
      
      let trustScore = 50; // Base score
      
      // Verification bonus
      if (verificationRecord) {
        switch (verificationRecord.verificationLevel) {
          case 'gold': trustScore += 30; break;
          case 'silver': trustScore += 20; break;
          case 'bronze': trustScore += 10; break;
        }
      }
      
      // Performance history
      if (trustHistory.length > 0) {
        const avgRating = trustHistory.reduce((sum, record) => {
          const metrics = record.trustMetrics;
          return sum + (metrics.punctuality + metrics.professionalism + metrics.vehicleCondition + metrics.communication + metrics.safety) / 5;
        }, 0) / trustHistory.length;
        
        trustScore += (avgRating - 3) * 10; // Scale 1-5 rating to trust score
      }
      
      // Recent performance impact
      if (recentPerformance.incidents > 0) {
        trustScore -= recentPerformance.incidents * 5;
      }
      
      // Consistency bonus
      if (trustHistory.length > 10 && this.calculateConsistency(trustHistory) > 0.8) {
        trustScore += 15;
      }
      
      // Cap between 0-100
      trustScore = Math.max(0, Math.min(100, trustScore));
      
      // Store updated score
      this.reputationScores.set(userPhone, {
        score: trustScore,
        lastUpdated: new Date(),
        factors: {
          verification: verificationRecord?.verificationLevel || 'none',
          historyCount: trustHistory.length,
          avgRating: trustHistory.length > 0 ? this.calculateAverageRating(trustHistory) : 0,
          recentIncidents: recentPerformance.incidents
        }
      });
      
      return {
        trustScore,
        trustLevel: this.getTrustLevel(trustScore),
        factors: this.reputationScores.get(userPhone).factors,
        recommendations: this.generateTrustRecommendations(trustScore, userType)
      };
    } catch (error) {
      console.error('Trust score calculation error:', error);
      throw error;
    }
  }

  /**
   * Smart matching based on trust compatibility
   */
  async findTrustCompatibleMatches(crewPhone, availableDrivers) {
    try {
      const crewTrustProfile = await this.getCrewTrustProfile(crewPhone);
      const compatibilityScores = [];
      
      for (const driver of availableDrivers) {
        const driverTrustProfile = await this.getDriverTrustProfile(driver.phone);
        const compatibilityScore = this.calculateTrustCompatibility(crewTrustProfile, driverTrustProfile);
        
        compatibilityScores.push({
          driverPhone: driver.phone,
          driverName: driver.name,
          compatibilityScore,
          trustLevel: driverTrustProfile.trustLevel,
          verificationLevel: driverTrustProfile.verificationLevel,
          matchReasons: this.getMatchReasons(crewTrustProfile, driverTrustProfile)
        });
      }
      
      // Sort by compatibility score
      compatibilityScores.sort((a, b) => b.compatibilityScore - a.compatibilityScore);
      
      return {
        matches: compatibilityScores,
        recommendedMatch: compatibilityScores[0],
        trustAnalysis: {
          crewTrustLevel: crewTrustProfile.trustLevel,
          avgDriverTrustLevel: this.calculateAverageDriverTrust(compatibilityScores),
          matchConfidence: compatibilityScores[0]?.compatibilityScore || 0
        }
      };
    } catch (error) {
      console.error('Trust matching error:', error);
      throw error;
    }
  }

  /**
   * Fraud detection using trust patterns
   */
  async detectFraudulentActivity(userPhone, activityData) {
    try {
      const trustHistory = this.getTrustHistory(userPhone);
      const behaviorPattern = this.analyzeBehaviorPattern(trustHistory, activityData);
      
      const fraudIndicators = [];
      
      // Check for unusual patterns
      if (behaviorPattern.ratingVariance > 2.0) {
        fraudIndicators.push('Inconsistent rating patterns');
      }
      
      if (behaviorPattern.frequencyAnomaly > 0.8) {
        fraudIndicators.push('Unusual activity frequency');
      }
      
      if (behaviorPattern.locationAnomaly > 0.7) {
        fraudIndicators.push('Suspicious location patterns');
      }
      
      const fraudRisk = this.calculateFraudRisk(fraudIndicators, behaviorPattern);
      
      return {
        fraudRisk,
        riskLevel: this.getFraudRiskLevel(fraudRisk),
        indicators: fraudIndicators,
        recommendations: this.generateFraudRecommendations(fraudRisk),
        confidence: 0.87
      };
    } catch (error) {
      console.error('Fraud detection error:', error);
      throw error;
    }
  }

  // Helper methods
  generateTrustId() {
    return 'TRUST_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  generateVerificationHash(data) {
    // Simplified hash - in production, use proper cryptographic hash
    return 'HASH_' + btoa(JSON.stringify(data)).substr(0, 16);
  }

  getLastHash() {
    const chainArray = Array.from(this.trustChain.values());
    return chainArray.length > 0 ? chainArray[chainArray.length - 1].verificationHash : '0';
  }

  getNextBlockNumber() {
    return this.trustChain.size + 1;
  }

  addToTrustChain(record) {
    this.trustChain.set(record.id, record);
  }

  async verifyLicense(licenseData) {
    // Mock verification - in production, integrate with government APIs
    return {
      valid: true,
      expiryDate: '2025-12-31',
      verificationScore: 0.95
    };
  }

  async verifyVehicle(vehicleData) {
    return {
      valid: true,
      registrationValid: true,
      verificationScore: 0.92
    };
  }

  async verifyInsurance(insuranceData) {
    return {
      valid: true,
      coverage: 'comprehensive',
      verificationScore: 0.88
    };
  }

  async verifyBackground(backgroundData) {
    return {
      clear: true,
      verificationScore: 0.90
    };
  }

  calculateVerificationLevel(credentials) {
    const scores = Object.values(credentials).map(c => c.verificationScore || 0);
    const avgScore = scores.reduce((sum, score) => sum + score, 0) / scores.length;
    
    if (avgScore >= 0.9) return 'gold';
    if (avgScore >= 0.8) return 'silver';
    if (avgScore >= 0.7) return 'bronze';
    return 'basic';
  }

  getTrustLevel(score) {
    if (score >= 80) return 'high';
    if (score >= 60) return 'medium';
    if (score >= 40) return 'low';
    return 'very_low';
  }

  calculateTrustCompatibility(crewProfile, driverProfile) {
    // Calculate compatibility based on trust preferences and history
    let compatibility = 0.5; // Base compatibility
    
    // Trust level compatibility
    if (crewProfile.preferredTrustLevel === driverProfile.trustLevel) {
      compatibility += 0.3;
    }
    
    // Verification level compatibility
    if (driverProfile.verificationLevel === 'gold') {
      compatibility += 0.2;
    }
    
    // Historical compatibility
    if (crewProfile.previousDrivers.includes(driverProfile.phone)) {
      compatibility += 0.4; // Bonus for previous positive experience
    }
    
    return Math.min(1.0, compatibility);
  }

  getTrustHistory(userPhone) {
    return Array.from(this.trustChain.values()).filter(record => 
      record.crewPhone === userPhone || record.driverPhone === userPhone
    );
  }
}

module.exports = new BlockchainTrustService();