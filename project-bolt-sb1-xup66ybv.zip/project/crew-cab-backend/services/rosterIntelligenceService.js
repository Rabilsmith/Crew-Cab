// Advanced Roster Intelligence & Auto-Matching Service

class RosterIntelligenceService {
  constructor() {
    this.rosterPatterns = new Map(); // Learn roster patterns
    this.crewSchedules = new Map(); // Track crew schedules
    this.driverAvailability = new Map(); // Track driver availability
    this.rideSharingGroups = new Map(); // Manage ride sharing groups
  }

  /**
   * Process uploaded roster with advanced intelligence
   */
  async processRosterUpload(crewPhone, imageUrl) {
    try {
      console.log(`📋 Processing roster for ${crewPhone}`);
      
      // Step 1: Extract flight data using OCR
      const ocrProcessor = require('../components/OCRProcessor');
      const rosterAnalysis = await ocrProcessor.processRosterImage(imageUrl);
      
      if (rosterAnalysis.flights.length === 0) {
        return {
          success: false,
          message: "❌ No flights detected in the roster. Please upload a clearer image."
        };
      }

      // Step 2: Analyze patterns and create intelligent suggestions
      const intelligentSuggestions = await this.createIntelligentSuggestions(crewPhone, rosterAnalysis.flights);
      
      // Step 3: Find ride sharing opportunities
      const rideSharingOpportunities = await this.findRideSharingOpportunities(rosterAnalysis.flights);
      
      // Step 4: Suggest optimal drivers
      const driverSuggestions = await this.suggestOptimalDrivers(crewPhone, rosterAnalysis.flights);
      
      // Step 5: Calculate bundle pricing with optimizations
      const bundlePricing = await this.calculateOptimizedBundlePricing(rosterAnalysis.flights, rideSharingOpportunities);
      
      // Step 6: Create auto-booking options
      const autoBookingOptions = await this.createAutoBookingOptions(crewPhone, rosterAnalysis.flights);

      // Cache roster for future reference
      this.crewSchedules.set(crewPhone, {
        flights: rosterAnalysis.flights,
        processedAt: new Date(),
        intelligentSuggestions,
        rideSharingOpportunities,
        driverSuggestions,
        bundlePricing
      });

      return {
        success: true,
        rosterAnalysis,
        intelligentSuggestions,
        rideSharingOpportunities,
        driverSuggestions,
        bundlePricing,
        autoBookingOptions,
        message: this.generateRosterConfirmationMessage(rosterAnalysis, bundlePricing, rideSharingOpportunities)
      };
    } catch (error) {
      console.error('Roster processing error:', error);
      return {
        success: false,
        message: "❌ Error processing roster. Please try again or contact support."
      };
    }
  }

  /**
   * Create intelligent suggestions based on roster analysis
   */
  async createIntelligentSuggestions(crewPhone, flights) {
    const suggestions = [];
    const crewHistory = await this.getCrewBookingHistory(crewPhone);
    
    for (const flight of flights) {
      // Analyze historical patterns
      const historicalPattern = this.analyzeHistoricalPattern(flight, crewHistory);
      
      // Suggest pickup time optimization
      const pickupOptimization = this.optimizePickupTime(flight);
      
      // Suggest route optimization
      const routeOptimization = await this.optimizeRoute(flight);
      
      suggestions.push({
        flightDate: flight.date,
        flightTime: flight.time,
        flightNumber: flight.flightNumber,
        destination: flight.destination,
        suggestions: {
          pickupTime: pickupOptimization.suggestedTime,
          pickupTimeReason: pickupOptimization.reason,
          route: routeOptimization.suggestedRoute,
          estimatedDuration: routeOptimization.duration,
          trafficConsiderations: routeOptimization.trafficNotes,
          historicalInsight: historicalPattern.insight,
          confidenceScore: historicalPattern.confidence
        }
      });
    }
    
    return suggestions;
  }

  /**
   * Find ride sharing opportunities across multiple crew members
   */
  async findRideSharingOpportunities(flights) {
    const opportunities = [];
    
    for (const flight of flights) {
      // Find other crew with similar flight times (within 30 minutes)
      const similarFlights = await this.findSimilarFlightTimes(flight);
      
      if (similarFlights.length > 0) {
        // Group by optimal pickup time windows
        const pickupGroups = this.groupByPickupWindows(similarFlights);
        
        for (const group of pickupGroups) {
          if (group.crewMembers.length >= 2 && group.crewMembers.length <= 3) {
            opportunities.push({
              groupId: this.generateGroupId(),
              flightDate: flight.date,
              pickupTimeWindow: group.timeWindow,
              crewMembers: group.crewMembers,
              totalSavings: group.crewMembers.length * 20, // AED 20 savings per person
              suggestedPickupLocation: await this.findOptimalPickupPoint(group.crewMembers),
              estimatedDuration: group.estimatedDuration,
              driverRequirements: this.calculateDriverRequirements(group.crewMembers)
            });
          }
        }
      }
    }
    
    return opportunities;
  }

  /**
   * Suggest optimal drivers based on multiple factors
   */
  async suggestOptimalDrivers(crewPhone, flights) {
    const suggestions = [];
    const crewPreferences = await this.getCrewPreferences(crewPhone);
    const availableDrivers = await this.getAvailableDrivers();
    
    for (const flight of flights) {
      const flightDriverSuggestions = [];
      
      for (const driver of availableDrivers) {
        // Check driver availability for this flight time
        const isAvailable = await this.checkDriverAvailability(driver.phoneNumber, flight.date, flight.time);
        
        if (isAvailable) {
          // Calculate match score
          const matchScore = await this.calculateDriverMatchScore(driver, crewPreferences, flight);
          
          if (matchScore > 0.7) {
            flightDriverSuggestions.push({
              driverName: driver.name,
              driverPhone: driver.phoneNumber,
              matchScore: Math.round(matchScore * 100),
              availability: 'available',
              specialties: this.getDriverSpecialties(driver),
              estimatedArrival: this.calculateEstimatedArrival(driver, flight),
              rating: driver.rating,
              completedRides: driver.totalRides,
              matchReasons: this.getMatchReasons(driver, crewPreferences, flight)
            });
          }
        }
      }
      
      // Sort by match score and take top 3
      flightDriverSuggestions.sort((a, b) => b.matchScore - a.matchScore);
      
      suggestions.push({
        flightDate: flight.date,
        flightTime: flight.time,
        suggestedDrivers: flightDriverSuggestions.slice(0, 3)
      });
    }
    
    return suggestions;
  }

  /**
   * Calculate optimized bundle pricing with ride sharing discounts
   */
  async calculateOptimizedBundlePricing(flights, rideSharingOpportunities) {
    const basePrice = flights.length * 60; // AED 60 per ride
    let bundlePrice = Math.floor(basePrice * 0.9); // 10% bundle discount
    
    // Additional savings from ride sharing
    let rideSharingSavings = 0;
    for (const opportunity of rideSharingOpportunities) {
      rideSharingSavings += opportunity.totalSavings;
    }
    
    const finalPrice = bundlePrice - rideSharingSavings;
    const totalSavings = basePrice - finalPrice;
    
    return {
      individualRidePrice: 60,
      totalRides: flights.length,
      basePrice,
      bundleDiscount: basePrice - bundlePrice,
      rideSharingSavings,
      finalPrice: Math.max(finalPrice, flights.length * 30), // Minimum AED 30 per ride
      totalSavings,
      savingsPercentage: Math.round((totalSavings / basePrice) * 100),
      breakdown: {
        bundleDiscount: '10% off for multiple rides',
        rideSharingDiscount: `AED ${rideSharingSavings} from shared rides`,
        finalSavings: `${Math.round((totalSavings / basePrice) * 100)}% total savings`
      }
    };
  }

  /**
   * Create auto-booking options with smart defaults
   */
  async createAutoBookingOptions(crewPhone, flights) {
    const options = [];
    
    // Option 1: Book all flights individually
    options.push({
      type: 'individual',
      title: 'Book All Rides Individually',
      description: 'Each flight gets its own dedicated ride',
      totalPrice: flights.length * 60,
      advantages: ['Guaranteed individual service', 'Flexible timing', 'No waiting for others'],
      bookingAction: 'book_individual_all'
    });
    
    // Option 2: Smart bundle with ride sharing
    const rideSharingOpportunities = await this.findRideSharingOpportunities(flights);
    if (rideSharingOpportunities.length > 0) {
      const bundlePrice = await this.calculateOptimizedBundlePricing(flights, rideSharingOpportunities);
      
      options.push({
        type: 'smart_bundle',
        title: 'Smart Bundle with Ride Sharing',
        description: `Share rides when possible, save AED ${bundlePrice.totalSavings}`,
        totalPrice: bundlePrice.finalPrice,
        advantages: [
          `${bundlePrice.savingsPercentage}% total savings`,
          'Meet other crew members',
          'Environmentally friendly',
          'Automatic optimization'
        ],
        rideSharingCount: rideSharingOpportunities.length,
        bookingAction: 'book_smart_bundle'
      });
    }
    
    // Option 3: Custom selection
    options.push({
      type: 'custom',
      title: 'Let Me Choose Each Ride',
      description: 'Review and customize each booking individually',
      advantages: ['Full control', 'Custom preferences per ride', 'Flexible payment'],
      bookingAction: 'book_custom'
    });
    
    return options;
  }

  /**
   * Generate comprehensive roster confirmation message
   */
  generateRosterConfirmationMessage(rosterAnalysis, bundlePricing, rideSharingOpportunities) {
    let message = `✅ *Roster Processed Successfully!*\n\n`;
    message += `📋 **${rosterAnalysis.totalFlights} Flights Detected** (${Math.round(rosterAnalysis.confidence)}% confidence)\n\n`;
    
    // Show first few flights
    rosterAnalysis.flights.slice(0, 3).forEach((flight, index) => {
      message += `${index + 1}. **${flight.date}** - ${flight.flightNumber}\n`;
      message += `   🛫 ${flight.time} to ${flight.destination}\n`;
      message += `   🚗 Suggested pickup: ${flight.pickupTime}\n\n`;
    });
    
    if (rosterAnalysis.flights.length > 3) {
      message += `... and ${rosterAnalysis.flights.length - 3} more flights\n\n`;
    }
    
    // Pricing information
    message += `💰 **Smart Pricing Options:**\n`;
    message += `• Individual rides: AED ${bundlePricing.basePrice}\n`;
    message += `• Bundle discount: -AED ${bundlePricing.bundleDiscount}\n`;
    
    if (bundlePricing.rideSharingSavings > 0) {
      message += `• Ride sharing savings: -AED ${bundlePricing.rideSharingSavings}\n`;
      message += `• **Final price: AED ${bundlePricing.finalPrice}**\n`;
      message += `• **Total savings: AED ${bundlePricing.totalSavings} (${bundlePricing.savingsPercentage}%)**\n\n`;
    } else {
      message += `• **Bundle price: AED ${bundlePricing.finalPrice}**\n`;
      message += `• **You save: AED ${bundlePricing.bundleDiscount}**\n\n`;
    }
    
    // Ride sharing opportunities
    if (rideSharingOpportunities.length > 0) {
      message += `🤝 **Ride Sharing Opportunities:**\n`;
      message += `Found ${rideSharingOpportunities.length} opportunities to share rides with other crew members!\n\n`;
    }
    
    message += `🎯 **Choose Your Option:**\n`;
    message += `1️⃣ "Smart Bundle" - Automatic optimization with ride sharing\n`;
    message += `2️⃣ "Individual Rides" - Dedicated rides for each flight\n`;
    message += `3️⃣ "Custom" - Let me choose each ride manually\n\n`;
    message += `Reply with your choice number to proceed! 🚀`;
    
    return message;
  }

  /**
   * Auto-suggest recurring bookings based on patterns
   */
  async suggestRecurringBookings(crewPhone) {
    const crewSchedule = this.crewSchedules.get(crewPhone);
    if (!crewSchedule) return [];
    
    const patterns = this.analyzeSchedulePatterns(crewSchedule.flights);
    const suggestions = [];
    
    for (const pattern of patterns) {
      if (pattern.frequency > 0.7) { // High confidence pattern
        suggestions.push({
          type: 'recurring',
          pattern: pattern.description,
          frequency: pattern.frequency,
          suggestedBooking: {
            pickupTime: pattern.commonPickupTime,
            pickupLocation: pattern.commonPickupLocation,
            destination: pattern.commonDestination
          },
          estimatedMonthlyCost: pattern.estimatedMonthlyCost,
          potentialSavings: pattern.potentialSavings
        });
      }
    }
    
    return suggestions;
  }

  // Helper methods
  analyzeHistoricalPattern(flight, crewHistory) {
    const similarFlights = crewHistory.filter(booking => 
      this.isSimilarFlightTime(booking.flightTime, flight.time)
    );
    
    if (similarFlights.length === 0) {
      return {
        insight: 'No historical data for similar flight times',
        confidence: 0
      };
    }
    
    const avgPickupTime = this.calculateAveragePickupTime(similarFlights);
    const commonLocation = this.findMostCommonLocation(similarFlights);
    
    return {
      insight: `Based on ${similarFlights.length} similar flights, you usually book pickup at ${avgPickupTime} from ${commonLocation}`,
      confidence: Math.min(similarFlights.length / 5, 1) // Max confidence at 5+ similar flights
    };
  }

  optimizePickupTime(flight) {
    const flightTime = new Date(`${flight.date} ${flight.time}`);
    const isInternational = this.isInternationalFlight(flight.destination);
    
    // Calculate optimal pickup time
    const hoursBeforeFlight = isInternational ? 2.5 : 1.5;
    const optimalPickupTime = new Date(flightTime.getTime() - (hoursBeforeFlight * 60 * 60 * 1000));
    
    // Add buffer for traffic
    const trafficBuffer = this.calculateTrafficBuffer(optimalPickupTime);
    const suggestedTime = new Date(optimalPickupTime.getTime() - (trafficBuffer * 60 * 1000));
    
    return {
      suggestedTime: suggestedTime.toTimeString().slice(0, 5),
      reason: `${hoursBeforeFlight} hours before ${isInternational ? 'international' : 'domestic'} flight + ${trafficBuffer} min traffic buffer`
    };
  }

  async optimizeRoute(flight) {
    // Mock route optimization
    return {
      suggestedRoute: 'Sheikh Zayed Road → Emirates Road → DXB',
      duration: '25-30 minutes',
      trafficNotes: 'Avoid peak hours 7-9 AM for faster journey'
    };
  }

  generateGroupId() {
    return 'GROUP_' + Date.now().toString().slice(-6);
  }

  isInternationalFlight(destination) {
    const domesticDestinations = ['Dubai', 'Abu Dhabi', 'Sharjah'];
    return !domesticDestinations.some(dest => destination.includes(dest));
  }

  calculateTrafficBuffer(pickupTime) {
    const hour = pickupTime.getHours();
    
    // Peak hours need more buffer
    if ((hour >= 7 && hour <= 9) || (hour >= 17 && hour <= 19)) {
      return 20; // 20 minutes extra
    } else if (hour >= 3 && hour <= 6) {
      return 5; // Early morning, less traffic
    } else {
      return 10; // Normal buffer
    }
  }

  // Additional helper methods would be implemented here...
  async getCrewBookingHistory(crewPhone) {
    // Mock implementation
    return [];
  }

  async findSimilarFlightTimes(flight) {
    // Mock implementation
    return [];
  }

  async getCrewPreferences(crewPhone) {
    // Mock implementation
    return {
      genderPreference: null,
      smallTalkPreference: 'no',
      musicPreference: 'off',
      acPreference: 'on'
    };
  }

  async getAvailableDrivers() {
    // Mock implementation
    return [
      { phoneNumber: '+971509876543', name: 'Ahmed Hassan', rating: 4.8, gender: 'male' },
      { phoneNumber: '+971501111111', name: 'Mohammed Ali', rating: 4.9, gender: 'male' }
    ];
  }
}

module.exports = new RosterIntelligenceService();