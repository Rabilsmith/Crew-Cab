// WhatsApp Service - Multiple Provider Support with Enhanced Integration

class WhatsAppService {
  constructor() {
    this.provider = process.env.WHATSAPP_PROVIDER || 'meta';
    this.initializeProvider();
  }

  initializeProvider() {
    console.log(`🚀 Initializing WhatsApp provider: ${this.provider}`);
    
    switch (this.provider) {
      case 'meta':
        this.apiUrl = 'https://graph.facebook.com/v18.0';
        this.phoneNumberId = process.env.META_PHONE_NUMBER_ID;
        this.accessToken = process.env.META_ACCESS_TOKEN;
        this.verifyToken = process.env.META_WEBHOOK_VERIFY_TOKEN;
        this.headers = {
          'Authorization': `Bearer ${this.accessToken}`,
          'Content-Type': 'application/json'
        };
        break;
      
      case 'gallabox':
        this.apiUrl = process.env.GALLABOX_API_URL || 'https://server.gallabox.com/devapi';
        this.apiKey = process.env.GALLABOX_API_KEY;
        this.channelId = process.env.GALLABOX_CHANNEL_ID;
        this.headers = {
          'apikey': this.apiKey,
          'Content-Type': 'application/json'
        };
        break;
      
      case '360dialog':
        this.apiUrl = 'https://waba.360dialog.io/v1';
        this.headers = {
          'D360-API-KEY': process.env.DIALOG_360_API_KEY,
          'Content-Type': 'application/json'
        };
        break;
      
      case 'gupshup':
        this.apiUrl = 'https://api.gupshup.io/sm/api/v1';
        this.headers = {
          'apikey': process.env.GUPSHUP_API_KEY,
          'Content-Type': 'application/x-www-form-urlencoded'
        };
        break;
      
      case 'twilio':
        this.twilioClient = require('twilio')(
          process.env.TWILIO_ACCOUNT_SID,
          process.env.TWILIO_AUTH_TOKEN
        );
        break;
    }
  }

  async sendMessage(phoneNumber, message) {
    try {
      console.log(`📱 Sending via ${this.provider} to ${phoneNumber}: ${message.substring(0, 100)}...`);
      
      switch (this.provider) {
        case 'meta':
          return await this.sendMetaMessage(phoneNumber, message);
        case 'gallabox':
          return await this.sendGallaboxMessage(phoneNumber, message);
        case '360dialog':
          return await this.send360DialogMessage(phoneNumber, message);
        case 'gupshup':
          return await this.sendGupshupMessage(phoneNumber, message);
        case 'twilio':
          return await this.sendTwilioMessage(phoneNumber, message);
        default:
          console.log(`📱 [MOCK] ${phoneNumber}: ${message}`);
          return { success: true, messageId: 'mock_' + Date.now() };
      }
    } catch (error) {
      console.error('❌ WhatsApp send error:', error);
      throw error;
    }
  }

  // Meta WhatsApp Business API
  async sendMetaMessage(phoneNumber, message) {
    if (!this.phoneNumberId || !this.accessToken) {
      throw new Error('Meta WhatsApp credentials not configured');
    }

    const cleanPhoneNumber = phoneNumber.replace(/[^\d]/g, '');
    
    const response = await fetch(`${this.apiUrl}/${this.phoneNumberId}/messages`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to: cleanPhoneNumber,
        text: { body: message },
        type: 'text'
      })
    });

    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(`Meta API error: ${response.status} - ${errorData}`);
    }

    const result = await response.json();
    console.log('✅ Meta message sent:', result);
    return { success: true, messageId: result.messages[0].id };
  }

  // Gallabox API
  async sendGallaboxMessage(phoneNumber, message) {
    if (!this.apiKey || !this.channelId) {
      throw new Error('Gallabox credentials not configured');
    }

    const cleanPhoneNumber = phoneNumber.replace(/[^\d]/g, '');
    
    const response = await fetch(`${this.apiUrl}/message/sendMessage`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify({
        channelId: this.channelId,
        channelType: "whatsapp",
        recipient: cleanPhoneNumber,
        message: {
          type: "text",
          text: message
        }
      })
    });

    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(`Gallabox API error: ${response.status} - ${errorData}`);
    }

    const result = await response.json();
    console.log('✅ Gallabox message sent:', result);
    return { success: true, messageId: result.messageId };
  }

  // 360Dialog API
  async send360DialogMessage(phoneNumber, message) {
    const cleanPhoneNumber = phoneNumber.replace(/[^\d]/g, '');
    
    const response = await fetch(`${this.apiUrl}/messages`, {
      method: 'POST',
      headers: this.headers,
      body: JSON.stringify({
        to: cleanPhoneNumber,
        text: { body: message },
        type: 'text'
      })
    });

    if (!response.ok) {
      throw new Error(`360Dialog API error: ${response.status}`);
    }

    return await response.json();
  }

  // Gupshup API
  async sendGupshupMessage(phoneNumber, message) {
    const cleanPhoneNumber = phoneNumber.replace(/[^\d]/g, '');
    
    const response = await fetch(`${this.apiUrl}/msg`, {
      method: 'POST',
      headers: this.headers,
      body: new URLSearchParams({
        channel: 'whatsapp',
        source: process.env.GUPSHUP_APP_NAME,
        destination: cleanPhoneNumber,
        message: JSON.stringify({
          text: message,
          type: 'text'
        })
      })
    });

    if (!response.ok) {
      throw new Error(`Gupshup API error: ${response.status}`);
    }

    return await response.json();
  }

  // Twilio API
  async sendTwilioMessage(phoneNumber, message) {
    const result = await this.twilioClient.messages.create({
      body: message,
      from: process.env.TWILIO_WHATSAPP_NUMBER,
      to: `whatsapp:${phoneNumber}`
    });

    return { success: true, messageId: result.sid };
  }

  // Webhook handler for all providers
  async handleWebhook(req, res) {
    try {
      console.log('📱 WhatsApp webhook received:', JSON.stringify(req.body, null, 2));
      
      switch (this.provider) {
        case 'meta':
          return await this.handleMetaWebhook(req, res);
        case 'gallabox':
          return await this.handleGallaboxWebhook(req, res);
        case '360dialog':
          return await this.handle360DialogWebhook(req, res);
        case 'gupshup':
          return await this.handleGupshupWebhook(req, res);
        case 'twilio':
          return await this.handleTwilioWebhook(req, res);
        default:
          return await this.handleGenericWebhook(req, res);
      }
    } catch (error) {
      console.error('❌ Webhook handling error:', error);
      res.status(500).json({ error: 'Webhook processing failed' });
    }
  }

  // Meta webhook verification and message handling
  async handleMetaWebhook(req, res) {
    const mode = req.query['hub.mode'];
    const token = req.query['hub.verify_token'];
    const challenge = req.query['hub.challenge'];

    // Webhook verification
    if (mode === 'subscribe' && token === this.verifyToken) {
      console.log('✅ Meta webhook verified');
      return res.status(200).send(challenge);
    }

    // Handle incoming messages
    const body = req.body;
    if (body.object === 'whatsapp_business_account') {
      if (body.entry && body.entry[0].changes && body.entry[0].changes[0].value.messages) {
        const message = body.entry[0].changes[0].value.messages[0];
        const phoneNumber = message.from;
        const messageText = message.text?.body;
        
        if (messageText) {
          console.log(`📱 Received from ${phoneNumber}: ${messageText}`);
          
          // Process with AI chatbot
          const aiChatbotService = require('./aiChatbotService');
          const response = await aiChatbotService.processMessage(phoneNumber, messageText);
          
          // Send response back
          if (response) {
            await this.sendMessage(phoneNumber, response);
          }
        }
      }
      return res.status(200).send('EVENT_RECEIVED');
    }

    return res.status(404).send('Not Found');
  }

  async handleGallaboxWebhook(req, res) {
    const body = req.body;
    
    if (body.type === 'message' && body.message) {
      const phoneNumber = body.sender;
      const messageText = body.message.text;
      
      if (messageText && phoneNumber) {
        console.log(`📱 Received from ${phoneNumber}: ${messageText}`);
        
        const aiChatbotService = require('./aiChatbotService');
        const response = await aiChatbotService.processMessage(phoneNumber, messageText);
        
        if (response) {
          await this.sendMessage(phoneNumber, response);
        }
      }
    }
    
    res.status(200).json({ success: true });
  }

  async handle360DialogWebhook(req, res) {
    const body = req.body;
    
    if (body.messages && body.messages.length > 0) {
      const message = body.messages[0];
      const phoneNumber = message.from;
      const messageText = message.text?.body;
      
      if (messageText) {
        const aiChatbotService = require('./aiChatbotService');
        const response = await aiChatbotService.processMessage(phoneNumber, messageText);
        if (response) {
          await this.sendMessage(phoneNumber, response);
        }
      }
    }
    
    res.status(200).json({ success: true });
  }

  async handleGupshupWebhook(req, res) {
    const body = req.body;
    
    if (body.type === 'message' && body.payload) {
      const phoneNumber = body.payload.source;
      const messageText = body.payload.payload?.text;
      
      if (messageText) {
        const aiChatbotService = require('./aiChatbotService');
        const response = await aiChatbotService.processMessage(phoneNumber, messageText);
        if (response) {
          await this.sendMessage(phoneNumber, response);
        }
      }
    }
    
    res.status(200).json({ success: true });
  }

  async handleTwilioWebhook(req, res) {
    const body = req.body;
    const phoneNumber = body.From?.replace('whatsapp:', '');
    const messageText = body.Body;
    
    if (messageText && phoneNumber) {
      const aiChatbotService = require('./aiChatbotService');
      const response = await aiChatbotService.processMessage(phoneNumber, messageText);
      if (response) {
        await this.sendMessage(phoneNumber, response);
      }
    }
    
    res.status(200).json({ success: true });
  }

  async handleGenericWebhook(req, res) {
    // Generic webhook handler for testing
    const body = req.body;
    const phoneNumber = body.From?.replace('whatsapp:', '') || body.from || body.sender || 'unknown';
    const messageText = body.Body || body.message || body.text;
    
    if (messageText) {
      console.log(`📱 Generic webhook - Received from ${phoneNumber}: ${messageText}`);
      
      const aiChatbotService = require('./aiChatbotService');
      const response = await aiChatbotService.processMessage(phoneNumber, messageText);
      if (response) {
        await this.sendMessage(phoneNumber, response);
      }
    }
    
    res.status(200).json({ success: true });
  }

  // Test connection
  async testConnection() {
    try {
      console.log(`🧪 Testing ${this.provider} connection...`);
      
      switch (this.provider) {
        case 'meta':
          if (!this.phoneNumberId || !this.accessToken) {
            return { 
              success: false, 
              provider: 'meta', 
              error: 'Meta credentials not configured. Please set META_ACCESS_TOKEN and META_PHONE_NUMBER_ID in .env file.' 
            };
          }
          
          const response = await fetch(`${this.apiUrl}/${this.phoneNumberId}`, {
            headers: this.headers
          });
          
          if (response.ok) {
            const data = await response.json();
            console.log('✅ Meta connection successful:', data);
            return { success: true, provider: 'meta', data };
          } else {
            const errorText = await response.text();
            console.log('❌ Meta connection failed:', response.status, errorText);
            return { success: false, provider: 'meta', error: `HTTP ${response.status}: ${errorText}` };
          }
        
        case 'gallabox':
          if (!this.apiKey || !this.channelId) {
            return { 
              success: false, 
              provider: 'gallabox', 
              error: 'Gallabox credentials not configured. Please set GALLABOX_API_KEY and GALLABOX_CHANNEL_ID in .env file.' 
            };
          }
          
          const gallaboxResponse = await fetch(`${this.apiUrl}/channel/getChannels`, {
            method: 'GET',
            headers: this.headers
          });
          
          if (gallaboxResponse.ok) {
            const data = await gallaboxResponse.json();
            console.log('✅ Gallabox connection successful:', data);
            return { success: true, provider: 'gallabox', data };
          } else {
            const errorText = await gallaboxResponse.text();
            return { success: false, provider: 'gallabox', error: `HTTP ${gallaboxResponse.status}: ${errorText}` };
          }
        
        default:
          console.log(`✅ ${this.provider} connection test passed (mock)`);
          return { success: true, provider: this.provider, message: 'Mock connection successful' };
      }
    } catch (error) {
      console.error(`❌ ${this.provider} connection test failed:`, error);
      return { success: false, provider: this.provider, error: error.message };
    }
  }
}

module.exports = new WhatsAppService();