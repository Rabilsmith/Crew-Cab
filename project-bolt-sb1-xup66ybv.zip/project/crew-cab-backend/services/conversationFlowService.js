// Conversation Flow Management Service for Crew Cab AI Chatbot

class ConversationFlowService {
  constructor() {
    this.flowDefinitions = this.initializeFlowDefinitions();
    this.stateTransitions = this.initializeStateTransitions();
  }

  initializeFlowDefinitions() {
    return {
      crew_booking_flow: {
        name: 'Crew Booking Flow',
        description: 'Complete booking flow for crew members',
        states: [
          'initial',
          'intent_detected',
          'collecting_pickup',
          'collecting_time',
          'collecting_destination',
          'confirming_details',
          'processing_payment',
          'booking_confirmed',
          'completed'
        ],
        requiredData: ['pickup_location', 'pickup_time', 'destination'],
        optionalData: ['flight_number', 'special_instructions', 'preferences']
      },

      roster_upload_flow: {
        name: 'Roster Upload Flow',
        description: 'Process roster upload and create multiple bookings',
        states: [
          'initial',
          'roster_received',
          'processing_ocr',
          'flights_extracted',
          'confirming_flights',
          'bundle_pricing',
          'payment_processing',
          'bookings_created',
          'completed'
        ],
        requiredData: ['roster_image', 'extracted_flights'],
        optionalData: ['pickup_preferences', 'bundle_type']
      },

      driver_onboarding_flow: {
        name: 'Driver Onboarding Flow',
        description: 'Complete driver registration and verification',
        states: [
          'initial',
          'basic_info',
          'vehicle_info',
          'documents_upload',
          'verification_pending',
          'approved',
          'completed'
        ],
        requiredData: ['name', 'phone', 'vehicle_details', 'license'],
        optionalData: ['preferred_areas', 'availability']
      },

      preference_setting_flow: {
        name: 'Preference Setting Flow',
        description: 'Set user preferences for rides',
        states: [
          'initial',
          'preference_type',
          'collecting_values',
          'confirming_changes',
          'preferences_saved',
          'completed'
        ],
        requiredData: ['preference_type'],
        optionalData: ['ac_preference', 'music_preference', 'talk_preference']
      }
    };
  }

  initializeStateTransitions() {
    return {
      crew_booking_flow: {
        initial: {
          triggers: ['booking_intent_detected'],
          next: 'intent_detected',
          actions: ['extract_initial_data', 'identify_missing_info']
        },
        intent_detected: {
          triggers: ['has_all_required_data'],
          next: 'confirming_details',
          actions: ['prepare_booking_summary']
        },
        intent_detected: {
          triggers: ['missing_pickup'],
          next: 'collecting_pickup',
          actions: ['ask_for_pickup']
        },
        intent_detected: {
          triggers: ['missing_time'],
          next: 'collecting_time',
          actions: ['ask_for_time']
        },
        collecting_pickup: {
          triggers: ['pickup_provided'],
          next: 'intent_detected',
          actions: ['validate_pickup', 'check_completeness']
        },
        collecting_time: {
          triggers: ['time_provided'],
          next: 'intent_detected',
          actions: ['validate_time', 'check_completeness']
        },
        confirming_details: {
          triggers: ['user_confirmed'],
          next: 'processing_payment',
          actions: ['create_booking', 'generate_payment_link']
        },
        confirming_details: {
          triggers: ['user_rejected'],
          next: 'intent_detected',
          actions: ['reset_data', 'ask_for_changes']
        },
        processing_payment: {
          triggers: ['payment_completed'],
          next: 'booking_confirmed',
          actions: ['assign_driver', 'send_confirmations']
        },
        booking_confirmed: {
          triggers: ['calendar_requested'],
          next: 'completed',
          actions: ['generate_calendar_link']
        },
        booking_confirmed: {
          triggers: ['no_additional_actions'],
          next: 'completed',
          actions: ['cleanup_session']
        }
      },

      roster_upload_flow: {
        initial: {
          triggers: ['roster_image_received'],
          next: 'processing_ocr',
          actions: ['start_ocr_processing', 'show_processing_message']
        },
        processing_ocr: {
          triggers: ['ocr_completed'],
          next: 'flights_extracted',
          actions: ['parse_flight_data', 'validate_flights']
        },
        flights_extracted: {
          triggers: ['flights_valid'],
          next: 'confirming_flights',
          actions: ['show_extracted_flights', 'calculate_bundle_pricing']
        },
        confirming_flights: {
          triggers: ['user_confirmed_flights'],
          next: 'payment_processing',
          actions: ['create_bundle_booking', 'generate_bundle_payment']
        },
        payment_processing: {
          triggers: ['bundle_payment_completed'],
          next: 'bookings_created',
          actions: ['create_individual_bookings', 'assign_drivers']
        },
        bookings_created: {
          triggers: ['all_bookings_created'],
          next: 'completed',
          actions: ['send_booking_confirmations', 'cleanup_session']
        }
      }
    };
  }

  // Main flow processing method
  async processUserInput(phoneNumber, message, currentContext) {
    try {
      // Determine current flow and state
      const flowInfo = this.getCurrentFlow(currentContext);
      
      if (!flowInfo.flowType) {
        // No active flow, detect new flow
        flowInfo.flowType = await this.detectNewFlow(message, currentContext);
        flowInfo.currentState = 'initial';
      }

      // Process input within current flow
      const result = await this.processFlowStep(
        phoneNumber,
        message,
        flowInfo.flowType,
        flowInfo.currentState,
        currentContext
      );

      return result;
    } catch (error) {
      console.error('Flow processing error:', error);
      return this.getErrorResponse(phoneNumber, currentContext);
    }
  }

  async processFlowStep(phoneNumber, message, flowType, currentState, context) {
    const flowDef = this.flowDefinitions[flowType];
    const transitions = this.stateTransitions[flowType];
    
    if (!flowDef || !transitions) {
      throw new Error(`Unknown flow type: ${flowType}`);
    }

    // Analyze user input
    const inputAnalysis = await this.analyzeUserInput(message, currentState, context);
    
    // Determine next state
    const nextState = this.determineNextState(
      currentState,
      inputAnalysis,
      transitions,
      context
    );

    // Execute state actions
    const actionResults = await this.executeStateActions(
      phoneNumber,
      flowType,
      currentState,
      nextState,
      inputAnalysis,
      context
    );

    // Update context
    this.updateFlowContext(context, flowType, nextState, inputAnalysis, actionResults);

    return {
      response: actionResults.response,
      flowType,
      currentState: nextState,
      completed: nextState === 'completed',
      context: context
    };
  }

  async analyzeUserInput(message, currentState, context) {
    const nlpService = require('./nlpService');
    const analysis = await nlpService.processWithContext(message, context);
    
    return {
      ...analysis,
      stateContext: currentState,
      extractedData: this.extractStateSpecificData(message, currentState, context)
    };
  }

  extractStateSpecificData(message, currentState, context) {
    const extractedData = {};

    switch (currentState) {
      case 'collecting_pickup':
        extractedData.pickup_location = this.extractLocation(message, context);
        break;
      
      case 'collecting_time':
        extractedData.pickup_time = this.extractTime(message, context);
        break;
      
      case 'collecting_destination':
        extractedData.destination = this.extractDestination(message, context);
        break;
      
      case 'confirming_details':
        extractedData.confirmation = this.extractConfirmation(message);
        break;
      
      case 'preference_type':
        extractedData.preference_type = this.extractPreferenceType(message);
        break;
      
      case 'collecting_values':
        extractedData.preference_values = this.extractPreferenceValues(message, context);
        break;
    }

    return extractedData;
  }

  determineNextState(currentState, inputAnalysis, transitions, context) {
    const stateTransitions = transitions[currentState];
    
    if (!stateTransitions) {
      return currentState; // Stay in current state if no transitions defined
    }

    // Check each possible transition
    for (const transition of Object.values(stateTransitions)) {
      if (this.evaluateTransitionTrigger(transition.triggers, inputAnalysis, context)) {
        return transition.next;
      }
    }

    return currentState; // No valid transition found
  }

  evaluateTransitionTrigger(triggers, inputAnalysis, context) {
    for (const trigger of triggers) {
      switch (trigger) {
        case 'booking_intent_detected':
          return inputAnalysis.intents.some(intent => intent.intent === 'booking_request');
        
        case 'has_all_required_data':
          return this.hasAllRequiredData(context);
        
        case 'missing_pickup':
          return !context.currentBooking?.pickup_location;
        
        case 'missing_time':
          return !context.currentBooking?.pickup_time;
        
        case 'pickup_provided':
          return inputAnalysis.extractedData.pickup_location;
        
        case 'time_provided':
          return inputAnalysis.extractedData.pickup_time;
        
        case 'user_confirmed':
          return inputAnalysis.extractedData.confirmation === true;
        
        case 'user_rejected':
          return inputAnalysis.extractedData.confirmation === false;
        
        case 'roster_image_received':
          return context.lastMessageType === 'image';
        
        case 'payment_completed':
          return context.paymentStatus === 'completed';
        
        default:
          return false;
      }
    }
    
    return false;
  }

  async executeStateActions(phoneNumber, flowType, currentState, nextState, inputAnalysis, context) {
    const transitions = this.stateTransitions[flowType];
    const stateTransition = transitions[currentState];
    
    if (!stateTransition) {
      return { response: "I'm not sure how to proceed. Let me help you start over." };
    }

    const actions = stateTransition.actions || [];
    let response = '';
    const actionResults = {};

    for (const action of actions) {
      const result = await this.executeAction(action, phoneNumber, inputAnalysis, context);
      if (result.response) {
        response = result.response;
      }
      Object.assign(actionResults, result);
    }

    return { response, ...actionResults };
  }

  async executeAction(action, phoneNumber, inputAnalysis, context) {
    switch (action) {
      case 'extract_initial_data':
        return this.extractInitialBookingData(inputAnalysis, context);
      
      case 'identify_missing_info':
        return this.identifyMissingInformation(context);
      
      case 'ask_for_pickup':
        return { response: this.generatePickupQuestion(context) };
      
      case 'ask_for_time':
        return { response: this.generateTimeQuestion(context) };
      
      case 'validate_pickup':
        return this.validatePickupLocation(inputAnalysis.extractedData.pickup_location, context);
      
      case 'validate_time':
        return this.validatePickupTime(inputAnalysis.extractedData.pickup_time, context);
      
      case 'check_completeness':
        return this.checkBookingCompleteness(context);
      
      case 'prepare_booking_summary':
        return this.prepareBookingSummary(context);
      
      case 'create_booking':
        return await this.createBooking(phoneNumber, context);
      
      case 'generate_payment_link':
        return await this.generatePaymentLink(context);
      
      case 'assign_driver':
        return await this.assignDriver(context);
      
      case 'send_confirmations':
        return await this.sendBookingConfirmations(phoneNumber, context);
      
      case 'generate_calendar_link':
        return this.generateCalendarLink(context);
      
      case 'cleanup_session':
        return this.cleanupSession(context);
      
      default:
        return { response: "Processing your request..." };
    }
  }

  // Action implementations
  extractInitialBookingData(inputAnalysis, context) {
    context.currentBooking = context.currentBooking || {};
    
    // Extract time if present
    if (inputAnalysis.entities.time.length > 0) {
      context.currentBooking.pickup_time = inputAnalysis.entities.time[0].value;
    }
    
    // Extract location if present
    if (inputAnalysis.entities.location.length > 0) {
      const location = inputAnalysis.entities.location[0];
      if (location.needsContext) {
        context.currentBooking.pickup_location_reference = location.value;
      } else {
        context.currentBooking.pickup_location = location.normalized || location.value;
      }
    }
    
    // Extract date if present
    if (inputAnalysis.entities.date.length > 0) {
      context.currentBooking.pickup_date = inputAnalysis.entities.date[0].value;
    }
    
    return { dataExtracted: true };
  }

  identifyMissingInformation(context) {
    const booking = context.currentBooking || {};
    const missing = [];
    
    if (!booking.pickup_location && !booking.pickup_location_reference) {
      missing.push('pickup_location');
    }
    
    if (!booking.pickup_time) {
      missing.push('pickup_time');
    }
    
    if (!booking.destination) {
      booking.destination = 'Emirates HQ'; // Default destination
    }
    
    context.missingInformation = missing;
    return { missingInfo: missing };
  }

  generatePickupQuestion(context) {
    const booking = context.currentBooking || {};
    
    if (booking.pickup_location_reference === 'contextual_reference') {
      // User said "same place" or similar
      const lastLocation = this.getLastPickupLocation(context.phoneNumber);
      if (lastLocation) {
        context.suggestedLocation = lastLocation;
        return `Last time, you were picked up from ${lastLocation}. Should we use the same location?`;
      }
    }
    
    const timeContext = booking.pickup_time ? ` for your ${booking.pickup_time} pickup` : '';
    return `Where should we pick you up from${timeContext}? 📍`;
  }

  generateTimeQuestion(context) {
    const booking = context.currentBooking || {};
    const locationContext = booking.pickup_location ? ` from ${booking.pickup_location}` : '';
    return `What time do you need to be picked up${locationContext}? 🕐`;
  }

  validatePickupLocation(location, context) {
    if (!location) {
      return { 
        valid: false, 
        response: "I didn't catch the pickup location. Could you please specify where you'd like to be picked up?" 
      };
    }
    
    context.currentBooking = context.currentBooking || {};
    context.currentBooking.pickup_location = location;
    
    return { valid: true, location };
  }

  validatePickupTime(time, context) {
    if (!time) {
      return { 
        valid: false, 
        response: "I didn't catch the time. Could you please specify when you need to be picked up?" 
      };
    }
    
    context.currentBooking = context.currentBooking || {};
    context.currentBooking.pickup_time = time;
    
    return { valid: true, time };
  }

  checkBookingCompleteness(context) {
    const booking = context.currentBooking || {};
    const required = ['pickup_location', 'pickup_time'];
    const missing = required.filter(field => !booking[field]);
    
    return { 
      complete: missing.length === 0,
      missing,
      hasAllData: missing.length === 0
    };
  }

  prepareBookingSummary(context) {
    const booking = context.currentBooking || {};
    
    const summary = `✅ *Booking Summary:*\n\n📍 Pickup: ${booking.pickup_location}\n🕐 Time: ${booking.pickup_time}\n✈️ Destination: ${booking.destination || 'Emirates HQ'}\n💰 Price: AED 60\n\nShall I proceed with this booking?`;
    
    return { response: summary };
  }

  async createBooking(phoneNumber, context) {
    const booking = context.currentBooking;
    const bookingId = 'RIDE' + Date.now().toString().slice(-6);
    
    context.bookingId = bookingId;
    context.bookingStatus = 'created';
    
    return { bookingId, created: true };
  }

  async generatePaymentLink(context) {
    const paymentLink = `https://checkout.stripe.com/pay/mock-${context.bookingId}`;
    context.paymentLink = paymentLink;
    
    const response = `🎉 *Booking Created!*\n\nBooking ID: ${context.bookingId}\n\n💳 *Secure Payment:*\n${paymentLink}\n\n✅ Your driver will be assigned after payment confirmation.`;
    
    return { response, paymentLink };
  }

  async assignDriver(context) {
    // Mock driver assignment
    context.assignedDriver = {
      name: 'Ahmed Hassan',
      car: 'Toyota Camry 2022',
      plate: 'A12345',
      phone: '+971509876543'
    };
    
    return { driverAssigned: true };
  }

  async sendBookingConfirmations(phoneNumber, context) {
    const driver = context.assignedDriver;
    const response = `✅ *Driver Assigned!*\n\nYour driver: ${driver.name}\nCar: ${driver.car} (${driver.plate})\nContact: ${driver.phone}\n\nWould you like to add this to your calendar?`;
    
    return { response };
  }

  generateCalendarLink(context) {
    const calendarUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=Crew+Cab+Ride&dates=${context.bookingId}`;
    const response = `📅 *Calendar Link:*\n${calendarUrl}\n\nYour ride has been added to your calendar!`;
    
    return { response };
  }

  cleanupSession(context) {
    // Clean up temporary data but keep important info
    delete context.currentBooking;
    delete context.missingInformation;
    delete context.waitingFor;
    
    context.lastCompletedFlow = context.currentFlow;
    delete context.currentFlow;
    
    return { sessionCleaned: true };
  }

  // Helper methods
  getCurrentFlow(context) {
    return {
      flowType: context.currentFlow?.type,
      currentState: context.currentFlow?.state || 'initial'
    };
  }

  async detectNewFlow(message, context) {
    const nlpService = require('./nlpService');
    const analysis = await nlpService.processMessage(message, context);
    
    // Check for booking intent
    if (analysis.intents.some(intent => intent.intent === 'booking_request')) {
      return 'crew_booking_flow';
    }
    
    // Check for roster upload
    if (analysis.intents.some(intent => intent.intent === 'roster_upload') || 
        context.lastMessageType === 'image') {
      return 'roster_upload_flow';
    }
    
    // Check for driver onboarding
    if (message.toLowerCase().includes('join driver') || 
        message.toLowerCase().includes('driver signup')) {
      return 'driver_onboarding_flow';
    }
    
    // Check for preference setting
    if (analysis.intents.some(intent => intent.intent === 'preferences')) {
      return 'preference_setting_flow';
    }
    
    return null; // No specific flow detected
  }

  updateFlowContext(context, flowType, nextState, inputAnalysis, actionResults) {
    context.currentFlow = {
      type: flowType,
      state: nextState,
      lastUpdate: new Date()
    };
    
    // Merge action results into context
    Object.assign(context, actionResults);
    
    // Update message history
    context.messageHistory = context.messageHistory || [];
    context.messageHistory.push({
      message: inputAnalysis.originalMessage,
      timestamp: new Date(),
      state: nextState,
      processed: true
    });
    
    // Keep only last 10 messages
    if (context.messageHistory.length > 10) {
      context.messageHistory = context.messageHistory.slice(-10);
    }
  }

  hasAllRequiredData(context) {
    const booking = context.currentBooking || {};
    return booking.pickup_location && booking.pickup_time;
  }

  extractLocation(message, context) {
    // Simple location extraction - in real implementation, use NLP service
    const locations = ['marina', 'downtown', 'deira', 'jumeirah', 'home'];
    const lowerMessage = message.toLowerCase();
    
    for (const location of locations) {
      if (lowerMessage.includes(location)) {
        return location;
      }
    }
    
    return null;
  }

  extractTime(message, context) {
    // Simple time extraction - in real implementation, use NLP service
    const timeMatch = message.match(/(\d{1,2}):?(\d{2})?\s*(am|pm)?/i);
    if (timeMatch) {
      return timeMatch[0];
    }
    
    return null;
  }

  extractDestination(message, context) {
    if (message.toLowerCase().includes('airport') || 
        message.toLowerCase().includes('emirates')) {
      return 'Emirates HQ';
    }
    
    return null;
  }

  extractConfirmation(message) {
    const lowerMessage = message.toLowerCase().trim();
    
    if (['yes', 'yeah', 'yep', 'ok', 'okay', 'sure', 'correct', 'right'].includes(lowerMessage)) {
      return true;
    }
    
    if (['no', 'nope', 'not', 'wrong', 'different'].includes(lowerMessage)) {
      return false;
    }
    
    return null;
  }

  extractPreferenceType(message) {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('music')) return 'music';
    if (lowerMessage.includes('ac') || lowerMessage.includes('air')) return 'ac';
    if (lowerMessage.includes('talk') || lowerMessage.includes('chat')) return 'talk';
    
    return null;
  }

  extractPreferenceValues(message, context) {
    const lowerMessage = message.toLowerCase();
    const preferenceType = context.currentPreferenceType;
    
    const values = {};
    
    if (lowerMessage.includes('on') || lowerMessage.includes('yes')) {
      values[preferenceType] = 'on';
    } else if (lowerMessage.includes('off') || lowerMessage.includes('no')) {
      values[preferenceType] = 'off';
    }
    
    return values;
  }

  getLastPickupLocation(phoneNumber) {
    // Mock implementation - in real app, query database
    const mockLocations = {
      '+971501234567': 'Dubai Marina',
      '+971502222222': 'Downtown Dubai'
    };
    
    return mockLocations[phoneNumber] || null;
  }

  getErrorResponse(phoneNumber, context) {
    return {
      response: "I'm having trouble understanding. Let me help you start over. What would you like to do?",
      flowType: null,
      currentState: 'initial',
      completed: false,
      context: this.resetContext(context)
    };
  }

  resetContext(context) {
    // Keep essential info but reset flow state
    return {
      phoneNumber: context.phoneNumber,
      userType: context.userType,
      messageHistory: context.messageHistory || [],
      preferences: context.preferences || {},
      createdAt: context.createdAt
    };
  }
}

module.exports = new ConversationFlowService();