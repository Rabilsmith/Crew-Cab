// Voice Note Processing Service for Natural Booking

class VoiceProcessingService {
  constructor() {
    this.supportedLanguages = ['en', 'ar', 'hi', 'ur']; // English, Arabic, Hindi, Urdu
    this.aviationKeywords = this.initializeAviationKeywords();
  }

  initializeAviationKeywords() {
    return {
      english: {
        flight: ['flight', 'departure', 'takeoff', 'boarding'],
        pickup: ['pickup', 'pick me up', 'collect', 'get me'],
        time: ['at', 'around', 'by', 'before'],
        locations: ['marina', 'downtown', 'deira', 'jumeirah', 'home', 'airport', 'emirates hq'],
        urgency: ['urgent', 'asap', 'quickly', 'rush', 'emergency']
      },
      arabic: {
        flight: ['رحلة', 'طيران', 'مغادرة'],
        pickup: ['اصطحاب', 'خذني', 'استقبال'],
        time: ['في', 'حوالي', 'قبل'],
        locations: ['مارينا', 'وسط المدينة', 'ديرة', 'جميرا', 'البيت', 'المطار']
      }
    };
  }

  /**
   * Convert voice note to text using speech recognition
   */
  async convertVoiceToText(voiceNoteUrl, language = 'en') {
    try {
      // Mock implementation - in production, use Google Speech-to-Text, Azure, or similar
      console.log(`🎤 Converting voice note to text: ${voiceNoteUrl}`);
      
      // Simulate processing time
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock transcription based on common crew requests
      const mockTranscriptions = [
        "I have a flight tomorrow at six ten AM, can you pick me up from Marina?",
        "Need a ride to the airport at three thirty in the morning from my usual place",
        "Flight at seven fifteen tomorrow, pickup from downtown please",
        "Emergency ride needed, flight in two hours from Deira to Emirates HQ",
        "Can you get me at five forty five AM tomorrow from the same place as last time?"
      ];
      
      const transcription = mockTranscriptions[Math.floor(Math.random() * mockTranscriptions.length)];
      
      return {
        success: true,
        transcription,
        language: language,
        confidence: 0.92,
        duration: 8.5, // seconds
        processingTime: 2.1 // seconds
      };
    } catch (error) {
      console.error('Voice-to-text conversion error:', error);
      return {
        success: false,
        error: error.message,
        transcription: null
      };
    }
  }

  /**
   * Process voice note for booking intent
   */
  async processVoiceBooking(crewPhone, voiceNoteUrl) {
    try {
      console.log(`🎤 Processing voice booking for ${crewPhone}`);
      
      // Step 1: Convert voice to text
      const transcriptionResult = await this.convertVoiceToText(voiceNoteUrl);
      
      if (!transcriptionResult.success) {
        return {
          success: false,
          message: "🎤 Sorry, I couldn't understand your voice note clearly. Could you try speaking more clearly or type your request?"
        };
      }

      // Step 2: Analyze transcription with NLP
      const nlpService = require('./nlpService');
      const analysis = await nlpService.processMessage(transcriptionResult.transcription);
      
      // Step 3: Extract booking information
      const bookingInfo = this.extractBookingFromVoice(analysis, transcriptionResult);
      
      // Step 4: Create response based on extracted information
      const response = await this.createVoiceBookingResponse(crewPhone, bookingInfo, transcriptionResult);
      
      return {
        success: true,
        transcription: transcriptionResult.transcription,
        bookingInfo,
        response: response.message,
        confidence: transcriptionResult.confidence,
        needsFollowUp: response.needsFollowUp
      };
    } catch (error) {
      console.error('Voice booking processing error:', error);
      return {
        success: false,
        message: "🎤 I had trouble processing your voice note. Please try again or type your request."
      };
    }
  }

  /**
   * Extract booking information from voice analysis
   */
  extractBookingFromVoice(analysis, transcriptionResult) {
    const bookingInfo = {
      hasBookingIntent: false,
      extractedTime: null,
      extractedLocation: null,
      extractedDate: null,
      urgency: 'normal',
      confidence: transcriptionResult.confidence
    };

    // Check for booking intent
    const bookingIntents = analysis.intents.filter(intent => 
      intent.intent === 'booking_request' || intent.intent === 'flight_booking'
    );
    
    if (bookingIntents.length > 0) {
      bookingInfo.hasBookingIntent = true;
    }

    // Extract time information
    if (analysis.entities.time && analysis.entities.time.length > 0) {
      bookingInfo.extractedTime = analysis.entities.time[0].value;
    }

    // Extract location information
    if (analysis.entities.location && analysis.entities.location.length > 0) {
      bookingInfo.extractedLocation = analysis.entities.location[0].value;
    }

    // Extract date information
    if (analysis.entities.date && analysis.entities.date.length > 0) {
      bookingInfo.extractedDate = analysis.entities.date[0].value;
    }

    // Detect urgency
    if (analysis.sentiment.isUrgent) {
      bookingInfo.urgency = 'urgent';
    }

    return bookingInfo;
  }

  /**
   * Create appropriate response for voice booking
   */
  async createVoiceBookingResponse(crewPhone, bookingInfo, transcriptionResult) {
    if (!bookingInfo.hasBookingIntent) {
      return {
        message: `🎤 I heard: "${transcriptionResult.transcription}"\n\nI'm not sure if you want to book a ride. Could you clarify what you need help with?`,
        needsFollowUp: true
      };
    }

    // Get user context for personalization
    const aiChatbotService = require('./aiChatbotService');
    const context = aiChatbotService.getUserContext(crewPhone);
    
    let response = `🎤 *Voice Message Understood!*\n\n`;
    response += `I heard: "${transcriptionResult.transcription}"\n\n`;
    
    // Build booking confirmation
    response += `✈️ Let me confirm your booking:\n`;
    
    if (bookingInfo.extractedTime) {
      response += `🕐 Time: ${bookingInfo.extractedTime}\n`;
      context.currentBooking = context.currentBooking || {};
      context.currentBooking.time = bookingInfo.extractedTime;
    } else {
      response += `🕐 Time: Please specify pickup time\n`;
    }
    
    if (bookingInfo.extractedLocation) {
      response += `📍 Pickup: ${bookingInfo.extractedLocation}\n`;
      context.currentBooking = context.currentBooking || {};
      context.currentBooking.pickup = bookingInfo.extractedLocation;
    } else if (bookingInfo.extractedLocation === 'same place' || bookingInfo.extractedLocation === 'usual place') {
      const lastLocation = await this.getLastPickupLocation(crewPhone);
      if (lastLocation) {
        response += `📍 Pickup: ${lastLocation} (your usual place)\n`;
        context.currentBooking = context.currentBooking || {};
        context.currentBooking.pickup = lastLocation;
      } else {
        response += `📍 Pickup: Please specify location\n`;
      }
    } else {
      response += `📍 Pickup: Please specify pickup location\n`;
    }
    
    response += `📍 Destination: Emirates HQ\n\n`;
    
    // Check if we have all required information
    const hasAllInfo = context.currentBooking?.time && context.currentBooking?.pickup;
    
    if (hasAllInfo) {
      response += `✅ Perfect! I have all the details. Shall I proceed with this booking?\n\n`;
      response += `Reply "Yes" to confirm or "No" to make changes.`;
      context.waitingFor = 'booking_confirmation';
      return { message: response, needsFollowUp: false };
    } else {
      const missing = [];
      if (!context.currentBooking?.time) missing.push('pickup time');
      if (!context.currentBooking?.pickup) missing.push('pickup location');
      
      response += `❓ I need to confirm: ${missing.join(' and ')}\n\n`;
      response += `Please provide the missing information to complete your booking.`;
      context.waitingFor = missing[0].includes('time') ? 'time' : 'pickup';
      return { message: response, needsFollowUp: true };
    }
  }

  /**
   * Handle multilingual voice notes
   */
  async processMultilingualVoice(voiceNoteUrl) {
    try {
      // Detect language first
      const detectedLanguage = await this.detectLanguage(voiceNoteUrl);
      
      // Convert to text in detected language
      const transcription = await this.convertVoiceToText(voiceNoteUrl, detectedLanguage);
      
      // Translate to English if needed for processing
      let processableText = transcription.transcription;
      if (detectedLanguage !== 'en') {
        processableText = await this.translateToEnglish(transcription.transcription, detectedLanguage);
      }
      
      return {
        originalLanguage: detectedLanguage,
        originalText: transcription.transcription,
        englishText: processableText,
        confidence: transcription.confidence
      };
    } catch (error) {
      console.error('Multilingual voice processing error:', error);
      throw error;
    }
  }

  /**
   * Detect language from voice note
   */
  async detectLanguage(voiceNoteUrl) {
    // Mock implementation - in production, use language detection service
    const languages = ['en', 'ar', 'hi', 'ur'];
    return languages[Math.floor(Math.random() * languages.length)];
  }

  /**
   * Translate text to English
   */
  async translateToEnglish(text, sourceLanguage) {
    // Mock implementation - in production, use Google Translate or similar
    const translations = {
      'ar': 'I have a flight tomorrow at six AM, pick me up from Marina',
      'hi': 'I have a flight tomorrow at six AM, pick me up from Marina',
      'ur': 'I have a flight tomorrow at six AM, pick me up from Marina'
    };
    
    return translations[sourceLanguage] || text;
  }

  /**
   * Generate voice response (text-to-speech for accessibility)
   */
  async generateVoiceResponse(text, language = 'en') {
    try {
      // Mock implementation - in production, use text-to-speech service
      console.log(`🔊 Generating voice response in ${language}: ${text.substring(0, 50)}...`);
      
      return {
        success: true,
        audioUrl: `https://mock-tts-service.com/audio/${Date.now()}.mp3`,
        duration: Math.ceil(text.length / 10), // Rough estimate
        language
      };
    } catch (error) {
      console.error('Voice response generation error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Smart voice command recognition
   */
  recognizeVoiceCommands(transcription) {
    const commands = {
      booking: /book|ride|pickup|flight|airport/i,
      cancel: /cancel|stop|abort/i,
      status: /status|where|when|driver/i,
      help: /help|assist|support/i,
      repeat: /repeat|again|what/i
    };

    const recognizedCommands = [];
    
    for (const [command, pattern] of Object.entries(commands)) {
      if (pattern.test(transcription)) {
        recognizedCommands.push(command);
      }
    }
    
    return recognizedCommands;
  }

  // Helper methods
  async getLastPickupLocation(crewPhone) {
    // Mock implementation
    const mockLocations = {
      '+971501234567': 'Dubai Marina',
      '+971502222222': 'Downtown Dubai'
    };
    return mockLocations[crewPhone] || null;
  }
}

module.exports = new VoiceProcessingService();