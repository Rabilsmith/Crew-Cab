// Smart Auto-Matching & AI Dispatcher Service for Crew Cab

class SmartDispatcherService {
  constructor() {
    this.activeRides = new Map(); // Track active ride requests
    this.driverResponses = new Map(); // Track driver responses to rides
    this.learningData = new Map(); // Store learning patterns
    this.rosterCache = new Map(); // Cache processed rosters
    this.performanceMetrics = new Map(); // Driver performance tracking
  }

  /**
   * Main ride dispatch logic - notifies all drivers and handles responses
   */
  async dispatchRide(rideRequest) {
    try {
      console.log(`🚀 Dispatching ride ${rideRequest.id} to all available drivers`);
      
      // Get all available drivers in the area
      const availableDrivers = await this.getAvailableDrivers(rideRequest);
      
      if (availableDrivers.length === 0) {
        return await this.handleNoDriversAvailable(rideRequest);
      }

      // Create dispatch entry
      this.activeRides.set(rideRequest.id, {
        ...rideRequest,
        dispatchedAt: new Date(),
        notifiedDrivers: availableDrivers.map(d => d.phoneNumber),
        status: 'dispatched',
        responses: []
      });

      // Notify all drivers simultaneously
      const notifications = availableDrivers.map(driver => 
        this.notifyDriver(driver, rideRequest)
      );

      await Promise.all(notifications);

      // Set timeout for auto-escalation if no response
      setTimeout(() => {
        this.handleDispatchTimeout(rideRequest.id);
      }, 300000); // 5 minutes timeout

      return {
        success: true,
        dispatchedTo: availableDrivers.length,
        rideId: rideRequest.id
      };
    } catch (error) {
      console.error('Dispatch error:', error);
      return await this.handleDispatchError(rideRequest, error);
    }
  }

  /**
   * Handle driver responses to ride requests
   */
  async handleDriverResponse(driverPhone, rideId, response) {
    try {
      const ride = this.activeRides.get(rideId);
      
      if (!ride) {
        return await this.sendDriverMessage(driverPhone, 
          "❌ This ride is no longer available or has been assigned."
        );
      }

      if (ride.status === 'assigned') {
        return await this.sendDriverMessage(driverPhone, 
          "❌ This ride has already been assigned to another driver."
        );
      }

      // Record response time for learning
      const responseTime = Date.now() - ride.dispatchedAt.getTime();
      this.recordDriverResponseTime(driverPhone, responseTime);

      if (response.toLowerCase().includes('accept') || response.toLowerCase() === 'yes') {
        return await this.assignRideToDriver(rideId, driverPhone);
      } else {
        return await this.recordDriverDecline(rideId, driverPhone, response);
      }
    } catch (error) {
      console.error('Error handling driver response:', error);
      return false;
    }
  }

  /**
   * Assign ride to first accepting driver
   */
  async assignRideToDriver(rideId, driverPhone) {
    try {
      const ride = this.activeRides.get(rideId);
      const driver = await this.getDriverByPhone(driverPhone);
      
      if (!ride || !driver) {
        return false;
      }

      // Update ride status
      ride.status = 'assigned';
      ride.assignedDriver = driverPhone;
      ride.assignedAt = new Date();

      // Notify accepting driver
      await this.sendDriverMessage(driverPhone, 
        `✅ *Ride Assigned to You!*\n\n` +
        `📋 Ride ID: ${rideId}\n` +
        `👤 Passenger: Crew Member\n` +
        `📍 Pickup: ${ride.pickupLocation}\n` +
        `🕐 Time: ${ride.pickupTime}\n` +
        `📍 Destination: ${ride.destination}\n` +
        `💰 Your Payout: AED ${ride.driverPayout}\n\n` +
        `📱 Passenger Contact: ${ride.crewPhone}\n` +
        `🚗 Confirm pickup: CrewCab#pickup#${rideId}`
      );

      // Notify other drivers that ride is taken
      const otherDrivers = ride.notifiedDrivers.filter(phone => phone !== driverPhone);
      const notifications = otherDrivers.map(phone => 
        this.sendDriverMessage(phone, 
          `❌ Ride ${rideId} has been assigned to another driver. Thanks for your quick response!`
        )
      );
      await Promise.all(notifications);

      // Notify crew member to proceed with payment
      await this.requestCrewPayment(ride);

      // Learn from successful assignment
      this.recordSuccessfulAssignment(driverPhone, ride);

      console.log(`✅ Ride ${rideId} assigned to driver ${driverPhone}`);
      return true;
    } catch (error) {
      console.error('Error assigning ride:', error);
      return false;
    }
  }

  /**
   * Process roster uploads and create intelligent suggestions
   */
  async processRosterIntelligence(crewPhone, rosterData) {
    try {
      console.log(`📋 Processing roster intelligence for ${crewPhone}`);
      
      // Extract flights from roster
      const flights = await this.extractFlightsFromRoster(rosterData);
      
      // Find potential ride sharing opportunities
      const rideSharingOpportunities = await this.findRideSharingOpportunities(flights, crewPhone);
      
      // Suggest optimal driver matches
      const driverSuggestions = await this.suggestOptimalDrivers(flights, crewPhone);
      
      // Create auto-booking suggestions
      const autoBookingSuggestions = await this.createAutoBookingSuggestions(flights, crewPhone);
      
      // Cache roster for future matching
      this.rosterCache.set(crewPhone, {
        flights,
        processedAt: new Date(),
        rideSharingOpportunities,
        driverSuggestions
      });

      return {
        flights,
        rideSharingOpportunities,
        driverSuggestions,
        autoBookingSuggestions,
        totalFlights: flights.length,
        bundlePrice: this.calculateBundlePrice(flights.length)
      };
    } catch (error) {
      console.error('Roster intelligence error:', error);
      throw error;
    }
  }

  /**
   * Find ride sharing opportunities based on roster analysis
   */
  async findRideSharingOpportunities(flights, crewPhone) {
    const opportunities = [];
    
    for (const flight of flights) {
      // Check for other crew with similar flight times
      const similarFlights = await this.findSimilarFlights(flight, crewPhone);
      
      if (similarFlights.length > 0) {
        opportunities.push({
          flightTime: flight.time,
          flightDate: flight.date,
          potentialShares: similarFlights.length,
          estimatedSavings: similarFlights.length * 15, // AED 15 savings per shared ride
          crewMembers: similarFlights.map(f => f.crewName),
          suggestedPickupTime: this.calculateOptimalPickupTime(flight.time),
          maxCapacity: 3 // Max 3 crew members per ride
        });
      }
    }
    
    return opportunities;
  }

  /**
   * Suggest optimal drivers based on performance and preferences
   */
  async suggestOptimalDrivers(flights, crewPhone) {
    try {
      const crewPreferences = await this.getCrewPreferences(crewPhone);
      const availableDrivers = await this.getAllDrivers();
      
      const suggestions = [];
      
      for (const driver of availableDrivers) {
        const score = await this.calculateDriverMatchScore(driver, crewPreferences, flights);
        
        if (score > 0.7) { // Only suggest high-scoring matches
          suggestions.push({
            driverName: driver.name,
            driverPhone: driver.phoneNumber,
            matchScore: Math.round(score * 100),
            reasons: this.getMatchReasons(driver, crewPreferences),
            availability: await this.checkDriverAvailability(driver.phoneNumber, flights),
            rating: driver.rating,
            completedRides: driver.totalRides
          });
        }
      }
      
      // Sort by match score
      return suggestions.sort((a, b) => b.matchScore - a.matchScore).slice(0, 5);
    } catch (error) {
      console.error('Error suggesting drivers:', error);
      return [];
    }
  }

  /**
   * Calculate driver match score based on multiple factors
   */
  async calculateDriverMatchScore(driver, crewPreferences, flights) {
    let score = 0;
    
    // Base score from driver rating
    score += (driver.rating / 5) * 0.3;
    
    // Preference matching
    if (crewPreferences.genderPreference && driver.gender === crewPreferences.genderPreference) {
      score += 0.2;
    }
    
    if (crewPreferences.smallTalkPreference === driver.communicationStyle) {
      score += 0.15;
    }
    
    if (crewPreferences.musicPreference === driver.musicPolicy) {
      score += 0.1;
    }
    
    // Performance metrics
    const performance = this.performanceMetrics.get(driver.phoneNumber);
    if (performance) {
      score += (performance.onTimePercentage / 100) * 0.15;
      score -= (performance.cancellationRate / 100) * 0.1;
    }
    
    // Area familiarity
    const crewArea = await this.getCrewHomeArea(crewPreferences.crewPhone);
    if (driver.preferredAreas.includes(crewArea)) {
      score += 0.1;
    }
    
    return Math.min(score, 1.0);
  }

  /**
   * Auto-suggest bookings based on roster patterns
   */
  async createAutoBookingSuggestions(flights, crewPhone) {
    const suggestions = [];
    const crewHistory = await this.getCrewBookingHistory(crewPhone);
    
    for (const flight of flights) {
      // Find similar historical bookings
      const similarBookings = crewHistory.filter(booking => 
        this.isSimilarFlightTime(booking.flightTime, flight.time)
      );
      
      if (similarBookings.length > 0) {
        const mostCommon = this.findMostCommonPattern(similarBookings);
        
        suggestions.push({
          flightDate: flight.date,
          flightTime: flight.time,
          suggestedPickupTime: mostCommon.pickupTime,
          suggestedPickupLocation: mostCommon.pickupLocation,
          confidence: this.calculateSuggestionConfidence(similarBookings),
          basedOnRides: similarBookings.length,
          estimatedPrice: mostCommon.averagePrice
        });
      }
    }
    
    return suggestions;
  }

  /**
   * Smart driver notification with ride details
   */
  async notifyDriver(driver, rideRequest) {
    try {
      const message = `🚗 *New Ride Available*\n\n` +
        `📋 Ride ID: ${rideRequest.id}\n` +
        `📍 Pickup: ${rideRequest.pickupLocation}\n` +
        `🕐 Time: ${rideRequest.pickupTime}\n` +
        `📍 Destination: ${rideRequest.destination}\n` +
        `💰 Your Payout: AED ${rideRequest.driverPayout}\n` +
        `📏 Distance: ${rideRequest.estimatedDistance}km\n` +
        `⏱️ Duration: ${rideRequest.estimatedDuration} mins\n\n` +
        `✅ Reply "Accept" to take this ride\n` +
        `❌ Reply "Decline" to pass\n\n` +
        `⚡ First to accept gets the job!`;

      await this.sendDriverMessage(driver.phoneNumber, message);
      
      // Track notification for analytics
      this.recordDriverNotification(driver.phoneNumber, rideRequest.id);
      
      return true;
    } catch (error) {
      console.error(`Error notifying driver ${driver.phoneNumber}:`, error);
      return false;
    }
  }

  /**
   * Request payment from crew member after driver assignment
   */
  async requestCrewPayment(ride) {
    try {
      const paymentLink = await this.generatePaymentLink(ride);
      
      const message = `✅ *Driver Assigned!*\n\n` +
        `🚗 Driver: ${ride.assignedDriverName}\n` +
        `📱 Contact: ${ride.assignedDriver}\n` +
        `🕐 Pickup Time: ${ride.pickupTime}\n` +
        `📍 From: ${ride.pickupLocation}\n` +
        `📍 To: ${ride.destination}\n` +
        `💰 Price: AED ${ride.price}\n\n` +
        `💳 *Complete Payment:*\n${paymentLink}\n\n` +
        `✅ Your driver will be notified once payment is confirmed.`;

      await this.sendCrewMessage(ride.crewPhone, message);
      
      return true;
    } catch (error) {
      console.error('Error requesting crew payment:', error);
      return false;
    }
  }

  /**
   * Performance analytics and learning
   */
  recordDriverResponseTime(driverPhone, responseTime) {
    const metrics = this.performanceMetrics.get(driverPhone) || {
      totalResponses: 0,
      averageResponseTime: 0,
      acceptanceRate: 0,
      onTimePercentage: 100,
      cancellationRate: 0
    };
    
    metrics.totalResponses++;
    metrics.averageResponseTime = (metrics.averageResponseTime + responseTime) / 2;
    
    this.performanceMetrics.set(driverPhone, metrics);
  }

  recordSuccessfulAssignment(driverPhone, ride) {
    // Learn successful patterns for future matching
    const learningKey = `${driverPhone}_${ride.pickupArea}_${ride.timeSlot}`;
    const existing = this.learningData.get(learningKey) || { count: 0, successRate: 0 };
    
    existing.count++;
    existing.successRate = (existing.successRate + 1) / 2; // Weighted average
    existing.lastSuccess = new Date();
    
    this.learningData.set(learningKey, existing);
  }

  /**
   * Voice note processing for natural booking
   */
  async processVoiceNote(crewPhone, voiceNoteUrl) {
    try {
      // Convert voice to text (mock implementation)
      const transcription = await this.convertVoiceToText(voiceNoteUrl);
      
      // Process with NLP
      const nlpService = require('./nlpService');
      const analysis = await nlpService.processMessage(transcription);
      
      // Extract booking intent
      if (analysis.intents.some(intent => intent.intent === 'booking_request')) {
        return await this.createBookingFromVoice(crewPhone, analysis);
      }
      
      return {
        success: false,
        message: "I couldn't understand the booking request from your voice note. Could you try again?"
      };
    } catch (error) {
      console.error('Voice note processing error:', error);
      return {
        success: false,
        message: "Sorry, I had trouble processing your voice note. Please try typing your request."
      };
    }
  }

  /**
   * Fail-safe logic for system errors
   */
  async handleSystemFailure(context, error) {
    console.error('System failure detected:', error);
    
    // Switch to human mode
    const humanModeMessage = `🔧 *System Check in Progress*\n\n` +
      `We're checking this manually to ensure everything is perfect.\n\n` +
      `⏱️ Please hold for 2-3 minutes while our team reviews your request.\n\n` +
      `📞 For urgent matters, call: +971-XXX-XXXX\n\n` +
      `Thank you for your patience! 🙏`;
    
    if (context.crewPhone) {
      await this.sendCrewMessage(context.crewPhone, humanModeMessage);
    }
    
    // Alert admin team
    await this.alertAdminTeam({
      type: 'system_failure',
      context,
      error: error.message,
      timestamp: new Date(),
      requiresManualIntervention: true
    });
    
    return {
      success: false,
      humanModeActivated: true,
      message: humanModeMessage
    };
  }

  /**
   * Generate monthly reports for crew and drivers
   */
  async generateMonthlyReport(userPhone, userType) {
    try {
      if (userType === 'crew') {
        return await this.generateCrewReport(userPhone);
      } else if (userType === 'driver') {
        return await this.generateDriverReport(userPhone);
      }
    } catch (error) {
      console.error('Report generation error:', error);
      throw error;
    }
  }

  async generateCrewReport(crewPhone) {
    const bookings = await this.getCrewBookings(crewPhone, 'last_month');
    
    return {
      totalRides: bookings.length,
      totalSpent: bookings.reduce((sum, b) => sum + b.price, 0),
      averageRidePrice: bookings.length > 0 ? bookings.reduce((sum, b) => sum + b.price, 0) / bookings.length : 0,
      favoritePickupLocation: this.getMostFrequentLocation(bookings, 'pickup'),
      favoriteDriver: this.getMostFrequentDriver(bookings),
      onTimePercentage: this.calculateOnTimePercentage(bookings),
      totalSavings: bookings.reduce((sum, b) => sum + (b.careemPrice - b.crewCabPrice), 0),
      rideHistory: bookings.map(b => ({
        date: b.date,
        pickup: b.pickupLocation,
        destination: b.destination,
        price: b.price,
        driver: b.driverName,
        rating: b.rating
      }))
    };
  }

  // Helper methods
  async getAvailableDrivers(rideRequest) {
    // Mock implementation - get drivers in area
    return [
      { phoneNumber: '+971509876543', name: 'Ahmed Hassan', rating: 4.8 },
      { phoneNumber: '+971501111111', name: 'Mohammed Ali', rating: 4.9 }
    ];
  }

  async sendDriverMessage(phoneNumber, message) {
    console.log(`📱 [DRIVER ${phoneNumber}]: ${message}`);
    // In production, use WhatsApp API
    return true;
  }

  async sendCrewMessage(phoneNumber, message) {
    console.log(`📱 [CREW ${phoneNumber}]: ${message}`);
    // In production, use WhatsApp API
    return true;
  }

  calculateBundlePrice(flightCount) {
    const individualPrice = flightCount * 60; // AED 60 per ride
    return Math.floor(individualPrice * 0.9); // 10% discount
  }

  // Additional helper methods would be implemented here...
}

module.exports = new SmartDispatcherService();