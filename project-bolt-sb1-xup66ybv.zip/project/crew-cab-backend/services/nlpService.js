// Basic NLP Service for Crew Cab AI Chatbot

class NLPService {
  constructor() {
    this.aviationTerms = this.initializeAviationTerms();
    this.locationAliases = this.initializeLocationAliases();
    this.timePatterns = this.initializeTimePatterns();
    this.intentClassifiers = this.initializeIntentClassifiers();
  }

  initializeAviationTerms() {
    return {
      airlines: ['emirates', 'etihad', 'flydubai', 'qatar airways', 'turkish airlines'],
      airports: ['dxb', 'dubai airport', 'terminal 1', 'terminal 2', 'terminal 3', 'emirates hq'],
      crewTerms: ['crew', 'cabin crew', 'flight attendant', 'purser', 'crew member'],
      flightTerms: ['flight', 'departure', 'arrival', 'layover', 'turnaround', 'roster', 'schedule']
    };
  }

  initializeLocationAliases() {
    return {
      'marina': ['dubai marina', 'marina', 'jbr', 'jumeirah beach residence'],
      'downtown': ['downtown dubai', 'downtown', 'burj khalifa', 'dubai mall'],
      'deira': ['deira', 'gold souk', 'spice souk', 'bur dubai'],
      'jumeirah': ['jumeirah', 'jumeirah beach', 'umm suqeim'],
      'business_bay': ['business bay', 'bay area'],
      'jlt': ['jlt', 'jumeirah lakes towers', 'lakes'],
      'emirates_hq': ['emirates hq', 'headquarters', 'hq', 'office', 'work'],
      'home': ['home', 'my place', 'house', 'apartment']
    };
  }

  initializeTimePatterns() {
    return [
      { pattern: /(\d{1,2}):(\d{2})\s*(am|pm)/i, type: 'standard_12h' },
      { pattern: /(\d{1,2}):(\d{2})/i, type: 'standard_24h' },
      { pattern: /(\d{1,2})\s*(am|pm)/i, type: 'hour_only' }
    ];
  }

  initializeIntentClassifiers() {
    return {
      booking_request: {
        keywords: ['pickup', 'ride', 'book', 'need', 'want', 'flight', 'airport'],
        patterns: [
          /pick.*up.*from/i,
          /need.*ride/i,
          /book.*ride/i,
          /going.*airport/i,
          /flight.*tomorrow/i,
          /can you.*pick/i
        ],
        confidence: 0.8
      }
    };
  }

  async processMessage(message, context = {}) {
    try {
      const analysis = {
        originalMessage: message,
        normalizedMessage: this.normalizeMessage(message),
        intents: this.detectIntents(message),
        entities: this.extractEntities(message, context),
        sentiment: this.analyzeSentiment(message),
        confidence: 0.8
      };

      return analysis;
    } catch (error) {
      console.error('NLP processing error:', error);
      return this.getDefaultAnalysis(message);
    }
  }

  normalizeMessage(message) {
    return message
      .toLowerCase()
      .trim()
      .replace(/[^\w\s:]/g, ' ')
      .replace(/\s+/g, ' ');
  }

  detectIntents(message) {
    const detectedIntents = [];
    const normalizedMessage = this.normalizeMessage(message);

    for (const [intentName, classifier] of Object.entries(this.intentClassifiers)) {
      let score = 0;
      let matches = [];

      const keywordMatches = classifier.keywords.filter(keyword => 
        normalizedMessage.includes(keyword)
      );
      score += keywordMatches.length * 0.3;

      for (const pattern of classifier.patterns) {
        const match = message.match(pattern);
        if (match) {
          score += 0.5;
          matches.push({
            pattern: pattern.toString(),
            match: match[0],
            groups: match.slice(1)
          });
        }
      }

      score *= classifier.confidence;

      if (score > 0.3) {
        detectedIntents.push({
          intent: intentName,
          confidence: Math.min(score, 1.0),
          matches,
          keywords: keywordMatches
        });
      }
    }

    return detectedIntents.sort((a, b) => b.confidence - a.confidence);
  }

  extractEntities(message, context = {}) {
    const entities = {};

    entities.time = this.extractTimeEntities(message, context);
    entities.location = this.extractLocationEntities(message, context);
    entities.date = this.extractDateEntities(message);

    return entities;
  }

  extractTimeEntities(message, context) {
    const timeEntities = [];

    for (const timePattern of this.timePatterns) {
      const match = message.match(timePattern.pattern);
      if (match) {
        let timeValue = null;

        switch (timePattern.type) {
          case 'standard_12h':
            timeValue = this.parseStandard12Hour(match);
            break;
          case 'standard_24h':
            timeValue = this.parseStandard24Hour(match);
            break;
          case 'hour_only':
            timeValue = this.parseHourOnly(match);
            break;
        }

        if (timeValue) {
          timeEntities.push({
            value: timeValue,
            raw: match[0],
            type: timePattern.type,
            confidence: 0.9
          });
        }
      }
    }

    return timeEntities;
  }

  extractLocationEntities(message, context) {
    const locationEntities = [];
    const normalizedMessage = this.normalizeMessage(message);

    for (const [location, aliases] of Object.entries(this.locationAliases)) {
      for (const alias of aliases) {
        if (normalizedMessage.includes(alias.toLowerCase())) {
          locationEntities.push({
            value: location,
            raw: alias,
            normalized: location,
            confidence: 0.9
          });
        }
      }
    }

    return locationEntities;
  }

  extractDateEntities(message) {
    const dateEntities = [];
    const datePatterns = [
      { pattern: /tomorrow|tmr/i, value: 'tomorrow' },
      { pattern: /today/i, value: 'today' },
      { pattern: /tonight/i, value: 'tonight' }
    ];

    for (const datePattern of datePatterns) {
      const match = message.match(datePattern.pattern);
      if (match) {
        dateEntities.push({
          value: datePattern.value,
          raw: match[0],
          type: 'relative',
          confidence: 0.85
        });
      }
    }

    return dateEntities;
  }

  analyzeSentiment(message) {
    const positiveWords = ['good', 'great', 'excellent', 'perfect', 'thanks', 'please'];
    const negativeWords = ['bad', 'terrible', 'wrong', 'problem', 'issue', 'cancel'];

    const normalizedMessage = this.normalizeMessage(message);
    
    let positiveScore = 0;
    let negativeScore = 0;

    for (const word of positiveWords) {
      if (normalizedMessage.includes(word)) positiveScore++;
    }

    for (const word of negativeWords) {
      if (normalizedMessage.includes(word)) negativeScore++;
    }

    let sentiment = 'neutral';
    if (positiveScore > negativeScore) sentiment = 'positive';
    else if (negativeScore > positiveScore) sentiment = 'negative';

    return {
      sentiment,
      positiveScore,
      negativeScore,
      confidence: Math.min((Math.abs(positiveScore - negativeScore) + 1) / 5, 1)
    };
  }

  parseStandard12Hour(match) {
    const hour = parseInt(match[1]);
    const minute = parseInt(match[2]);
    const period = match[3]?.toLowerCase();

    let adjustedHour = hour;
    if (period === 'pm' && hour !== 12) adjustedHour += 12;
    if (period === 'am' && hour === 12) adjustedHour = 0;

    return `${adjustedHour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
  }

  parseStandard24Hour(match) {
    const hour = parseInt(match[1]);
    const minute = parseInt(match[2]);
    return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
  }

  parseHourOnly(match) {
    const hour = parseInt(match[1]);
    const period = match[2]?.toLowerCase();

    let adjustedHour = hour;
    if (period === 'pm' && hour !== 12) adjustedHour += 12;
    if (period === 'am' && hour === 12) adjustedHour = 0;

    return `${adjustedHour.toString().padStart(2, '0')}:00`;
  }

  getDefaultAnalysis(message) {
    return {
      originalMessage: message,
      normalizedMessage: this.normalizeMessage(message),
      intents: [],
      entities: { time: [], location: [], date: [] },
      sentiment: { sentiment: 'neutral', confidence: 0.5 },
      confidence: 0.3
    };
  }
}

module.exports = new NLPService();