// Emotional Intelligence & Sentiment Analysis Service

class EmotionalIntelligenceService {
  constructor() {
    this.emotionPatterns = new Map();
    this.stressIndicators = new Map();
    this.satisfactionMetrics = new Map();
    this.communicationStyles = new Map();
  }

  /**
   * Analyze emotional state from message content and context
   */
  async analyzeEmotionalState(phoneNumber, message, context = {}) {
    try {
      const analysis = {
        primaryEmotion: 'neutral',
        emotionIntensity: 0.5,
        stressLevel: 'low',
        urgency: 'normal',
        satisfaction: 'neutral',
        communicationStyle: 'professional',
        recommendations: []
      };

      // Analyze text for emotional indicators
      const textAnalysis = this.analyzeTextEmotions(message);
      
      // Consider contextual factors
      const contextualAnalysis = this.analyzeContextualEmotions(context);
      
      // Combine analyses
      analysis.primaryEmotion = textAnalysis.emotion;
      analysis.emotionIntensity = textAnalysis.intensity;
      analysis.stressLevel = this.calculateStressLevel(textAnalysis, contextualAnalysis);
      analysis.urgency = this.calculateUrgency(textAnalysis, context);
      
      // Generate appropriate response strategy
      analysis.recommendations = this.generateEmotionalResponse(analysis);
      
      // Store for learning
      this.storeEmotionalData(phoneNumber, analysis);
      
      return analysis;
    } catch (error) {
      console.error('Emotional analysis error:', error);
      return this.getDefaultEmotionalState();
    }
  }

  /**
   * Analyze text for emotional indicators
   */
  analyzeTextEmotions(message) {
    const lowerMessage = message.toLowerCase();
    
    // Stress indicators
    const stressWords = ['urgent', 'emergency', 'asap', 'quickly', 'rush', 'late', 'delayed', 'problem', 'issue', 'help'];
    const stressCount = stressWords.filter(word => lowerMessage.includes(word)).length;
    
    // Positive indicators
    const positiveWords = ['thanks', 'thank you', 'great', 'perfect', 'excellent', 'good', 'amazing', 'wonderful'];
    const positiveCount = positiveWords.filter(word => lowerMessage.includes(word)).length;
    
    // Negative indicators
    const negativeWords = ['bad', 'terrible', 'awful', 'horrible', 'disappointed', 'frustrated', 'angry', 'upset'];
    const negativeCount = negativeWords.filter(word => lowerMessage.includes(word)).length;
    
    // Fatigue indicators (common for crew)
    const fatigueWords = ['tired', 'exhausted', 'long flight', 'jet lag', 'sleepy', 'worn out'];
    const fatigueCount = fatigueWords.filter(word => lowerMessage.includes(word)).length;
    
    // Determine primary emotion
    let emotion = 'neutral';
    let intensity = 0.5;
    
    if (stressCount > 0) {
      emotion = 'stressed';
      intensity = Math.min(0.3 + (stressCount * 0.2), 1.0);
    } else if (fatigueCount > 0) {
      emotion = 'fatigued';
      intensity = Math.min(0.4 + (fatigueCount * 0.2), 1.0);
    } else if (positiveCount > negativeCount) {
      emotion = 'positive';
      intensity = Math.min(0.6 + (positiveCount * 0.1), 1.0);
    } else if (negativeCount > 0) {
      emotion = 'negative';
      intensity = Math.min(0.4 + (negativeCount * 0.2), 1.0);
    }
    
    return { emotion, intensity, stressCount, positiveCount, negativeCount, fatigueCount };
  }

  /**
   * Analyze contextual emotional factors
   */
  analyzeContextualEmotions(context) {
    const factors = {
      timeStress: 0,
      frequencyStress: 0,
      historyStress: 0
    };
    
    // Time-based stress (early morning, late night)
    if (context.requestTime) {
      const hour = new Date(context.requestTime).getHours();
      if (hour >= 3 && hour <= 6) factors.timeStress = 0.3; // Early morning stress
      if (hour >= 22 || hour <= 2) factors.timeStress = 0.2; // Late night fatigue
    }
    
    // Frequency stress (multiple requests in short time)
    if (context.recentRequests > 3) {
      factors.frequencyStress = 0.4;
    }
    
    // Historical stress patterns
    if (context.previousCancellations > 2) {
      factors.historyStress = 0.3;
    }
    
    return factors;
  }

  /**
   * Calculate overall stress level
   */
  calculateStressLevel(textAnalysis, contextualAnalysis) {
    const textStress = textAnalysis.stressCount * 0.2;
    const contextStress = Object.values(contextualAnalysis).reduce((sum, val) => sum + val, 0);
    const totalStress = textStress + contextStress;
    
    if (totalStress > 0.7) return 'high';
    if (totalStress > 0.4) return 'medium';
    return 'low';
  }

  /**
   * Calculate urgency level
   */
  calculateUrgency(textAnalysis, context) {
    if (textAnalysis.stressCount > 2) return 'high';
    if (context.flightDeparture && this.isFlightSoon(context.flightDeparture)) return 'high';
    if (textAnalysis.stressCount > 0) return 'medium';
    return 'normal';
  }

  /**
   * Generate emotionally appropriate response strategy
   */
  generateEmotionalResponse(analysis) {
    const recommendations = [];
    
    switch (analysis.primaryEmotion) {
      case 'stressed':
        recommendations.push('Use calm, reassuring language');
        recommendations.push('Provide immediate confirmation and timeline');
        recommendations.push('Offer additional support options');
        recommendations.push('Prioritize this request');
        break;
        
      case 'fatigued':
        recommendations.push('Keep responses brief and clear');
        recommendations.push('Minimize follow-up questions');
        recommendations.push('Offer comfort-focused options');
        recommendations.push('Suggest quiet ride preferences');
        break;
        
      case 'positive':
        recommendations.push('Match positive energy in response');
        recommendations.push('Offer premium service options');
        recommendations.push('Ask for feedback/referrals');
        break;
        
      case 'negative':
        recommendations.push('Acknowledge concerns empathetically');
        recommendations.push('Provide extra assurance');
        recommendations.push('Offer compensation if appropriate');
        recommendations.push('Follow up after service');
        break;
        
      default:
        recommendations.push('Maintain professional, friendly tone');
        recommendations.push('Provide clear, efficient service');
    }
    
    // Add urgency-based recommendations
    if (analysis.urgency === 'high') {
      recommendations.push('Expedite processing');
      recommendations.push('Assign best available driver');
      recommendations.push('Send immediate confirmation');
    }
    
    return recommendations;
  }

  /**
   * Generate emotionally intelligent response text
   */
  generateEmotionallyIntelligentResponse(message, analysis) {
    const baseResponse = message;
    let enhancedResponse = baseResponse;
    
    // Add emotional intelligence based on analysis
    switch (analysis.primaryEmotion) {
      case 'stressed':
        enhancedResponse = `🤗 I understand this is urgent. ${baseResponse}\n\n✅ Don't worry - I'll make sure everything is handled quickly and smoothly.`;
        break;
        
      case 'fatigued':
        enhancedResponse = `😌 ${baseResponse}\n\n💤 I'll keep this simple and get you sorted quickly so you can rest.`;
        break;
        
      case 'positive':
        enhancedResponse = `😊 ${baseResponse}\n\n🌟 It's great to help such a positive customer!`;
        break;
        
      case 'negative':
        enhancedResponse = `🙏 I understand your concerns. ${baseResponse}\n\n💪 I'm here to make sure we exceed your expectations this time.`;
        break;
    }
    
    // Add urgency handling
    if (analysis.urgency === 'high') {
      enhancedResponse += `\n\n⚡ **PRIORITY REQUEST** - Processing immediately.`;
    }
    
    return enhancedResponse;
  }

  /**
   * Crew-specific emotional intelligence
   */
  async analyzeCrewEmotionalState(crewPhone, message, flightContext) {
    try {
      const baseAnalysis = await this.analyzeEmotionalState(crewPhone, message);
      
      // Add crew-specific factors
      const crewFactors = {
        jetLagLevel: this.calculateJetLag(flightContext),
        workloadStress: this.calculateWorkloadStress(flightContext),
        scheduleDisruption: this.calculateScheduleDisruption(flightContext)
      };
      
      // Adjust analysis for crew-specific factors
      if (crewFactors.jetLagLevel > 0.5) {
        baseAnalysis.primaryEmotion = 'fatigued';
        baseAnalysis.recommendations.push('Suggest quiet ride');
        baseAnalysis.recommendations.push('Minimize conversation');
      }
      
      if (crewFactors.workloadStress > 0.7) {
        baseAnalysis.stressLevel = 'high';
        baseAnalysis.recommendations.push('Expedite service');
        baseAnalysis.recommendations.push('Assign most reliable driver');
      }
      
      return {
        ...baseAnalysis,
        crewFactors,
        specialConsiderations: this.generateCrewConsiderations(crewFactors)
      };
    } catch (error) {
      console.error('Crew emotional analysis error:', error);
      return this.getDefaultEmotionalState();
    }
  }

  /**
   * Real-time satisfaction monitoring
   */
  async monitorSatisfaction(phoneNumber, interactionHistory) {
    try {
      const satisfactionTrend = this.calculateSatisfactionTrend(interactionHistory);
      const riskFactors = this.identifyRiskFactors(interactionHistory);
      const interventions = this.suggestInterventions(satisfactionTrend, riskFactors);
      
      return {
        currentSatisfaction: satisfactionTrend.current,
        trend: satisfactionTrend.direction,
        riskLevel: this.calculateRiskLevel(riskFactors),
        recommendedInterventions: interventions,
        confidence: 0.84
      };
    } catch (error) {
      console.error('Satisfaction monitoring error:', error);
      throw error;
    }
  }

  // Helper methods
  calculateJetLag(flightContext) {
    if (!flightContext.lastFlight) return 0;
    
    const timezoneChange = flightContext.lastFlight.timezoneChange || 0;
    const hoursSinceLanding = flightContext.lastFlight.hoursSinceLanding || 0;
    
    if (Math.abs(timezoneChange) > 6 && hoursSinceLanding < 24) {
      return 0.8;
    } else if (Math.abs(timezoneChange) > 3 && hoursSinceLanding < 12) {
      return 0.6;
    }
    
    return 0.2;
  }

  calculateWorkloadStress(flightContext) {
    const flightsThisWeek = flightContext.flightsThisWeek || 0;
    const hoursThisWeek = flightContext.hoursThisWeek || 0;
    
    if (flightsThisWeek > 8 || hoursThisWeek > 60) return 0.9;
    if (flightsThisWeek > 6 || hoursThisWeek > 45) return 0.7;
    if (flightsThisWeek > 4 || hoursThisWeek > 30) return 0.5;
    
    return 0.3;
  }

  isFlightSoon(flightTime) {
    const now = new Date();
    const flight = new Date(flightTime);
    const hoursUntilFlight = (flight - now) / (1000 * 60 * 60);
    
    return hoursUntilFlight < 3; // Less than 3 hours
  }

  storeEmotionalData(phoneNumber, analysis) {
    const existing = this.emotionPatterns.get(phoneNumber) || [];
    existing.push({
      timestamp: new Date(),
      analysis
    });
    
    // Keep only last 50 interactions
    if (existing.length > 50) {
      existing.splice(0, existing.length - 50);
    }
    
    this.emotionPatterns.set(phoneNumber, existing);
  }

  getDefaultEmotionalState() {
    return {
      primaryEmotion: 'neutral',
      emotionIntensity: 0.5,
      stressLevel: 'low',
      urgency: 'normal',
      satisfaction: 'neutral',
      communicationStyle: 'professional',
      recommendations: ['Maintain professional, friendly tone']
    };
  }
}

module.exports = new EmotionalIntelligenceService();