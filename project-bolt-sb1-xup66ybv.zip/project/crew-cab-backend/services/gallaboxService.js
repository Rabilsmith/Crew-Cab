// Gallabox WhatsApp API Integration Service

class GallaboxService {
  constructor() {
    this.apiUrl = process.env.GALLABOX_API_URL || 'https://server.gallabox.com/devapi';
    this.apiKey = process.env.GALLABOX_API_KEY;
    this.secretKey = process.env.GALLABOX_SECRET_KEY;
    this.channelId = process.env.GALLABOX_CHANNEL_ID;
    this.headers = {
      'apikey': this.apiKey,
      'secretkey': this.secretKey,
      'Content-Type': 'application/json'
    };
  }

  /**
   * Send WhatsApp message via Gallabox
   */
  async sendMessage(phoneNumber, message, messageType = 'text') {
    try {
      console.log(`📱 Sending via Gallabox to ${phoneNumber}: ${message}`);
      
      const payload = {
        channelId: this.channelId,
        channelType: "whatsapp",
        recipient: this.formatPhoneNumber(phoneNumber),
        message: {
          type: messageType,
          text: message
        }
      };

      const response = await fetch(`${this.apiUrl}/message/sendMessage`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`Gallabox API error: ${response.status} - ${response.statusText}`);
      }

      const result = await response.json();
      console.log('✅ Message sent successfully via Gallabox:', result);
      
      return {
        success: true,
        messageId: result.messageId,
        status: result.status
      };
    } catch (error) {
      console.error('❌ Gallabox send error:', error);
      throw error;
    }
  }

  /**
   * Send template message via Gallabox
   */
  async sendTemplateMessage(phoneNumber, templateName, templateParams = []) {
    try {
      const payload = {
        channelId: this.channelId,
        channelType: "whatsapp",
        recipient: this.formatPhoneNumber(phoneNumber),
        message: {
          type: "template",
          template: {
            name: templateName,
            language: {
              code: "en"
            },
            components: templateParams.length > 0 ? [
              {
                type: "body",
                parameters: templateParams.map(param => ({
                  type: "text",
                  text: param
                }))
              }
            ] : []
          }
        }
      };

      const response = await fetch(`${this.apiUrl}/message/sendMessage`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`Gallabox template error: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Template message error:', error);
      throw error;
    }
  }

  /**
   * Handle incoming webhook from Gallabox
   */
  async handleWebhook(req, res) {
    try {
      const webhookData = req.body;
      console.log('📱 Gallabox webhook received:', JSON.stringify(webhookData, null, 2));

      // Verify webhook signature if needed
      if (!this.verifyWebhookSignature(req)) {
        return res.status(401).json({ error: 'Invalid webhook signature' });
      }

      // Process different webhook events
      if (webhookData.type === 'message') {
        await this.processIncomingMessage(webhookData);
      } else if (webhookData.type === 'status') {
        await this.processMessageStatus(webhookData);
      }

      res.status(200).json({ success: true });
    } catch (error) {
      console.error('❌ Webhook processing error:', error);
      res.status(500).json({ error: 'Webhook processing failed' });
    }
  }

  /**
   * Process incoming message from WhatsApp
   */
  async processIncomingMessage(webhookData) {
    try {
      const message = webhookData.message;
      const phoneNumber = this.extractPhoneNumber(webhookData.sender);
      
      if (!message || !phoneNumber) {
        console.log('⚠️ Invalid message data received');
        return;
      }

      let messageText = '';
      let messageType = message.type;

      // Extract message content based on type
      switch (messageType) {
        case 'text':
          messageText = message.text;
          break;
        case 'image':
          messageText = message.caption || 'Image received';
          await this.handleImageMessage(phoneNumber, message);
          break;
        case 'document':
          messageText = message.caption || 'Document received';
          break;
        case 'audio':
          messageText = 'Voice message received';
          await this.handleVoiceMessage(phoneNumber, message);
          break;
        default:
          messageText = `${messageType} message received`;
      }

      console.log(`📱 Processing message from ${phoneNumber}: ${messageText}`);

      // Process with AI chatbot
      const aiChatbotService = require('./aiChatbotService');
      const response = await aiChatbotService.processMessage(phoneNumber, messageText);

      // Send response back
      if (response) {
        await this.sendMessage(phoneNumber, response);
      }

    } catch (error) {
      console.error('Error processing incoming message:', error);
    }
  }

  /**
   * Handle image messages (roster uploads)
   */
  async handleImageMessage(phoneNumber, message) {
    try {
      const imageUrl = message.url;
      console.log(`📸 Image received from ${phoneNumber}: ${imageUrl}`);

      // Process roster if it's an image upload
      const rosterIntelligenceService = require('./rosterIntelligenceService');
      const result = await rosterIntelligenceService.processRosterUpload(phoneNumber, imageUrl);

      if (result.success) {
        await this.sendMessage(phoneNumber, result.message);
      } else {
        await this.sendMessage(phoneNumber, "I had trouble processing your image. Please try uploading a clearer photo.");
      }
    } catch (error) {
      console.error('Image processing error:', error);
    }
  }

  /**
   * Handle voice messages
   */
  async handleVoiceMessage(phoneNumber, message) {
    try {
      const audioUrl = message.url;
      console.log(`🎤 Voice message received from ${phoneNumber}: ${audioUrl}`);

      // Process voice note
      const voiceProcessingService = require('./voiceProcessingService');
      const result = await voiceProcessingService.processVoiceBooking(phoneNumber, audioUrl);

      if (result.success) {
        await this.sendMessage(phoneNumber, result.response);
      } else {
        await this.sendMessage(phoneNumber, result.message);
      }
    } catch (error) {
      console.error('Voice processing error:', error);
    }
  }

  /**
   * Process message status updates
   */
  async processMessageStatus(webhookData) {
    try {
      const status = webhookData.status;
      const messageId = webhookData.messageId;
      
      console.log(`📊 Message ${messageId} status: ${status}`);
      
      // Track message delivery status
      // You can store this in database for analytics
    } catch (error) {
      console.error('Status processing error:', error);
    }
  }

  /**
   * Verify webhook signature (implement based on Gallabox documentation)
   */
  verifyWebhookSignature(req) {
    // Implement signature verification if Gallabox provides it
    // For now, return true (you should implement proper verification)
    return true;
  }

  /**
   * Format phone number for Gallabox API
   */
  formatPhoneNumber(phoneNumber) {
    // Remove any non-digit characters except +
    let formatted = phoneNumber.replace(/[^\d+]/g, '');
    
    // Ensure it starts with +
    if (!formatted.startsWith('+')) {
      formatted = '+' + formatted;
    }
    
    return formatted;
  }

  /**
   * Extract phone number from webhook data
   */
  extractPhoneNumber(sender) {
    if (typeof sender === 'string') {
      return sender;
    } else if (sender && sender.phone) {
      return sender.phone;
    } else if (sender && sender.id) {
      return sender.id;
    }
    return null;
  }

  /**
   * Get contact info from Gallabox
   */
  async getContactInfo(phoneNumber) {
    try {
      const response = await fetch(`${this.apiUrl}/contact/getContact`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify({
          channelId: this.channelId,
          phone: this.formatPhoneNumber(phoneNumber)
        })
      });

      if (response.ok) {
        return await response.json();
      }
    } catch (error) {
      console.error('Error getting contact info:', error);
    }
    return null;
  }

  /**
   * Send media message
   */
  async sendMediaMessage(phoneNumber, mediaUrl, mediaType, caption = '') {
    try {
      const payload = {
        channelId: this.channelId,
        channelType: "whatsapp",
        recipient: this.formatPhoneNumber(phoneNumber),
        message: {
          type: mediaType,
          [mediaType]: {
            url: mediaUrl,
            caption: caption
          }
        }
      };

      const response = await fetch(`${this.apiUrl}/message/sendMessage`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify(payload)
      });

      return await response.json();
    } catch (error) {
      console.error('Media message error:', error);
      throw error;
    }
  }

  /**
   * Test connection to Gallabox API
   */
  async testConnection() {
    try {
      const response = await fetch(`${this.apiUrl}/channel/getChannels`, {
        method: 'GET',
        headers: this.headers
      });

      if (response.ok) {
        const data = await response.json();
        console.log('✅ Gallabox connection successful:', data);
        return { success: true, data };
      } else {
        throw new Error(`Connection failed: ${response.status}`);
      }
    } catch (error) {
      console.error('❌ Gallabox connection test failed:', error);
      return { success: false, error: error.message };
    }
  }
}

module.exports = new GallaboxService();