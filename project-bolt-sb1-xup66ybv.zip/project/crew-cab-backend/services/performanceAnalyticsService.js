// Performance Analytics & Learning Service

class PerformanceAnalyticsService {
  constructor() {
    this.driverMetrics = new Map();
    this.crewMetrics = new Map();
    this.systemMetrics = new Map();
    this.learningPatterns = new Map();
    this.alertThresholds = this.initializeAlertThresholds();
  }

  initializeAlertThresholds() {
    return {
      driver: {
        lateIncidents: 2, // Auto-block after 2 late incidents
        cancellationRate: 0.15, // 15% cancellation rate threshold
        ratingThreshold: 4.0, // Minimum rating
        responseTime: 300000 // 5 minutes max response time
      },
      system: {
        aiAccuracy: 0.85, // 85% minimum AI accuracy
        bookingSuccess: 0.90, // 90% booking success rate
        averageResponseTime: 2000 // 2 seconds max response time
      }
    };
  }

  /**
   * Track driver performance in real-time
   */
  async trackDriverPerformance(driverPhone, event) {
    try {
      const metrics = this.driverMetrics.get(driverPhone) || this.initializeDriverMetrics();
      
      switch (event.type) {
        case 'ride_accepted':
          metrics.totalRideOffers++;
          metrics.acceptanceRate = metrics.ridesAccepted / metrics.totalRideOffers;
          metrics.lastActivity = new Date();
          break;
          
        case 'ride_completed':
          metrics.ridesCompleted++;
          metrics.totalEarnings += event.payout;
          metrics.completionRate = metrics.ridesCompleted / metrics.ridesAccepted;
          await this.checkPunctuality(driverPhone, event);
          break;
          
        case 'ride_cancelled':
          metrics.ridesCancelled++;
          metrics.cancellationRate = metrics.ridesCancelled / metrics.ridesAccepted;
          await this.handleDriverCancellation(driverPhone, event);
          break;
          
        case 'late_pickup':
          metrics.lateIncidents++;
          metrics.onTimePercentage = ((metrics.ridesCompleted - metrics.lateIncidents) / metrics.ridesCompleted) * 100;
          await this.handleLateIncident(driverPhone, event);
          break;
          
        case 'rating_received':
          this.updateDriverRating(metrics, event.rating);
          break;
      }
      
      // Update metrics
      this.driverMetrics.set(driverPhone, metrics);
      
      // Check for automatic actions
      await this.checkDriverThresholds(driverPhone, metrics);
      
      return metrics;
    } catch (error) {
      console.error('Driver performance tracking error:', error);
      throw error;
    }
  }

  /**
   * Handle late pickup incidents with automatic blocking
   */
  async handleLateIncident(driverPhone, event) {
    const metrics = this.driverMetrics.get(driverPhone);
    const minutesLate = event.minutesLate || 0;
    
    console.log(`⚠️ Late incident: Driver ${driverPhone} was ${minutesLate} minutes late`);
    
    // Record incident details
    metrics.lateIncidentHistory = metrics.lateIncidentHistory || [];
    metrics.lateIncidentHistory.push({
      date: new Date(),
      minutesLate,
      rideId: event.rideId,
      reason: event.reason || 'Not specified'
    });
    
    // Check for auto-blocking (2+ incidents in 30 days)
    const recentIncidents = metrics.lateIncidentHistory.filter(incident => 
      (new Date() - incident.date) <= (30 * 24 * 60 * 60 * 1000) // 30 days
    );
    
    if (recentIncidents.length >= this.alertThresholds.driver.lateIncidents) {
      await this.autoBlockDriver(driverPhone, 'Multiple late incidents');
    } else {
      // Send warning
      await this.sendDriverWarning(driverPhone, recentIncidents.length);
    }
  }

  /**
   * Automatically block driver for poor performance
   */
  async autoBlockDriver(driverPhone, reason) {
    try {
      console.log(`🚫 Auto-blocking driver ${driverPhone}: ${reason}`);
      
      const metrics = this.driverMetrics.get(driverPhone);
      metrics.isBlocked = true;
      metrics.blockReason = reason;
      metrics.blockedAt = new Date();
      
      // Send notification to driver
      const message = `🚫 *Account Temporarily Suspended*\n\n` +
        `Reason: ${reason}\n\n` +
        `Your account has been temporarily suspended due to performance issues. ` +
        `Please contact our support team to discuss reactivation.\n\n` +
        `📞 Support: +971-XXX-XXXX\n` +
        `📧 Email: support@crewcab.ae`;
      
      await this.sendDriverMessage(driverPhone, message);
      
      // Alert admin team
      await this.alertAdminTeam({
        type: 'driver_auto_blocked',
        driverPhone,
        reason,
        metrics: metrics,
        timestamp: new Date()
      });
      
      return true;
    } catch (error) {
      console.error('Auto-block driver error:', error);
      return false;
    }
  }

  /**
   * Send warning to driver about performance
   */
  async sendDriverWarning(driverPhone, incidentCount) {
    const message = `⚠️ *Performance Warning*\n\n` +
      `You have ${incidentCount} late pickup incident(s) in the past 30 days.\n\n` +
      `🚨 **Important**: After 2 late incidents, your account will be automatically suspended.\n\n` +
      `💡 **Tips to improve**:\n` +
      `• Leave 10-15 minutes earlier\n` +
      `• Check traffic conditions before departure\n` +
      `• Contact crew if you'll be late\n\n` +
      `Thank you for maintaining our service quality! 🙏`;
    
    await this.sendDriverMessage(driverPhone, message);
  }

  /**
   * Track AI chatbot performance
   */
  async trackAIPerformance(interaction) {
    try {
      const metrics = this.systemMetrics.get('ai_chatbot') || this.initializeAIMetrics();
      
      metrics.totalInteractions++;
      metrics.lastInteraction = new Date();
      
      // Track intent recognition accuracy
      if (interaction.intentRecognized) {
        metrics.successfulIntentRecognition++;
        metrics.intentAccuracy = metrics.successfulIntentRecognition / metrics.totalInteractions;
      }
      
      // Track booking completion rate
      if (interaction.bookingAttempted) {
        metrics.bookingAttempts++;
        if (interaction.bookingCompleted) {
          metrics.successfulBookings++;
        }
        metrics.bookingSuccessRate = metrics.successfulBookings / metrics.bookingAttempts;
      }
      
      // Track response time
      if (interaction.responseTime) {
        metrics.totalResponseTime += interaction.responseTime;
        metrics.averageResponseTime = metrics.totalResponseTime / metrics.totalInteractions;
      }
      
      // Track user satisfaction
      if (interaction.userSatisfaction) {
        metrics.satisfactionRatings.push(interaction.userSatisfaction);
        metrics.averageSatisfaction = metrics.satisfactionRatings.reduce((a, b) => a + b, 0) / metrics.satisfactionRatings.length;
      }
      
      this.systemMetrics.set('ai_chatbot', metrics);
      
      // Check AI performance thresholds
      await this.checkAIThresholds(metrics);
      
      return metrics;
    } catch (error) {
      console.error('AI performance tracking error:', error);
      throw error;
    }
  }

  /**
   * Generate comprehensive performance reports
   */
  async generatePerformanceReport(type, timeframe = 'weekly') {
    try {
      const endDate = new Date();
      const startDate = new Date();
      
      switch (timeframe) {
        case 'daily':
          startDate.setDate(endDate.getDate() - 1);
          break;
        case 'weekly':
          startDate.setDate(endDate.getDate() - 7);
          break;
        case 'monthly':
          startDate.setMonth(endDate.getMonth() - 1);
          break;
      }
      
      if (type === 'driver') {
        return await this.generateDriverReport(startDate, endDate);
      } else if (type === 'system') {
        return await this.generateSystemReport(startDate, endDate);
      } else if (type === 'ai') {
        return await this.generateAIReport(startDate, endDate);
      }
    } catch (error) {
      console.error('Performance report generation error:', error);
      throw error;
    }
  }

  /**
   * Generate driver performance report
   */
  async generateDriverReport(startDate, endDate) {
    const report = {
      timeframe: { startDate, endDate },
      totalDrivers: this.driverMetrics.size,
      activeDrivers: 0,
      blockedDrivers: 0,
      topPerformers: [],
      performanceIssues: [],
      averageMetrics: {
        rating: 0,
        onTimePercentage: 0,
        completionRate: 0,
        responseTime: 0
      }
    };
    
    const allMetrics = Array.from(this.driverMetrics.values());
    
    // Calculate aggregated metrics
    report.activeDrivers = allMetrics.filter(m => !m.isBlocked).length;
    report.blockedDrivers = allMetrics.filter(m => m.isBlocked).length;
    
    if (allMetrics.length > 0) {
      report.averageMetrics.rating = allMetrics.reduce((sum, m) => sum + m.rating, 0) / allMetrics.length;
      report.averageMetrics.onTimePercentage = allMetrics.reduce((sum, m) => sum + m.onTimePercentage, 0) / allMetrics.length;
      report.averageMetrics.completionRate = allMetrics.reduce((sum, m) => sum + m.completionRate, 0) / allMetrics.length;
    }
    
    // Identify top performers
    report.topPerformers = allMetrics
      .filter(m => !m.isBlocked)
      .sort((a, b) => (b.rating + b.onTimePercentage + b.completionRate) - (a.rating + a.onTimePercentage + a.completionRate))
      .slice(0, 5)
      .map(m => ({
        phone: m.phone,
        rating: m.rating,
        onTimePercentage: m.onTimePercentage,
        completionRate: m.completionRate,
        totalRides: m.ridesCompleted
      }));
    
    // Identify performance issues
    report.performanceIssues = allMetrics
      .filter(m => 
        m.rating < this.alertThresholds.driver.ratingThreshold ||
        m.cancellationRate > this.alertThresholds.driver.cancellationRate ||
        m.lateIncidents >= this.alertThresholds.driver.lateIncidents
      )
      .map(m => ({
        phone: m.phone,
        issues: this.identifyDriverIssues(m),
        severity: this.calculateIssueSeverity(m)
      }));
    
    return report;
  }

  /**
   * Real-time performance monitoring dashboard
   */
  async getRealtimeMetrics() {
    return {
      drivers: {
        total: this.driverMetrics.size,
        active: Array.from(this.driverMetrics.values()).filter(m => !m.isBlocked).length,
        averageRating: this.calculateAverageDriverRating(),
        onTimePercentage: this.calculateAverageOnTimePercentage()
      },
      ai: {
        intentAccuracy: this.getAIMetric('intentAccuracy'),
        bookingSuccessRate: this.getAIMetric('bookingSuccessRate'),
        averageResponseTime: this.getAIMetric('averageResponseTime'),
        totalInteractions: this.getAIMetric('totalInteractions')
      },
      system: {
        uptime: this.calculateSystemUptime(),
        errorRate: this.calculateErrorRate(),
        activeUsers: this.getActiveUserCount()
      }
    };
  }

  /**
   * Predictive analytics for driver performance
   */
  async predictDriverPerformance(driverPhone) {
    const metrics = this.driverMetrics.get(driverPhone);
    if (!metrics) return null;
    
    const prediction = {
      riskLevel: 'low',
      predictedRating: metrics.rating,
      recommendedActions: [],
      confidenceScore: 0.8
    };
    
    // Analyze trends
    if (metrics.lateIncidents > 0) {
      prediction.riskLevel = 'medium';
      prediction.recommendedActions.push('Monitor punctuality closely');
    }
    
    if (metrics.cancellationRate > 0.1) {
      prediction.riskLevel = 'high';
      prediction.recommendedActions.push('Review cancellation patterns');
    }
    
    if (metrics.rating < 4.5) {
      prediction.recommendedActions.push('Provide customer service training');
    }
    
    return prediction;
  }

  // Helper methods
  initializeDriverMetrics() {
    return {
      phone: '',
      totalRideOffers: 0,
      ridesAccepted: 0,
      ridesCompleted: 0,
      ridesCancelled: 0,
      lateIncidents: 0,
      rating: 5.0,
      totalRatings: 0,
      ratingSum: 0,
      acceptanceRate: 0,
      completionRate: 0,
      cancellationRate: 0,
      onTimePercentage: 100,
      totalEarnings: 0,
      averageResponseTime: 0,
      lastActivity: new Date(),
      isBlocked: false,
      blockReason: null,
      lateIncidentHistory: []
    };
  }

  initializeAIMetrics() {
    return {
      totalInteractions: 0,
      successfulIntentRecognition: 0,
      intentAccuracy: 0,
      bookingAttempts: 0,
      successfulBookings: 0,
      bookingSuccessRate: 0,
      totalResponseTime: 0,
      averageResponseTime: 0,
      satisfactionRatings: [],
      averageSatisfaction: 0,
      lastInteraction: new Date()
    };
  }

  updateDriverRating(metrics, newRating) {
    metrics.totalRatings++;
    metrics.ratingSum += newRating;
    metrics.rating = metrics.ratingSum / metrics.totalRatings;
  }

  async checkDriverThresholds(driverPhone, metrics) {
    const issues = [];
    
    if (metrics.cancellationRate > this.alertThresholds.driver.cancellationRate) {
      issues.push('High cancellation rate');
    }
    
    if (metrics.rating < this.alertThresholds.driver.ratingThreshold) {
      issues.push('Low rating');
    }
    
    if (issues.length > 0) {
      await this.alertAdminTeam({
        type: 'driver_performance_alert',
        driverPhone,
        issues,
        metrics,
        timestamp: new Date()
      });
    }
  }

  async sendDriverMessage(phoneNumber, message) {
    console.log(`📱 [DRIVER ${phoneNumber}]: ${message}`);
    // In production, use WhatsApp API
  }

  async alertAdminTeam(alert) {
    console.log('🚨 Admin Alert:', alert);
    // In production, send to admin dashboard/email/Slack
  }

  calculateAverageDriverRating() {
    const metrics = Array.from(this.driverMetrics.values());
    if (metrics.length === 0) return 0;
    return metrics.reduce((sum, m) => sum + m.rating, 0) / metrics.length;
  }

  getAIMetric(metricName) {
    const aiMetrics = this.systemMetrics.get('ai_chatbot');
    return aiMetrics ? aiMetrics[metricName] : 0;
  }
}

module.exports = new PerformanceAnalyticsService();