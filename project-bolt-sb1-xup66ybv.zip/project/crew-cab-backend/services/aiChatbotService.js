const nlpService = require('./nlpService');

class AIChatbotService {
  constructor() {
    this.userContexts = new Map(); // Store conversation contexts
    this.intentPatterns = this.initializeIntentPatterns();
    this.responseTemplates = this.initializeResponseTemplates();
  }

  initializeIntentPatterns() {
    return {
      // Flight booking intents
      flight_booking: [
        /i have a flight (tomorrow|tmr|today)/i,
        /need a ride (tomorrow|tmr|today)/i,
        /pick me up.*flight/i,
        /flight.*pick.*up/i,
        /going to airport/i,
        /airport ride/i
      ],
      
      // Time extraction
      time_extraction: [
        /at (\d{1,2}):?(\d{2})?\s*(am|pm)?/i,
        /(\d{1,2}):(\d{2})\s*(am|pm)?/i,
        /(\d{1,2})\s*(am|pm)/i
      ],
      
      // Location intents
      location_request: [
        /pickup from (.+)/i,
        /from (.+) to/i,
        /at (.+)/i,
        /same place/i,
        /last time/i,
        /home/i,
        /usual place/i
      ],
      
      // Confirmation intents
      confirmation: [
        /yes/i, /yeah/i, /yep/i, /correct/i, /right/i, /ok/i, /okay/i,
        /that's right/i, /exactly/i, /perfect/i, /good/i
      ],
      
      // Negation intents
      negation: [
        /no/i, /nope/i, /not/i, /wrong/i, /different/i, /change/i,
        /not that/i, /somewhere else/i
      ]
    };
  }

  initializeResponseTemplates() {
    return {
      greeting: [
        "Hello! 👋 I'm your Crew Cab assistant. How can I help you today?",
        "Hi there! ✈️ Ready to book your next ride?",
        "Welcome to Crew Cab! 🚗 What can I do for you?"
      ],
      
      flight_detected: [
        "✈️ Got it! Flight {time} {date}. Where should we pick you up from?",
        "Perfect! {time} {date} pickup. What's your pickup location?",
        "Understood! Flight at {time} {date}. Where are you departing from?"
      ],
      
      booking_confirmed: [
        "✅ Perfect! You're all set:\n📍 Pickup: {pickup}\n🕐 Time: {time}\n✈️ Destination: {destination}\n💰 Price: AED {price}",
        "🎉 Booking confirmed!\n{pickup} → {destination}\n{time} | AED {price}",
        "✅ All done! Your ride is booked for {time} from {pickup} to {destination}. AED {price}"
      ]
    };
  }

  async processMessage(phoneNumber, message, userType = null) {
    try {
      console.log(`🤖 Processing message from ${phoneNumber}: ${message}`);
      
      // Get or create user context
      let context = this.getUserContext(phoneNumber);
      
      // Detect user type if not known
      if (!userType) {
        userType = await this.detectUserType(phoneNumber, message);
      }
      
      // Update context
      context.userType = userType;
      context.lastMessage = message;
      context.messageHistory.push({
        message,
        timestamp: new Date(),
        processed: false
      });

      // Handle driver onboarding flow
      if (userType === 'driver' || message.toLowerCase().includes('join driver')) {
        return await this.handleDriverOnboarding(phoneNumber, message, context);
      }

      // Handle crew booking flow
      if (userType === 'crew' || this.isBookingIntent(message)) {
        return await this.handleCrewBooking(phoneNumber, message, context);
      }

      // Default response for unknown intent
      return this.getHelpMessage(userType);
    } catch (error) {
      console.error('🤖 AI Chatbot processing error:', error);
      return this.getErrorResponse();
    }
  }

  /**
   * Handle complete driver onboarding flow
   */
  async handleDriverOnboarding(phoneNumber, message, context) {
    try {
      // Initialize driver onboarding if not started
      if (!context.driverOnboarding) {
        context.driverOnboarding = {
          step: 0,
          data: {},
          startedAt: new Date()
        };
      }

      const onboarding = context.driverOnboarding;
      const lowerMessage = message.toLowerCase().trim();

      // Step 0: Welcome and start onboarding
      if (onboarding.step === 0 || lowerMessage.includes('join driver')) {
        onboarding.step = 1;
        return this.getDriverWelcomeMessage();
      }

      // Step 1: Home Location
      if (onboarding.step === 1) {
        onboarding.data.homeLocation = message.trim();
        onboarding.step = 2;
        return this.getWorkingHoursMessage();
      }

      // Step 2: Working Hours
      if (onboarding.step === 2) {
        onboarding.data.workingHours = message.trim();
        onboarding.step = 3;
        return this.getFrequentRoutesMessage();
      }

      // Step 3: Frequent Routes
      if (onboarding.step === 3) {
        onboarding.data.frequentRoutes = this.parseFrequentRoutes(message);
        onboarding.step = 4;
        return this.getMaxPickupsMessage();
      }

      // Step 4: Max Simultaneous Pickups
      if (onboarding.step === 4) {
        const maxPickups = this.parseMaxPickups(message);
        if (maxPickups) {
          onboarding.data.maxPickups = maxPickups;
          onboarding.step = 5;
          return this.getBehaviorPolicyMessage();
        } else {
          return "Please enter a number between 1 and 3 for maximum pickups.";
        }
      }

      // Step 5: Behavior Policy Acknowledgment
      if (onboarding.step === 5) {
        if (lowerMessage.includes('agree') || lowerMessage.includes('yes') || lowerMessage.includes('understood')) {
          onboarding.data.policyAgreed = true;
          onboarding.step = 6;
          return await this.completeDriverOnboarding(phoneNumber, onboarding.data);
        } else {
          return "Please type 'I agree' to acknowledge our behavior and trust policy.";
        }
      }

      // Step 6: Completed
      if (onboarding.step === 6) {
        return this.getDriverHelpMessage();
      }

      return "I didn't understand. Could you please respond to the current question?";
    } catch (error) {
      console.error('Driver onboarding error:', error);
      return "Sorry, there was an error with the onboarding process. Please try again.";
    }
  }

  /**
   * Handle crew booking flow
   */
  async handleCrewBooking(phoneNumber, message, context) {
    try {
      // Initialize booking if not started
      if (!context.currentBooking) {
        context.currentBooking = {};
      }

      const booking = context.currentBooking;
      const lowerMessage = message.toLowerCase();

      // Extract information from message
      const timeInfo = this.extractTimeInfo(message);
      const locationInfo = this.extractLocationInfo(message);

      // Update booking with extracted info
      if (timeInfo) {
        booking.time = timeInfo;
      }
      if (locationInfo) {
        booking.pickup = locationInfo;
      }

      // Check what we still need
      const missingInfo = this.getMissingBookingInfo(booking);

      if (missingInfo.length === 0) {
        // We have all info, create booking
        return await this.createBookingFromContext(phoneNumber, context);
      } else {
        // Ask for missing information
        return await this.askForMissingInfo(phoneNumber, context, missingInfo[0]);
      }
    } catch (error) {
      console.error('Crew booking error:', error);
      return "Sorry, there was an error processing your booking. Please try again.";
    }
  }

  // Driver onboarding messages
  getDriverWelcomeMessage() {
    return `🚘 *Welcome to Crew Cab, Driver!*

You're now part of a reliable, respectful driver community — let's get you ready to start earning.

*1️⃣ 📍 Your Home Location*
Where do you usually start your shift?
→ Used to match you with nearby crew members.

Please reply with your home location (e.g., "Dubai Marina", "Downtown", "Deira")`;
  }

  getWorkingHoursMessage() {
    return `*2️⃣ 🕒 Your Usual Working Hours*
When are you usually available to drive?
(e.g., "Daily from 5:00 to 10:00 AM")
→ Saved for automatic matching.

Please reply with your typical working hours:`;
  }

  getFrequentRoutesMessage() {
    return `*3️⃣ 📍 Frequent Routes*
Do you regularly drive to:

• Emirates HQ?
• Terminal 1 / 2 / 3?
→ Mark your comfort zones for better ride suggestions.

Please reply with routes you're comfortable with (e.g., "Emirates HQ, Terminal 3, Downtown to Airport")`;
  }

  getMaxPickupsMessage() {
    return `*4️⃣ ⏳ Max Simultaneous Pickups*
How many crew members can you take in one trip?

Reply with: *1*, *2*, or *3*
→ (Limit enforced automatically)`;
  }

  getBehaviorPolicyMessage() {
    return `*5️⃣ 🤝 Behavior & Trust Policy*
We work only with reliable drivers.

❗ *Important Rules:*
• If you're more than 11 minutes late twice, the system may pause your access temporarily
• Always confirm pickup and dropoff via WhatsApp
• Maintain professional behavior with crew members
• Keep your vehicle clean and comfortable

Do you agree to follow these policies? Reply *"I agree"*`;
  }

  async completeDriverOnboarding(phoneNumber, driverData) {
    try {
      // Save driver data
      await this.saveDriverData(phoneNumber, driverData);
      
      // Clear onboarding context
      const context = this.getUserContext(phoneNumber);
      context.driverOnboarding = null;
      context.userType = 'driver';
      context.driverStatus = 'active';
      
      return `*6️⃣ ✅ Ready to Roll!*

🎉 *Registration Complete!*

You'll now receive WhatsApp messages when rides go live nearby.
*First driver to accept = gets the job.*
Payments are instant after confirmation 💸

*Your Profile:*
📍 Home: ${driverData.homeLocation}
🕒 Hours: ${driverData.workingHours}
🛣️ Routes: ${driverData.frequentRoutes.join(', ')}
👥 Max Pickups: ${driverData.maxPickups}

*You can also type:*
• "Available now" - Get matched with crew requests
• "Status" - Check your driver stats
• "Help" - See all commands

*Ready to start earning! 🚗💨*`;
    } catch (error) {
      console.error('Error completing driver onboarding:', error);
      return "Registration completed! You'll start receiving ride requests soon. Welcome to Crew Cab! 🚗";
    }
  }

  getDriverHelpMessage() {
    return `🚗 *Driver Commands:*

• "Available now" - Mark yourself as available
• "Not available" - Mark yourself as unavailable
• "Status" - View your stats and earnings
• "CrewCab#pickup#RIDEID" - Confirm pickup
• "CrewCab#dropoff#RIDEID" - Confirm dropoff
• "Help" - Show this menu

*Current Status:* Active and ready for rides! 🚘`;
  }

  // Helper methods
  parseFrequentRoutes(message) {
    const routes = [];
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('emirates') || lowerMessage.includes('hq')) {
      routes.push('Emirates HQ');
    }
    if (lowerMessage.includes('terminal 1') || lowerMessage.includes('t1')) {
      routes.push('Terminal 1');
    }
    if (lowerMessage.includes('terminal 2') || lowerMessage.includes('t2')) {
      routes.push('Terminal 2');
    }
    if (lowerMessage.includes('terminal 3') || lowerMessage.includes('t3')) {
      routes.push('Terminal 3');
    }
    if (lowerMessage.includes('airport') && !routes.some(r => r.includes('Terminal'))) {
      routes.push('Dubai Airport');
    }
    if (lowerMessage.includes('marina')) {
      routes.push('Dubai Marina');
    }
    if (lowerMessage.includes('downtown')) {
      routes.push('Downtown Dubai');
    }
    
    return routes.length > 0 ? routes : ['Emirates HQ']; // Default route
  }

  parseMaxPickups(message) {
    const match = message.match(/[123]/);
    if (match) {
      const num = parseInt(match[0]);
      return num >= 1 && num <= 3 ? num : null;
    }
    return null;
  }

  async saveDriverData(phoneNumber, driverData) {
    // Mock save - in production, save to database
    console.log(`✅ Driver registered: ${phoneNumber}`, driverData);
    return true;
  }

  isBookingIntent(message) {
    const bookingKeywords = ['flight', 'pickup', 'ride', 'airport', 'book'];
    const lowerMessage = message.toLowerCase();
    return bookingKeywords.some(keyword => lowerMessage.includes(keyword));
  }

  extractTimeInfo(message) {
    const timePatterns = [
      /(\d{1,2}):(\d{2})\s*(am|pm)?/i,
      /(\d{1,2})\s*(am|pm)/i,
      /at\s*(\d{1,2}):?(\d{2})?\s*(am|pm)?/i
    ];
    
    for (const pattern of timePatterns) {
      const match = message.match(pattern);
      if (match) {
        return {
          hour: parseInt(match[1]),
          minute: parseInt(match[2] || '0'),
          period: match[3]?.toLowerCase() || null,
          raw: match[0]
        };
      }
    }
    
    return null;
  }

  extractLocationInfo(message) {
    const locationPatterns = [
      /pickup from (.+?)(?:\s+at|\s+tomorrow|\s+tmr|$)/i,
      /from (.+?)(?:\s+at|\s+to|\s+tomorrow|\s+tmr|$)/i,
      /at (.+?)(?:\s+at|\s+tomorrow|\s+tmr|$)/i
    ];
    
    for (const pattern of locationPatterns) {
      const match = message.match(pattern);
      if (match) {
        return match[1].trim();
      }
    }
    
    return null;
  }

  getMissingBookingInfo(booking) {
    const missing = [];
    
    if (!booking?.pickup) missing.push('pickup');
    if (!booking?.time) missing.push('time');
    
    return missing;
  }

  async askForMissingInfo(phoneNumber, context, missingType) {
    context.waitingFor = missingType;
    
    switch (missingType) {
      case 'pickup':
        return "Where should we pick you up from? 📍";
      
      case 'time':
        return "What time do you need to be picked up? 🕐";
      
      default:
        return "I need a bit more information to complete your booking.";
    }
  }

  async createBookingFromContext(phoneNumber, context) {
    const booking = context.currentBooking;
    
    // Format booking summary
    const timeStr = this.formatTime(booking.time);
    const summary = `✅ *Booking Summary:*\n\n📍 Pickup: ${booking.pickup}\n🕐 Time: ${timeStr}\n✈️ Destination: Emirates HQ\n💰 Price: AED 60\n\nShall I proceed with this booking? Reply 'yes' to confirm.`;
    
    // Set context for confirmation
    context.waitingFor = 'booking_confirmation';
    context.bookingSummary = {
      ...booking,
      bookingId: this.generateBookingId(),
      price: 60
    };
    
    return summary;
  }

  formatTime(timeInfo) {
    if (!timeInfo) return '';
    
    const hour = timeInfo.hour;
    const minute = timeInfo.minute || 0;
    const period = timeInfo.period || (hour < 12 ? 'AM' : 'PM');
    
    return `${hour}:${minute.toString().padStart(2, '0')} ${period.toUpperCase()}`;
  }

  generateBookingId() {
    return 'RIDE' + Date.now().toString().slice(-6);
  }

  getUserContext(phoneNumber) {
    if (!this.userContexts.has(phoneNumber)) {
      this.userContexts.set(phoneNumber, {
        phoneNumber,
        userType: null,
        messageHistory: [],
        currentBooking: null,
        lastBooking: null,
        preferences: {},
        waitingFor: null,
        createdAt: new Date()
      });
    }
    
    return this.userContexts.get(phoneNumber);
  }

  async detectUserType(phoneNumber, message) {
    const lowerMessage = message.toLowerCase();
    
    if (lowerMessage.includes('join driver') || lowerMessage.includes('driver')) {
      return 'driver';
    }
    
    if (lowerMessage.includes('flight') || lowerMessage.includes('pickup') || lowerMessage.includes('crew')) {
      return 'crew';
    }
    
    return 'unknown';
  }

  getHelpMessage(userType) {
    if (userType === 'driver') {
      return this.getDriverHelpMessage();
    } else {
      return `👋 *Welcome to Crew Cab!*

I can help you:
• Book rides to/from the airport
• Upload your roster for automatic scheduling
• Set your ride preferences

Try saying:
• "I have a flight tomorrow at 6 AM"
• "Pickup from Marina at 3:30 AM"
• "Join driver" (if you want to become a driver)

How can I help you today?`;
    }
  }

  getErrorResponse() {
    return "I'm experiencing some technical difficulties. Please try again in a moment, or contact our support team.";
  }
}

module.exports = new AIChatbotService();