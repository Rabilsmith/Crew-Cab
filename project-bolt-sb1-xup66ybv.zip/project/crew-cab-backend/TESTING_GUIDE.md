# 🧪 Crew Cab Testing Guide

## 🚀 **READY FOR TESTING NOW!**

Your WhatsApp Business Number: **+44 7520 643511**

## 📱 **WhatsApp Testing Commands**

### **For Crew Members:**
Send these messages to **+44 7520 643511**:

1. **Registration**: `crew signup`
2. **Book a Ride**: `Pickup from Marina at 3:30AM`
3. **Help**: `help`

### **For Drivers:**
Send these messages to **+44 7520 643511**:

1. **Apply**: `join driver`
2. **Confirm Pickup**: `CrewCab#pickup#RIDE123456`
3. **Confirm Dropoff**: `CrewCab#dropoff#RIDE123456`

## 🔧 **API Testing Endpoints**

### **Test WhatsApp Integration:**
```bash
# Test webhook directly
curl -X POST http://localhost:3001/api/whatsapp/webhook \
  -H "Content-Type: application/json" \
  -d '{
    "Body": "crew signup",
    "From": "whatsapp:+447520643511",
    "MessageType": "text"
  }'
```

### **Test All Services:**
```bash
# Health check
curl http://localhost:3001/api/health

# Test WhatsApp
curl -X POST http://localhost:3001/api/whatsapp/test

# Test Payments
curl -X POST http://localhost:3001/api/payments/test

# Test Bookings
curl -X POST http://localhost:3001/api/bookings/test

# Test Drivers
curl -X POST http://localhost:3001/api/drivers/test

# Test Crew
curl -X POST http://localhost:3001/api/crew/test

# Test Admin
curl -X POST http://localhost:3001/api/admin/test
```

## 🎯 **Complete Testing Scenarios**

### **Scenario 1: Crew Member Journey**
1. **Send**: `crew signup` to +44 7520 643511
2. **Expect**: Welcome message with instructions
3. **Send**: `Pickup from Marina at 3:30AM`
4. **Expect**: Booking confirmation with payment link
5. **Result**: Mock payment processed, driver assigned

### **Scenario 2: Driver Journey**
1. **Send**: `join driver` to +44 7520 643511
2. **Expect**: Driver onboarding message
3. **Send**: `CrewCab#pickup#RIDE123456`
4. **Expect**: Pickup confirmation
5. **Send**: `CrewCab#dropoff#RIDE123456`
6. **Expect**: Ride completion with earnings

### **Scenario 3: Admin Dashboard**
1. **Visit**: http://localhost:3001/api/admin/dashboard
2. **Expect**: Complete analytics data
3. **Check**: Real-time booking stats

## 📊 **What's Working Right Now:**

### ✅ **Backend Services:**
- **WhatsApp Integration** - Mock service ready
- **Payment Processing** - Mock Stripe integration
- **Booking System** - Full CRUD operations
- **Driver Management** - Registration and approval
- **Crew Management** - Registration and ride history
- **Admin Dashboard** - Analytics and monitoring

### ✅ **Landing Page:**
- **WhatsApp Links** - Connected to +44 7520 643511
- **Crew Cab Branding** - Official colors and fonts
- **Responsive Design** - Works on all devices
- **Call-to-Action** - Direct WhatsApp integration

## 🔗 **Quick Test Links:**

### **WhatsApp Links (Click to Test):**
- **Crew Signup**: https://wa.me/447520643511?text=crew%20signup
- **Driver Signup**: https://wa.me/447520643511?text=join%20driver
- **Book Ride**: https://wa.me/447520643511?text=Pickup%20from%20Marina%20at%203:30AM

### **API Endpoints:**
- **Health Check**: http://localhost:3001/api/health
- **Admin Dashboard**: http://localhost:3001/api/admin/dashboard
- **Landing Page**: http://localhost:5173

## 🚨 **Testing Checklist:**

### **✅ Immediate Tests (5 minutes):**
- [ ] Send "crew signup" to +44 7520 643511
- [ ] Send "join driver" to +44 7520 643511
- [ ] Check http://localhost:3001/api/health
- [ ] Visit landing page at http://localhost:5173

### **✅ Full Flow Tests (15 minutes):**
- [ ] Complete crew registration flow
- [ ] Test booking creation
- [ ] Test driver assignment
- [ ] Test pickup/dropoff confirmations
- [ ] Check admin dashboard data

### **✅ Integration Tests (30 minutes):**
- [ ] Test all WhatsApp commands
- [ ] Verify payment flow (mock)
- [ ] Check database operations
- [ ] Test error handling
- [ ] Verify logging and monitoring

## 📱 **Real WhatsApp Setup (Optional):**

To connect to real WhatsApp Business API:

1. **Twilio Setup:**
   - Sign up at https://console.twilio.com/
   - Get WhatsApp sandbox access
   - Update TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN in .env

2. **Webhook Configuration:**
   - Set webhook URL to: `https://your-domain.com/api/whatsapp/webhook`
   - Method: POST

## 🎉 **You're Ready to Test!**

**Everything is configured and running. Start testing immediately with your WhatsApp number: +44 7520 643511**

### **Next Steps:**
1. **Test basic WhatsApp commands** (5 min)
2. **Verify all API endpoints** (10 min)
3. **Check landing page integration** (5 min)
4. **Report any issues** for immediate fixes

**Happy Testing! 🚀**