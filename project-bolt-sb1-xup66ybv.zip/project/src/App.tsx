import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './components/auth/AuthProvider';
import { MessageCircle, Shield, Clock, CheckCircle, Users, Star, ArrowRight, Phone, Plane, Globe, MapPin, Calendar, Zap, Coffee, Moon, Sun } from 'lucide-react';
import { AdminDashboard } from './pages/AdminDashboard';
import { DashboardPage } from './pages/DashboardPage';
import { LoginPage } from './pages/LoginPage';
import { SuccessPage } from './pages/SuccessPage';
import { CancelPage } from './pages/CancelPage';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/success" element={<SuccessPage />} />
          <Route path="/cancel" element={<CancelPage />} />
          <Route path="/" element={<LandingPage />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center space-x-4">
              <img 
                src="/Crew Cab Whatsapp.png" 
                alt="Crew Cab Logo" 
                className="w-12 h-12"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
              <div>
                <h1 className="text-2xl font-bold text-gray-900" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                  Crew Cab
                </h1>
                <p className="text-sm text-gray-600" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                  Where your shift ends, we begin.
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <a 
                href="/admin"
                className="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-lg font-medium transition-colors"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Admin Dashboard
              </a>
              <a 
                href="/dashboard"
                className="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-lg font-medium transition-colors"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Dashboard
              </a>
              <button 
                onClick={() => window.open('https://wa.me/447520643511?text=crew%20signup', '_blank')}
                className="text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 hover:shadow-lg transform hover:-translate-y-0.5"
                style={{ 
                  background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)',
                  fontFamily: 'Montserrat, sans-serif'
                }}
              >
                Book Now
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div 
          className="absolute inset-0 opacity-5"
          style={{
            background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)'
          }}
        ></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="flex justify-center mb-12">
              <div className="relative">
                <img 
                  src="/Crew Cab Whatsapp.png" 
                  alt="Crew Cab Logo" 
                  className="w-32 h-32 drop-shadow-2xl"
                />
                <div 
                  className="absolute -inset-4 rounded-full opacity-20 blur-xl"
                  style={{
                    background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)'
                  }}
                ></div>
              </div>
            </div>
            
            <h1 
              className="text-5xl md:text-7xl font-extrabold mb-8"
              style={{ 
                fontFamily: 'Montserrat, sans-serif',
                background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text'
              }}
            >
              Premium Airport Rides
              <span className="block text-4xl md:text-5xl mt-4 text-gray-800">
                for Cabin Crew
              </span>
            </h1>
            
            <p 
              className="text-xl md:text-2xl text-gray-700 mb-12 max-w-4xl mx-auto leading-relaxed"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              Experience reliable, professional transportation designed specifically for airline cabin crew members in Dubai. 
              Book instantly via WhatsApp and save 20% compared to regular taxi services.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
              <button 
                onClick={() => window.open('https://wa.me/447520643511?text=crew%20signup', '_blank')}
                className="text-white px-10 py-5 rounded-xl text-lg font-bold transition-all duration-300 hover:shadow-2xl transform hover:-translate-y-1 flex items-center space-x-3"
                style={{ 
                  background: '#1CC88A',
                  fontFamily: 'Montserrat, sans-serif'
                }}
              >
                <MessageCircle className="w-6 h-6" />
                <span>Book via WhatsApp</span>
              </button>
              
              <button 
                className="bg-white text-gray-800 px-10 py-5 rounded-xl text-lg font-bold border-2 transition-all duration-300 hover:shadow-xl transform hover:-translate-y-1"
                style={{ 
                  borderColor: '#26B67F',
                  fontFamily: 'Montserrat, sans-serif'
                }}
              >
                Learn More
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Airlines Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 
              className="text-3xl font-bold mb-4"
              style={{ 
                fontFamily: 'Montserrat, sans-serif',
                color: '#0E6245'
              }}
            >
              Serving All Airlines in Dubai
            </h2>
            <p 
              className="text-lg text-gray-600"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              Professional transportation for crew members from all major airlines
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 items-center opacity-60">
            <div className="text-center">
              <div 
                className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)' }}
              >
                <Plane className="w-8 h-8 text-white" />
              </div>
              <p className="text-sm font-medium text-gray-700" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                Emirates
              </p>
            </div>
            
            <div className="text-center">
              <div 
                className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)' }}
              >
                <Plane className="w-8 h-8 text-white" />
              </div>
              <p className="text-sm font-medium text-gray-700" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                Etihad
              </p>
            </div>
            
            <div className="text-center">
              <div 
                className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)' }}
              >
                <Plane className="w-8 h-8 text-white" />
              </div>
              <p className="text-sm font-medium text-gray-700" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                flydubai
              </p>
            </div>
            
            <div className="text-center">
              <div 
                className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)' }}
              >
                <Plane className="w-8 h-8 text-white" />
              </div>
              <p className="text-sm font-medium text-gray-700" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                Qatar Airways
              </p>
            </div>
            
            <div className="text-center">
              <div 
                className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)' }}
              >
                <Plane className="w-8 h-8 text-white" />
              </div>
              <p className="text-sm font-medium text-gray-700" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                Turkish Airlines
              </p>
            </div>
            
            <div className="text-center">
              <div 
                className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)' }}
              >
                <Globe className="w-8 h-8 text-white" />
              </div>
              <p className="text-sm font-medium text-gray-700" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                All Airlines
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 
              className="text-4xl md:text-5xl font-bold mb-6"
              style={{ 
                fontFamily: 'Montserrat, sans-serif',
                color: '#0E6245'
              }}
            >
              Why Choose Crew Cab?
            </h2>
            <p 
              className="text-xl text-gray-700 max-w-3xl mx-auto"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              Designed by crew, for crew. We understand your unique scheduling needs and provide premium service at affordable rates across all airlines.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
              <div 
                className="w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6"
                style={{ background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)' }}
              >
                <CheckCircle className="w-10 h-10 text-white" />
              </div>
              <h3 
                className="text-2xl font-bold mb-4 text-center"
                style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
              >
                20% Cheaper
              </h3>
              <p 
                className="text-gray-700 text-center leading-relaxed"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Save money compared to regular taxi services while getting premium service tailored for crew schedules from any airline.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
              <div 
                className="w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6"
                style={{ background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)' }}
              >
                <Shield className="w-10 h-10 text-white" />
              </div>
              <h3 
                className="text-2xl font-bold mb-4 text-center"
                style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
              >
                Vetted Drivers
              </h3>
              <p 
                className="text-gray-700 text-center leading-relaxed"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                All drivers are professionally screened and trained to provide safe, reliable transportation for airline crew members.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
              <div 
                className="w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6"
                style={{ background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)' }}
              >
                <Clock className="w-10 h-10 text-white" />
              </div>
              <h3 
                className="text-2xl font-bold mb-4 text-center"
                style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
              >
                24/7 Available
              </h3>
              <p 
                className="text-gray-700 text-center leading-relaxed"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Book rides anytime via WhatsApp. Perfect for early morning flights and late-night arrivals across all airline schedules.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 
              className="text-4xl md:text-5xl font-bold mb-6"
              style={{ 
                fontFamily: 'Montserrat, sans-serif',
                color: '#0E6245'
              }}
            >
              Perfect for Every Crew Schedule
            </h2>
            <p 
              className="text-xl text-gray-700 max-w-3xl mx-auto"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              From early morning departures to late-night arrivals, Crew Cab adapts to your unique airline schedule
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Early Morning Flights */}
            <div className="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-2xl p-8 border border-orange-100 hover:shadow-xl transition-all duration-300">
              <div 
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
                style={{ background: 'linear-gradient(135deg, #f59e0b 0%, #f97316 100%)' }}
              >
                <Sun className="w-8 h-8 text-white" />
              </div>
              <h3 
                className="text-xl font-bold mb-4"
                style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
              >
                Early Morning Flights
              </h3>
              <p 
                className="text-gray-700 mb-4 leading-relaxed"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                <strong>3:30 AM departure?</strong> No problem. Our drivers are ready when regular taxis aren't available.
              </p>
              <div className="text-sm text-gray-600" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                <div className="flex items-center mb-2">
                  <Clock className="w-4 h-4 mr-2" style={{ color: '#f59e0b' }} />
                  <span>Pickup: 2:00 AM</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="w-4 h-4 mr-2" style={{ color: '#f59e0b' }} />
                  <span>Marina → DXB Terminal 3</span>
                </div>
              </div>
            </div>

            {/* Late Night Arrivals */}
            <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl p-8 border border-indigo-100 hover:shadow-xl transition-all duration-300">
              <div 
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
                style={{ background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)' }}
              >
                <Moon className="w-8 h-8 text-white" />
              </div>
              <h3 
                className="text-xl font-bold mb-4"
                style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
              >
                Late Night Arrivals
              </h3>
              <p 
                className="text-gray-700 mb-4 leading-relaxed"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                <strong>Landed at 11:45 PM?</strong> Safe, reliable rides home when you're exhausted after long flights.
              </p>
              <div className="text-sm text-gray-600" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                <div className="flex items-center mb-2">
                  <Clock className="w-4 h-4 mr-2" style={{ color: '#6366f1' }} />
                  <span>Pickup: 12:30 AM</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="w-4 h-4 mr-2" style={{ color: '#6366f1' }} />
                  <span>DXB Terminal 1 → Downtown</span>
                </div>
              </div>
            </div>

            {/* Layover Transportation */}
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-8 border border-green-100 hover:shadow-xl transition-all duration-300">
              <div 
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
                style={{ background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)' }}
              >
                <Coffee className="w-8 h-8 text-white" />
              </div>
              <h3 
                className="text-xl font-bold mb-4"
                style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
              >
                Layover Breaks
              </h3>
              <p 
                className="text-gray-700 mb-4 leading-relaxed"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                <strong>6-hour layover?</strong> Quick trips to Dubai Mall, Marina, or home for a proper rest between flights.
              </p>
              <div className="text-sm text-gray-600" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                <div className="flex items-center mb-2">
                  <Clock className="w-4 h-4 mr-2" style={{ color: '#26B67F' }} />
                  <span>Round trip: 4 hours</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="w-4 h-4 mr-2" style={{ color: '#26B67F' }} />
                  <span>Airport → City → Airport</span>
                </div>
              </div>
            </div>

            {/* Emergency Situations */}
            <div className="bg-gradient-to-br from-red-50 to-pink-50 rounded-2xl p-8 border border-red-100 hover:shadow-xl transition-all duration-300">
              <div 
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6"
                style={{ background: 'linear-gradient(135deg, #dc2626 0%, #e11d48 100%)' }}
              >
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h3 
                className="text-xl font-bold mb-4"
                style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
              >
                Last-Minute Changes
              </h3>
              <p 
                className="text-gray-700 mb-4 leading-relaxed"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                <strong>Flight delayed 3 hours?</strong> Instant rebooking via WhatsApp. No waiting, no stress.
              </p>
              <div className="text-sm text-gray-600" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                <div className="flex items-center mb-2">
                  <Clock className="w-4 h-4 mr-2" style={{ color: '#dc2626' }} />
                  <span>Instant updates</span>
                </div>
                <div className="flex items-center">
                  <MessageCircle className="w-4 h-4 mr-2" style={{ color: '#dc2626' }} />
                  <span>WhatsApp rebooking</span>
                </div>
              </div>
            </div>
          </div>

          {/* Real Scenarios */}
          <div className="mt-16 bg-gray-50 rounded-2xl p-8">
            <h3 
              className="text-2xl font-bold text-center mb-8"
              style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
            >
              Real Crew Scenarios We Handle Daily
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl p-6 border-l-4" style={{ borderColor: '#26B67F' }}>
                <p 
                  className="text-gray-700 italic mb-3"
                  style={{ fontFamily: 'Montserrat, sans-serif' }}
                >
                  "My 4:30 AM flight to London got moved to 6:15 AM. Can you pick me up at 3:45 AM instead of 3:00 AM?"
                </p>
                <p 
                  className="text-sm font-medium"
                  style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
                >
                  ✅ Updated instantly via WhatsApp
                </p>
              </div>
              
              <div className="bg-white rounded-xl p-6 border-l-4" style={{ borderColor: '#26B67F' }}>
                <p 
                  className="text-gray-700 italic mb-3"
                  style={{ fontFamily: 'Montserrat, sans-serif' }}
                >
                  "Just landed from Singapore at 11:30 PM. Need a ride to Marina. Too tired to wait for regular taxis."
                </p>
                <p 
                  className="text-sm font-medium"
                  style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
                >
                  ✅ Driver waiting at arrivals
                </p>
              </div>
              
              <div className="bg-white rounded-xl p-6 border-l-4" style={{ borderColor: '#26B67F' }}>
                <p 
                  className="text-gray-700 italic mb-3"
                  style={{ fontFamily: 'Montserrat, sans-serif' }}
                >
                  "8-hour layover in Dubai. Want to go home for a quick shower and nap before my next flight to New York."
                </p>
                <p 
                  className="text-sm font-medium"
                  style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
                >
                  ✅ Round trip scheduled perfectly
                </p>
              </div>
              
              <div className="bg-white rounded-xl p-6 border-l-4" style={{ borderColor: '#26B67F' }}>
                <p 
                  className="text-gray-700 italic mb-3"
                  style={{ fontFamily: 'Montserrat, sans-serif' }}
                >
                  "Weather delay means I'm stuck at the airport. Can you cancel my 2 PM pickup and rebook for 6 PM?"
                </p>
                <p 
                  className="text-sm font-medium"
                  style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
                >
                  ✅ Flexible rebooking, no fees
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section 
        className="py-24 relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)'
        }}
      >
        <div className="absolute inset-0 bg-black opacity-5"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 
              className="text-4xl md:text-5xl font-bold text-white mb-6"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              How It Works
            </h2>
            <p 
              className="text-xl text-white opacity-90"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              Simple, fast, and designed for your busy airline schedule
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-2xl p-8 border border-white border-opacity-20">
              <div className="bg-white w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
                <span 
                  className="font-bold text-2xl"
                  style={{ color: '#0E6245', fontFamily: 'Montserrat, sans-serif' }}
                >
                  1
                </span>
              </div>
              <h3 
                className="text-2xl font-bold text-white mb-4"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Book via WhatsApp
              </h3>
              <p 
                className="text-white opacity-90 leading-relaxed"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Send a message to our WhatsApp number with your pickup location and time. Works for all airlines - no app downloads required.
              </p>
            </div>

            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-2xl p-8 border border-white border-opacity-20">
              <div className="bg-white w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
                <span 
                  className="font-bold text-2xl"
                  style={{ color: '#0E6245', fontFamily: 'Montserrat, sans-serif' }}
                >
                  2
                </span>
              </div>
              <h3 
                className="text-2xl font-bold text-white mb-4"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Secure Payment
              </h3>
              <p 
                className="text-white opacity-90 leading-relaxed"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Pay securely through our Stripe-powered payment system. Get instant confirmation and driver details for your ride.
              </p>
            </div>

            <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-2xl p-8 border border-white border-opacity-20">
              <div className="bg-white w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
                <span 
                  className="font-bold text-2xl"
                  style={{ color: '#0E6245', fontFamily: 'Montserrat, sans-serif' }}
                >
                  3
                </span>
              </div>
              <h3 
                className="text-2xl font-bold text-white mb-4"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Professional Ride
              </h3>
              <p 
                className="text-white opacity-90 leading-relaxed"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Your vetted driver arrives on time with a clean, comfortable vehicle. Track your ride in real-time to any Dubai airport.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 
              className="text-4xl md:text-5xl font-bold mb-6"
              style={{ 
                fontFamily: 'Montserrat, sans-serif',
                color: '#0E6245'
              }}
            >
              Transparent Pricing
            </h2>
            <p 
              className="text-xl text-gray-700"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              No surge pricing, no hidden fees. Just honest, affordable rates for all airline crew.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div className="bg-gray-50 rounded-2xl p-8 border-2 border-gray-200 hover:shadow-xl transition-all duration-300">
              <h3 
                className="text-xl font-bold mb-4"
                style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
              >
                Marina → DXB Airport
              </h3>
              <div 
                className="text-4xl font-bold mb-2"
                style={{ fontFamily: 'Montserrat, sans-serif', color: '#1CC88A' }}
              >
                AED 60
              </div>
              <p 
                className="text-gray-600 text-sm mb-4"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                vs Regular Taxi: AED 75
              </p>
              <div 
                className="font-bold"
                style={{ fontFamily: 'Montserrat, sans-serif', color: '#26B67F' }}
              >
                Save AED 15
              </div>
            </div>

            <div 
              className="rounded-2xl p-8 border-2 transform scale-105 shadow-2xl"
              style={{ 
                background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)',
                borderColor: '#1CC88A'
              }}
            >
              <h3 
                className="text-xl font-bold text-white mb-4"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Downtown → DXB Airport
              </h3>
              <div 
                className="text-4xl font-bold text-white mb-2"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                AED 52
              </div>
              <p 
                className="text-white opacity-80 text-sm mb-4"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                vs Regular Taxi: AED 65
              </p>
              <div 
                className="text-white font-bold"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Save AED 13
              </div>
            </div>

            <div className="bg-gray-50 rounded-2xl p-8 border-2 border-gray-200 hover:shadow-xl transition-all duration-300">
              <h3 
                className="text-xl font-bold mb-4"
                style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
              >
                Deira → DXB Airport
              </h3>
              <div 
                className="text-4xl font-bold mb-2"
                style={{ fontFamily: 'Montserrat, sans-serif', color: '#1CC88A' }}
              >
                AED 36
              </div>
              <p 
                className="text-gray-600 text-sm mb-4"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                vs Regular Taxi: AED 45
              </p>
              <div 
                className="font-bold"
                style={{ fontFamily: 'Montserrat, sans-serif', color: '#26B67F' }}
              >
                Save AED 9
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 
              className="text-4xl md:text-5xl font-bold mb-6"
              style={{ 
                fontFamily: 'Montserrat, sans-serif',
                color: '#0E6245'
              }}
            >
              Trusted by Airline Crew
            </h2>
            <p 
              className="text-xl text-gray-700"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              From Emirates to Etihad, flydubai to international carriers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-current" style={{ color: '#1CC88A' }} />
                ))}
              </div>
              <p 
                className="text-gray-700 mb-6 leading-relaxed"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                "Finally, a service that understands our crazy schedules! Always on time for my 4 AM flights, regardless of which airline I'm flying with."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full bg-gradient-to-r from-green-400 to-blue-500 flex items-center justify-center text-white font-bold">
                  S
                </div>
                <div className="ml-4">
                  <p 
                    className="font-bold"
                    style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
                  >
                    Sarah M.
                  </p>
                  <p 
                    className="text-gray-600 text-sm"
                    style={{ fontFamily: 'Montserrat, sans-serif' }}
                  >
                    Senior Flight Attendant
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-current" style={{ color: '#1CC88A' }} />
                ))}
              </div>
              <p 
                className="text-gray-700 mb-6 leading-relaxed"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                "Professional drivers who know all the airport routes. Much better than regular taxi services for us crew members."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-400 to-pink-500 flex items-center justify-center text-white font-bold">
                  A
                </div>
                <div className="ml-4">
                  <p 
                    className="font-bold"
                    style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
                  >
                    Ahmed K.
                  </p>
                  <p 
                    className="text-gray-600 text-sm"
                    style={{ fontFamily: 'Montserrat, sans-serif' }}
                  >
                    Cabin Crew
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="flex items-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-current" style={{ color: '#1CC88A' }} />
                ))}
              </div>
              <p 
                className="text-gray-700 mb-6 leading-relaxed"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                "The WhatsApp booking is so convenient. No apps to download, just simple messaging. Works perfectly for international crew schedules."
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full bg-gradient-to-r from-yellow-400 to-orange-500 flex items-center justify-center text-white font-bold">
                  M
                </div>
                <div className="ml-4">
                  <p 
                    className="font-bold"
                    style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
                  >
                    Maria L.
                  </p>
                  <p 
                    className="text-gray-600 text-sm"
                    style={{ fontFamily: 'Montserrat, sans-serif' }}
                  >
                    Purser
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Expansion Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 
              className="text-4xl md:text-5xl font-bold mb-6"
              style={{ 
                fontFamily: 'Montserrat, sans-serif',
                color: '#0E6245'
              }}
            >
              Growing Across the Region
            </h2>
            <p 
              className="text-xl text-gray-700 max-w-3xl mx-auto"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              Starting in Dubai, expanding to serve airline crew across the Middle East and beyond
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8">
              <div 
                className="w-20 h-20 rounded-full mx-auto mb-6 flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)' }}
              >
                <span className="text-white font-bold text-2xl" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                  🇦🇪
                </span>
              </div>
              <h3 
                className="text-2xl font-bold mb-4"
                style={{ fontFamily: 'Montserrat, sans-serif', color: '#0E6245' }}
              >
                Dubai - Now Live
              </h3>
              <p 
                className="text-gray-700"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Serving all airlines operating from Dubai International and Al Maktoum airports
              </p>
            </div>

            <div className="text-center p-8">
              <div 
                className="w-20 h-20 rounded-full mx-auto mb-6 flex items-center justify-center bg-gray-200"
              >
                <span className="text-gray-600 font-bold text-2xl" style={{ fontFamily: 'Montserrat, sans-serif' }}>
                  🇦🇪
                </span>
              </div>
              <h3 
                className="text-2xl font-bold mb-4 text-gray-600"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Abu Dhabi - Coming Soon
              </h3>
              <p 
                className="text-gray-600"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Expanding to serve Etihad and other carriers based in Abu Dhabi
              </p>
            </div>

            <div className="text-center p-8">
              <div 
                className="w-20 h-20 rounded-full mx-auto mb-6 flex items-center justify-center bg-gray-200"
              >
                <Globe className="w-10 h-10 text-gray-600" />
              </div>
              <h3 
                className="text-2xl font-bold mb-4 text-gray-600"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Regional Expansion
              </h3>
              <p 
                className="text-gray-600"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Planning expansion to Qatar, Kuwait, and other major aviation hubs
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section 
        className="py-24 relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, #0E6245 0%, #26B67F 100%)'
        }}
      >
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 
            className="text-4xl md:text-5xl font-bold text-white mb-6"
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            Ready to Experience Premium Crew Transportation?
          </h2>
          <p 
            className="text-xl text-white opacity-90 mb-12 max-w-3xl mx-auto"
            style={{ fontFamily: 'Montserrat, sans-serif' }}
          >
            Join hundreds of airline crew members who trust Crew Cab for reliable, affordable airport transportation across Dubai.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <button 
              onClick={() => window.open('https://wa.me/447520643511?text=crew%20signup', '_blank')}
              className="bg-white px-10 py-5 rounded-xl text-lg font-bold transition-all duration-300 hover:shadow-2xl transform hover:-translate-y-1 flex items-center justify-center space-x-3"
              style={{ 
                color: '#0E6245',
                fontFamily: 'Montserrat, sans-serif'
              }}
            >
              <MessageCircle className="w-6 h-6" />
              <span>Book Your First Ride</span>
            </button>
            <button 
              onClick={() => window.open('https://wa.me/447520643511?text=join%20driver', '_blank')}
              className="bg-transparent border-2 border-white text-white px-10 py-5 rounded-xl text-lg font-bold hover:bg-white transition-all duration-300 flex items-center justify-center space-x-3"
              style={{ 
                fontFamily: 'Montserrat, sans-serif'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = '#0E6245';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = 'white';
              }}
            >
              <Users className="w-6 h-6" />
              <span>Join as Driver</span>
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer 
        className="py-16"
        style={{
          background: 'linear-gradient(135deg, #0E6245 0%, #1a5a42 100%)'
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-4 mb-6">
                <img 
                  src="/Crew Cab Whatsapp.png" 
                  alt="Crew Cab Logo" 
                  className="w-12 h-12"
                />
                <div>
                  <h3 
                    className="text-2xl font-bold text-white"
                    style={{ fontFamily: 'Montserrat, sans-serif' }}
                  >
                    Crew Cab
                  </h3>
                  <p 
                    className="text-white opacity-80"
                    style={{ fontFamily: 'Montserrat, sans-serif' }}
                  >
                    Where your shift ends, we begin.
                  </p>
                </div>
              </div>
              <p 
                className="text-white opacity-80 mb-6 leading-relaxed"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Professional transportation services designed specifically for airline cabin crew members across Dubai. 
                Reliable, affordable, and available 24/7 for all airlines.
              </p>
            </div>

            <div>
              <h4 
                className="text-lg font-bold text-white mb-6"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Services
              </h4>
              <ul className="space-y-3">
                {['Airport Transfers', 'WhatsApp Booking', 'Multi-Airline Support', '24/7 Service'].map((item) => (
                  <li key={item}>
                    <a 
                      href="#" 
                      className="text-white opacity-80 hover:opacity-100 transition-opacity"
                      style={{ fontFamily: 'Montserrat, sans-serif' }}
                    >
                      {item}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 
                className="text-lg font-bold text-white mb-6"
                style={{ fontFamily: 'Montserrat, sans-serif' }}
              >
                Contact
              </h4>
              <ul className="space-y-3">
                <li className="flex items-center space-x-2">
                  <MessageCircle className="w-4 h-4 text-white opacity-80" />
                  <span 
                    className="text-white opacity-80"
                    style={{ fontFamily: 'Montserrat, sans-serif' }}
                  >
                    WhatsApp: +44 7520 643511
                  </span>
                </li>
                <li className="flex items-center space-x-2">
                  <Phone className="w-4 h-4 text-white opacity-80" />
                  <span 
                    className="text-white opacity-80"
                    style={{ fontFamily: 'Montserrat, sans-serif' }}
                  >
                    support@crewcab.ae
                  </span>
                </li>
                <li 
                  className="text-white opacity-80"
                  style={{ fontFamily: 'Montserrat, sans-serif' }}
                >
                  Dubai, UAE
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-white border-opacity-20 mt-12 pt-8 text-center">
            <p 
              className="text-white opacity-80"
              style={{ fontFamily: 'Montserrat, sans-serif' }}
            >
              &copy; 2024 Crew Cab. All rights reserved. Premium transportation for airline crew across Dubai.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;