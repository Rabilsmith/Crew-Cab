import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Car, 
  MessageCircle, 
  TrendingUp, 
  Clock, 
  MapPin, 
  Calendar,
  Brain,
  Image,
  AlertTriangle,
  CheckCircle,
  DollarSign,
  Activity,
  Zap,
  Eye,
  Download,
  Filter
} from 'lucide-react';

interface DashboardStats {
  totalBookings: number;
  totalCrewMembers: number;
  totalDrivers: number;
  activeDrivers: number;
  todayBookings: number;
  revenue: number;
  completionRate: number;
  aiAccuracy: number;
  rosterProcessed: number;
  locationVerifications: number;
}

interface AIInsight {
  type: 'success' | 'warning' | 'error';
  message: string;
  timestamp: string;
  confidence: number;
}

interface ConversationLog {
  id: string;
  phoneNumber: string;
  userType: 'crew' | 'driver';
  messages: Array<{
    sender: 'user' | 'bot';
    message: string;
    timestamp: string;
    intent?: string;
    confidence?: number;
  }>;
  status: 'active' | 'completed' | 'failed';
  bookingCreated: boolean;
}

export const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [aiInsights, setAiInsights] = useState<AIInsight[]>([]);
  const [conversations, setConversations] = useState<ConversationLog[]>([]);
  const [selectedTab, setSelectedTab] = useState('overview');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
    const interval = setInterval(fetchDashboardData, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchDashboardData = async () => {
    try {
      // Fetch dashboard stats
      const statsResponse = await fetch('/api/admin/dashboard');
      const statsData = await statsResponse.json();
      setStats(statsData.overview);

      // Fetch AI insights
      const aiResponse = await fetch('/api/admin/ai-insights');
      const aiData = await aiResponse.json();
      setAiInsights(aiData.insights);

      // Fetch conversation logs
      const conversationsResponse = await fetch('/api/admin/conversations');
      const conversationsData = await conversationsResponse.json();
      setConversations(conversationsData.conversations);

      setLoading(false);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="bg-green-600 p-2 rounded-lg">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Crew Cab AI Dashboard</h1>
                <p className="text-sm text-gray-500">Real-time AI insights and analytics</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-green-600">
                <div className="w-2 h-2 bg-green-600 rounded-full animate-pulse"></div>
                <span>AI System Online</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="border-b border-gray-200 mb-6">
          <nav className="-mb-px flex space-x-8">
            {[
              { id: 'overview', name: 'Overview', icon: Activity },
              { id: 'ai-insights', name: 'AI Insights', icon: Brain },
              { id: 'conversations', name: 'Conversations', icon: MessageCircle },
              { id: 'roster-ai', name: 'Roster AI', icon: Image },
              { id: 'location-ai', name: 'Location AI', icon: MapPin },
              { id: 'analytics', name: 'Analytics', icon: TrendingUp }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id)}
                className={`flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm ${
                  selectedTab === tab.id
                    ? 'border-green-500 text-green-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span>{tab.name}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Overview Tab */}
        {selectedTab === 'overview' && (
          <div className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Bookings</p>
                    <p className="text-3xl font-bold text-gray-900">{stats?.totalBookings || 0}</p>
                  </div>
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <Calendar className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                  <span className="text-green-600">+12% from last week</span>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">AI Accuracy</p>
                    <p className="text-3xl font-bold text-gray-900">{stats?.aiAccuracy || 94}%</p>
                  </div>
                  <div className="bg-green-100 p-3 rounded-lg">
                    <Brain className="w-6 h-6 text-green-600" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <CheckCircle className="w-4 h-4 text-green-500 mr-1" />
                  <span className="text-green-600">Intent recognition</span>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Roster Processed</p>
                    <p className="text-3xl font-bold text-gray-900">{stats?.rosterProcessed || 156}</p>
                  </div>
                  <div className="bg-purple-100 p-3 rounded-lg">
                    <Image className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <Zap className="w-4 h-4 text-purple-500 mr-1" />
                  <span className="text-purple-600">OCR success rate: 98%</span>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Revenue</p>
                    <p className="text-3xl font-bold text-gray-900">AED {stats?.revenue?.toLocaleString() || '15,680'}</p>
                  </div>
                  <div className="bg-yellow-100 p-3 rounded-lg">
                    <DollarSign className="w-6 h-6 text-yellow-600" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                  <span className="text-green-600">+8% from last month</span>
                </div>
              </div>
            </div>

            {/* Real-time Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Live AI Activity</h3>
                <div className="space-y-4">
                  {aiInsights.slice(0, 5).map((insight, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className={`w-2 h-2 rounded-full mt-2 ${
                        insight.type === 'success' ? 'bg-green-500' :
                        insight.type === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                      }`}></div>
                      <div className="flex-1">
                        <p className="text-sm text-gray-900">{insight.message}</p>
                        <p className="text-xs text-gray-500">{insight.timestamp}</p>
                      </div>
                      <div className="text-xs text-gray-400">
                        {Math.round(insight.confidence * 100)}%
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Active Conversations</h3>
                <div className="space-y-4">
                  {conversations.filter(c => c.status === 'active').slice(0, 5).map((conversation) => (
                    <div key={conversation.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                          <Users className="w-4 h-4 text-blue-600" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900">{conversation.phoneNumber}</p>
                          <p className="text-xs text-gray-500">{conversation.userType} • {conversation.messages.length} messages</p>
                        </div>
                      </div>
                      <button className="text-blue-600 hover:text-blue-700">
                        <Eye className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* AI Insights Tab */}
        {selectedTab === 'ai-insights' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">AI Performance Metrics</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">94%</div>
                  <div className="text-sm text-gray-600">Intent Recognition</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600">98%</div>
                  <div className="text-sm text-gray-600">OCR Accuracy</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600">92%</div>
                  <div className="text-sm text-gray-600">Booking Completion</div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent AI Insights</h3>
              <div className="space-y-4">
                {aiInsights.map((insight, index) => (
                  <div key={index} className={`p-4 rounded-lg border-l-4 ${
                    insight.type === 'success' ? 'bg-green-50 border-green-500' :
                    insight.type === 'warning' ? 'bg-yellow-50 border-yellow-500' :
                    'bg-red-50 border-red-500'
                  }`}>
                    <div className="flex items-center justify-between">
                      <p className="text-sm text-gray-900">{insight.message}</p>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-gray-500">{Math.round(insight.confidence * 100)}% confidence</span>
                        <span className="text-xs text-gray-400">{insight.timestamp}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Conversations Tab */}
        {selectedTab === 'conversations' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-gray-900">WhatsApp Conversations</h3>
                  <div className="flex items-center space-x-2">
                    <button className="flex items-center space-x-2 px-3 py-2 border border-gray-300 rounded-lg text-sm">
                      <Filter className="w-4 h-4" />
                      <span>Filter</span>
                    </button>
                    <button className="flex items-center space-x-2 px-3 py-2 bg-green-600 text-white rounded-lg text-sm">
                      <Download className="w-4 h-4" />
                      <span>Export</span>
                    </button>
                  </div>
                </div>
              </div>
              <div className="divide-y divide-gray-200">
                {conversations.map((conversation) => (
                  <div key={conversation.id} className="p-6 hover:bg-gray-50">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          conversation.userType === 'crew' ? 'bg-blue-100' : 'bg-green-100'
                        }`}>
                          {conversation.userType === 'crew' ? 
                            <Users className="w-5 h-5 text-blue-600" /> :
                            <Car className="w-5 h-5 text-green-600" />
                          }
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{conversation.phoneNumber}</p>
                          <p className="text-sm text-gray-500">
                            {conversation.userType} • {conversation.messages.length} messages
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          conversation.status === 'completed' ? 'bg-green-100 text-green-800' :
                          conversation.status === 'active' ? 'bg-blue-100 text-blue-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {conversation.status}
                        </span>
                        {conversation.bookingCreated && (
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        )}
                      </div>
                    </div>
                    <div className="space-y-2">
                      {conversation.messages.slice(-3).map((message, index) => (
                        <div key={index} className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-xs px-3 py-2 rounded-lg text-sm ${
                            message.sender === 'user' 
                              ? 'bg-blue-500 text-white' 
                              : 'bg-gray-100 text-gray-900'
                          }`}>
                            <p>{message.message}</p>
                            {message.intent && (
                              <p className="text-xs opacity-75 mt-1">
                                Intent: {message.intent} ({Math.round((message.confidence || 0) * 100)}%)
                              </p>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Roster AI Tab */}
        {selectedTab === 'roster-ai' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Roster OCR Performance</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600">156</div>
                  <div className="text-sm text-gray-600">Rosters Processed</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">98%</div>
                  <div className="text-sm text-gray-600">OCR Accuracy</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600">1,247</div>
                  <div className="text-sm text-gray-600">Flights Extracted</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-yellow-600">2.3s</div>
                  <div className="text-sm text-gray-600">Avg Processing Time</div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Roster Uploads</h3>
              <div className="space-y-4">
                {[
                  { crew: 'Sarah Ahmed', flights: 8, accuracy: 98, status: 'completed' },
                  { crew: 'Maria Santos', flights: 6, accuracy: 95, status: 'completed' },
                  { crew: 'Ahmed Hassan', flights: 10, accuracy: 99, status: 'processing' }
                ].map((roster, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                        <Image className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{roster.crew}</p>
                        <p className="text-sm text-gray-500">{roster.flights} flights extracted</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <p className="text-sm font-medium text-gray-900">{roster.accuracy}% accuracy</p>
                        <p className={`text-xs ${
                          roster.status === 'completed' ? 'text-green-600' : 'text-blue-600'
                        }`}>
                          {roster.status}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Location AI Tab */}
        {selectedTab === 'location-ai' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Location Intelligence</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600">89%</div>
                  <div className="text-sm text-gray-600">Location Recognition</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">234</div>
                  <div className="text-sm text-gray-600">Checkpoints Verified</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600">12</div>
                  <div className="text-sm text-gray-600">New Locations Learned</div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Popular Pickup Locations</h3>
              <div className="space-y-4">
                {[
                  { location: 'Dubai Marina', count: 156, accuracy: 95 },
                  { location: 'Downtown Dubai', count: 134, accuracy: 92 },
                  { location: 'Emirates HQ', count: 98, accuracy: 99 },
                  { location: 'Jumeirah Lakes Towers', count: 87, accuracy: 88 }
                ].map((location, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <MapPin className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{location.location}</p>
                        <p className="text-sm text-gray-500">{location.count} pickups</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium text-gray-900">{location.accuracy}% accuracy</p>
                      <p className="text-xs text-gray-500">Recognition rate</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};