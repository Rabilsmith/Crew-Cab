import React, { useEffect, useState } from 'react';
import { CheckCircle, Clock, XCircle, AlertCircle } from 'lucide-react';
import { useAuth } from './auth/AuthProvider';
import { getProductByPriceId } from '../stripe-config';

interface SubscriptionData {
  subscription_status: string;
  price_id: string | null;
  current_period_end: number | null;
  cancel_at_period_end: boolean;
  payment_method_brand: string | null;
  payment_method_last4: string | null;
}

export const SubscriptionStatus: React.FC = () => {
  const [subscription, setSubscription] = useState<SubscriptionData | null>(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      fetchSubscription();
    }
  }, [user]);

  const fetchSubscription = async () => {
    try {
      // Mock subscription data for demo
      setTimeout(() => {
        setSubscription({
          subscription_status: 'active',
          price_id: 'price_1RjUhS4eIuYQSdmE0zk0fVLq',
          current_period_end: Math.floor(Date.now() / 1000) + (30 * 24 * 60 * 60), // 30 days from now
          cancel_at_period_end: false,
          payment_method_brand: 'visa',
          payment_method_last4: '4242'
        });
        setLoading(false);
      }, 1000);
    } catch (error) {
      console.error('Error fetching subscription:', error);
      setLoading(false);
    } finally {
      // Loading handled in setTimeout
    }
  };

  if (!user || loading) {
    return null;
  }

  if (!subscription || subscription.subscription_status === 'not_started') {
    return null;
  }

  const product = subscription.price_id ? getProductByPriceId(subscription.price_id) : null;
  const statusConfig = getStatusConfig(subscription.subscription_status);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div className="flex items-center space-x-3 mb-4">
        <statusConfig.icon className={`w-6 h-6 ${statusConfig.color}`} />
        <div>
          <h3 className="text-lg font-semibold text-gray-900">
            {product?.name || 'Subscription'}
          </h3>
          <p className={`text-sm font-medium ${statusConfig.color}`}>
            {statusConfig.label}
          </p>
        </div>
      </div>

      {subscription.current_period_end && (
        <div className="text-sm text-gray-600 mb-3">
          {subscription.cancel_at_period_end ? 'Expires' : 'Renews'} on{' '}
          {new Date(subscription.current_period_end * 1000).toLocaleDateString()}
        </div>
      )}

      {subscription.payment_method_brand && subscription.payment_method_last4 && (
        <div className="text-sm text-gray-600">
          Payment method: {subscription.payment_method_brand.toUpperCase()} ending in{' '}
          {subscription.payment_method_last4}
        </div>
      )}

      {subscription.cancel_at_period_end && (
        <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-sm text-yellow-800">
            Your subscription will not renew automatically.
          </p>
        </div>
      )}
    </div>
  );
};

function getStatusConfig(status: string) {
  switch (status) {
    case 'active':
      return {
        icon: CheckCircle,
        color: 'text-green-600',
        label: 'Active',
      };
    case 'trialing':
      return {
        icon: Clock,
        color: 'text-blue-600',
        label: 'Trial Period',
      };
    case 'past_due':
      return {
        icon: AlertCircle,
        color: 'text-yellow-600',
        label: 'Payment Due',
      };
    case 'canceled':
      return {
        icon: XCircle,
        color: 'text-red-600',
        label: 'Canceled',
      };
    case 'incomplete':
      return {
        icon: AlertCircle,
        color: 'text-yellow-600',
        label: 'Incomplete',
      };
    default:
      return {
        icon: Clock,
        color: 'text-gray-600',
        label: 'Unknown',
      };
  }
}