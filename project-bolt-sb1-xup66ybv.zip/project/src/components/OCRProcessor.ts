// Advanced OCR Processing for Crew Cab Roster Analysis

interface FlightData {
  date: string;
  time: string;
  flightNumber: string;
  destination: string;
  aircraft: string;
  pickupTime: string;
  estimatedDuration: number;
}

interface RosterAnalysis {
  flights: FlightData[];
  totalFlights: number;
  confidence: number;
  processingTime: number;
  errors: string[];
  suggestions: string[];
}

class OCRProcessor {
  private apiKey: string;
  private ocrEndpoint = 'https://api.ocr.space/parse/image';

  constructor(apiKey?: string) {
    this.apiKey = apiKey || 'demo_key';
  }

  /**
   * Process roster image and extract flight data
   */
  async processRosterImage(imageUrl: string): Promise<RosterAnalysis> {
    const startTime = Date.now();
    
    try {
      // Step 1: Extract text from image
      const extractedText = await this.extractTextFromImage(imageUrl);
      
      // Step 2: Parse flight information
      const flights = this.parseFlightData(extractedText);
      
      // Step 3: Validate and enhance data
      const validatedFlights = await this.validateFlightData(flights);
      
      // Step 4: Calculate pickup times
      const enhancedFlights = this.calculatePickupTimes(validatedFlights);
      
      const processingTime = Date.now() - startTime;
      
      return {
        flights: enhancedFlights,
        totalFlights: enhancedFlights.length,
        confidence: this.calculateConfidence(enhancedFlights, extractedText),
        processingTime,
        errors: [],
        suggestions: this.generateSuggestions(enhancedFlights)
      };
    } catch (error) {
      return {
        flights: [],
        totalFlights: 0,
        confidence: 0,
        processingTime: Date.now() - startTime,
        errors: [error.message],
        suggestions: ['Please ensure the roster image is clear and well-lit', 'Try uploading a higher resolution image']
      };
    }
  }

  /**
   * Extract text from image using OCR
   */
  private async extractTextFromImage(imageUrl: string): Promise<string> {
    // Mock OCR extraction for demo
    // In production, this would use actual OCR service
    const mockRosterText = `
      EMIRATES CREW ROSTER - JANUARY 2024
      
      Date        Time    Flight    Destination    Aircraft    
      15/01/24    06:15   EK001     London LHR     A380-800
      17/01/24    14:30   EK201     New York JFK   B777-300
      20/01/24    22:45   EK319     Tokyo NRT      A380-800
      23/01/24    08:00   EK183     Sydney SYD     A380-800
      26/01/24    16:20   EK025     Paris CDG      B777-300
      28/01/24    11:45   EK149     Mumbai BOM     B777-300
      30/01/24    19:30   EK407     Bangkok BKK    A380-800
    `;
    
    return mockRosterText;
  }

  /**
   * Parse flight data from extracted text
   */
  private parseFlightData(text: string): Partial<FlightData>[] {
    const flights: Partial<FlightData>[] = [];
    const lines = text.split('\n');
    
    // Flight data pattern: Date Time Flight Destination Aircraft
    const flightPattern = /(\d{2}\/\d{2}\/\d{2,4})\s+(\d{2}:\d{2})\s+(EK\d+)\s+([A-Za-z\s]+)\s+([A-Z0-9-]+)/g;
    
    for (const line of lines) {
      const match = flightPattern.exec(line);
      if (match) {
        flights.push({
          date: this.normalizeDate(match[1]),
          time: match[2],
          flightNumber: match[3],
          destination: match[4].trim(),
          aircraft: match[5]
        });
      }
    }
    
    return flights;
  }

  /**
   * Validate and enhance flight data
   */
  private async validateFlightData(flights: Partial<FlightData>[]): Promise<FlightData[]> {
    const validatedFlights: FlightData[] = [];
    
    for (const flight of flights) {
      if (this.isValidFlight(flight)) {
        validatedFlights.push({
          date: flight.date!,
          time: flight.time!,
          flightNumber: flight.flightNumber!,
          destination: flight.destination!,
          aircraft: flight.aircraft!,
          pickupTime: '', // Will be calculated
          estimatedDuration: this.estimateFlightDuration(flight.destination!)
        });
      }
    }
    
    return validatedFlights;
  }

  /**
   * Calculate pickup times based on flight times
   */
  private calculatePickupTimes(flights: FlightData[]): FlightData[] {
    return flights.map(flight => {
      const flightTime = new Date(`${flight.date} ${flight.time}`);
      
      // Calculate pickup time (2.5 hours before flight for international, 1.5 for domestic)
      const isInternational = this.isInternationalFlight(flight.destination);
      const hoursBeforeFlight = isInternational ? 2.5 : 1.5;
      
      const pickupTime = new Date(flightTime.getTime() - (hoursBeforeFlight * 60 * 60 * 1000));
      
      return {
        ...flight,
        pickupTime: pickupTime.toTimeString().slice(0, 5) // HH:MM format
      };
    });
  }

  /**
   * Calculate confidence score based on data quality
   */
  private calculateConfidence(flights: FlightData[], originalText: string): number {
    let confidence = 0;
    
    // Base confidence from successful extractions
    confidence += Math.min(flights.length * 10, 60);
    
    // Bonus for complete data
    const completeFlights = flights.filter(f => 
      f.date && f.time && f.flightNumber && f.destination && f.aircraft
    );
    confidence += (completeFlights.length / flights.length) * 30;
    
    // Bonus for recognizable patterns
    if (originalText.includes('EMIRATES') || originalText.includes('EK')) {
      confidence += 10;
    }
    
    return Math.min(confidence, 100);
  }

  /**
   * Generate suggestions for improvement
   */
  private generateSuggestions(flights: FlightData[]): string[] {
    const suggestions: string[] = [];
    
    if (flights.length === 0) {
      suggestions.push('No flights detected. Please ensure the roster is clearly visible.');
    } else if (flights.length < 5) {
      suggestions.push('Only a few flights detected. Consider uploading a clearer image.');
    }
    
    const missingData = flights.filter(f => !f.aircraft || !f.destination);
    if (missingData.length > 0) {
      suggestions.push('Some flight details are incomplete. Manual verification recommended.');
    }
    
    return suggestions;
  }

  /**
   * Helper methods
   */
  private normalizeDate(dateStr: string): string {
    // Convert DD/MM/YY to YYYY-MM-DD
    const parts = dateStr.split('/');
    const day = parts[0].padStart(2, '0');
    const month = parts[1].padStart(2, '0');
    let year = parts[2];
    
    if (year.length === 2) {
      year = '20' + year;
    }
    
    return `${year}-${month}-${day}`;
  }

  private isValidFlight(flight: Partial<FlightData>): boolean {
    return !!(flight.date && flight.time && flight.flightNumber && flight.destination);
  }

  private isInternationalFlight(destination: string): boolean {
    const domesticDestinations = ['Dubai', 'Abu Dhabi', 'Sharjah'];
    return !domesticDestinations.some(dest => destination.includes(dest));
  }

  private estimateFlightDuration(destination: string): number {
    // Estimate flight duration in hours based on destination
    const durationMap: { [key: string]: number } = {
      'London': 7,
      'New York': 12,
      'Tokyo': 9,
      'Sydney': 14,
      'Paris': 7,
      'Mumbai': 3,
      'Bangkok': 6
    };
    
    for (const [dest, duration] of Object.entries(durationMap)) {
      if (destination.includes(dest)) {
        return duration;
      }
    }
    
    return 6; // Default duration
  }

  /**
   * Process multiple roster images in batch
   */
  async processBatchRosters(imageUrls: string[]): Promise<{
    results: RosterAnalysis[];
    summary: {
      totalFlights: number;
      averageConfidence: number;
      totalProcessingTime: number;
    };
  }> {
    const results: RosterAnalysis[] = [];
    
    for (const imageUrl of imageUrls) {
      const result = await this.processRosterImage(imageUrl);
      results.push(result);
    }
    
    const summary = {
      totalFlights: results.reduce((sum, r) => sum + r.totalFlights, 0),
      averageConfidence: results.reduce((sum, r) => sum + r.confidence, 0) / results.length,
      totalProcessingTime: results.reduce((sum, r) => sum + r.processingTime, 0)
    };
    
    return { results, summary };
  }

  /**
   * Generate WhatsApp message for roster confirmation
   */
  generateRosterConfirmationMessage(analysis: RosterAnalysis): string {
    const { flights, totalFlights, confidence } = analysis;
    
    let message = `✅ *Roster Processed Successfully!*\n\n`;
    message += `📋 *${totalFlights} Flights Detected* (${Math.round(confidence)}% confidence)\n\n`;
    
    flights.slice(0, 5).forEach((flight, index) => {
      message += `${index + 1}. **${flight.date}** - ${flight.flightNumber}\n`;
      message += `   🛫 ${flight.time} to ${flight.destination}\n`;
      message += `   🚗 Pickup: ${flight.pickupTime}\n\n`;
    });
    
    if (flights.length > 5) {
      message += `... and ${flights.length - 5} more flights\n\n`;
    }
    
    const totalPrice = totalFlights * 60; // AED 60 per ride
    const bundlePrice = Math.floor(totalPrice * 0.9); // 10% discount
    const savings = totalPrice - bundlePrice;
    
    message += `💰 *Bundle Pricing:*\n`;
    message += `• Individual bookings: AED ${totalPrice}\n`;
    message += `• Bundle price: AED ${bundlePrice}\n`;
    message += `• Your savings: AED ${savings} (10% off)\n\n`;
    message += `✅ Shall I create all these bookings for you? Reply 'yes' to confirm.`;
    
    return message;
  }
}

export { OCRProcessor, FlightData, RosterAnalysis };