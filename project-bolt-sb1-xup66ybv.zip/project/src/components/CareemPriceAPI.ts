// Careem Price API integration (mock implementation)
// In production, this would integrate with Careem's partner API if available

interface LocationData {
  address: string;
  lat: number;
  lng: number;
  area: string;
}

interface CareemPriceResponse {
  price: number;
  currency: 'AED';
  estimatedDuration: number;
  surge: number;
  available: boolean;
}

class CareemPriceAPI {
  private apiKey?: string;
  private baseUrl = 'https://api.careem.com/v1'; // Mock URL

  // Fallback pricing based on actual Careem rates in Dubai
  private static readonly CAREEM_RATES = {
    baseFare: 5,
    ratePerKm: 3.5,
    ratePerMinute: 0.5,
    minimumFare: 25,
    bookingFee: 2,
    // Area-specific multipliers
    areaMultipliers: new Map([
      ['marina', 1.1],
      ['downtown', 1.0],
      ['deira', 0.9],
      ['jumeirah', 1.2],
      ['business bay', 1.0],
      ['bur dubai', 0.9],
      ['al barsha', 1.1],
      ['dubai hills', 1.3],
      ['jlt', 1.0],
      ['dubai south', 1.4] // Higher due to distance
    ])
  };

  constructor(apiKey?: string) {
    this.apiKey = apiKey;
  }

  /**
   * Get Careem price for a route
   */
  async getPrice(origin: LocationData, destination: LocationData): Promise<number | null> {
    if (this.apiKey) {
      try {
        // Try to get real-time pricing from Careem API
        const realTimePrice = await this.getRealTimePrice(origin, destination);
        if (realTimePrice) {
          return realTimePrice.price;
        }
      } catch (error) {
        console.warn('Careem API call failed, using fallback pricing');
      }
    }

    // Fallback to estimated pricing
    return this.calculateEstimatedPrice(origin, destination);
  }

  /**
   * Get real-time price from Careem API
   */
  private async getRealTimePrice(origin: LocationData, destination: LocationData): Promise<CareemPriceResponse | null> {
    if (!this.apiKey) return null;

    try {
      const response = await fetch(`${this.baseUrl}/price-estimate`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          origin: {
            lat: origin.lat,
            lng: origin.lng
          },
          destination: {
            lat: destination.lat,
            lng: destination.lng
          },
          service_type: 'careem_go' // Standard service
        })
      });

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Careem API error:', error);
      return null;
    }
  }

  /**
   * Calculate estimated price based on distance and known rates
   */
  private calculateEstimatedPrice(origin: LocationData, destination: LocationData): number {
    // Calculate base price using distance and time
    const distance = this.calculateDistance(origin, destination);
    const estimatedTime = this.calculateEstimatedTime(distance);
    
    const { baseFare, ratePerKm, ratePerMinute, minimumFare, bookingFee } = CareemPriceAPI.CAREEM_RATES;
    
    // Base calculation
    let price = baseFare + (distance * ratePerKm) + (estimatedTime * ratePerMinute) + bookingFee;
    
    // Apply area multiplier
    const areaMultiplier = CareemPriceAPI.CAREEM_RATES.areaMultipliers.get(origin.area.toLowerCase()) || 1.0;
    price *= areaMultiplier;
    
    // Apply surge pricing during peak hours
    const surgeMultiplier = this.getCurrentSurgeMultiplier();
    price *= surgeMultiplier;
    
    // Ensure minimum fare
    price = Math.max(price, minimumFare);
    
    return Math.round(price);
  }

  /**
   * Calculate distance between two points (Haversine formula)
   */
  private calculateDistance(origin: LocationData, destination: LocationData): number {
    const R = 6371; // Earth's radius in km
    const dLat = this.toRadians(destination.lat - origin.lat);
    const dLon = this.toRadians(destination.lng - origin.lng);
    
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(this.toRadians(origin.lat)) * Math.cos(this.toRadians(destination.lat)) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  /**
   * Convert degrees to radians
   */
  private toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }

  /**
   * Calculate estimated travel time based on distance
   */
  private calculateEstimatedTime(distance: number): number {
    // Assume average speed of 30 km/h in Dubai traffic
    const averageSpeed = 30;
    return (distance / averageSpeed) * 60; // Convert to minutes
  }

  /**
   * Get current surge multiplier based on time and demand
   */
  private getCurrentSurgeMultiplier(): number {
    const now = new Date();
    const hour = now.getHours();
    const dayOfWeek = now.getDay();
    
    let surge = 1.0;
    
    // Peak hours surge
    if ((hour >= 7 && hour <= 9) || (hour >= 17 && hour <= 19)) {
      surge = 1.3;
    }
    
    // Early morning surge (crew shift changes)
    if (hour >= 3 && hour <= 6) {
      surge = 1.2;
    }
    
    // Weekend surge
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      surge *= 1.1;
    }
    
    return surge;
  }

  /**
   * Get historical price data for analytics
   */
  async getHistoricalPrices(route: string, days: number = 30): Promise<Array<{
    date: string;
    price: number;
    surge: number;
  }>> {
    // Mock historical data
    const prices = [];
    const today = new Date();
    
    for (let i = 0; i < days; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      
      prices.push({
        date: date.toISOString().split('T')[0],
        price: Math.round(50 + Math.random() * 30), // Random price between 50-80
        surge: Math.round((1 + Math.random() * 0.5) * 100) / 100 // Surge between 1.0-1.5
      });
    }
    
    return prices;
  }

  /**
   * Get available service types and their pricing
   */
  async getServiceTypes(): Promise<Array<{
    type: string;
    name: string;
    description: string;
    baseFare: number;
    ratePerKm: number;
    minimumFare: number;
  }>> {
    return [
      {
        type: 'careem_go',
        name: 'Careem GO',
        description: 'Affordable rides for everyday use',
        baseFare: 5,
        ratePerKm: 3.5,
        minimumFare: 25
      },
      {
        type: 'careem_plus',
        name: 'Careem PLUS',
        description: 'Premium rides with newer cars',
        baseFare: 8,
        ratePerKm: 4.0,
        minimumFare: 30
      },
      {
        type: 'careem_business',
        name: 'Careem Business',
        description: 'Professional rides for business travelers',
        baseFare: 12,
        ratePerKm: 5.0,
        minimumFare: 40
      }
    ];
  }

  /**
   * Check if service is available in area
   */
  async isServiceAvailable(lat: number, lng: number): Promise<boolean> {
    // Check if coordinates are within Dubai service area
    const dubaiBounds = {
      north: 25.5,
      south: 24.8,
      east: 55.8,
      west: 54.9
    };
    
    return lat >= dubaiBounds.south && lat <= dubaiBounds.north &&
           lng >= dubaiBounds.west && lng <= dubaiBounds.east;
  }
}

export { CareemPriceAPI };