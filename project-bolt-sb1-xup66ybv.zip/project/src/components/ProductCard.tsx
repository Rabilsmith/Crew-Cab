import React, { useState } from 'react';
import { Car, CreditCard, Loader2 } from 'lucide-react';
import { StripeProduct } from '../stripe-config';
import { useAuth } from './auth/AuthProvider';

interface ProductCardProps {
  product: StripeProduct;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const { session } = useAuth();

  const handlePurchase = async () => {
    if (!session) {
      setMessage({ type: 'error', text: 'Please sign in to make a purchase' });
      return;
    }

    setLoading(true);
    setMessage(null);

    try {
      // Mock checkout for demo
      setTimeout(() => {
        window.location.href = `/success?session_id=demo_session_${Date.now()}`;
      }, 2000);
    } catch (error: any) {
      console.error('Checkout error:', error);
      setMessage({ 
        type: 'error', 
        text: error.message || 'Failed to create checkout session' 
      });
      setLoading(false);
    } finally {
      // Loading will be set to false by redirect or error
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-shadow">
      <div className="flex items-center justify-center w-16 h-16 bg-blue-100 rounded-lg mb-6 mx-auto">
        <Car className="w-8 h-8 text-blue-600" />
      </div>
      
      <div className="text-center mb-6">
        <h3 className="text-xl font-bold text-gray-900 mb-2">{product.name}</h3>
        <p className="text-gray-600 mb-4">{product.description}</p>
        
        <div className="bg-blue-50 rounded-lg p-4 mb-4">
          <div className="text-sm text-blue-600 font-medium mb-1">Premium Features</div>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• 20% cheaper than Careem</li>
            <li>• Vetted professional drivers</li>
            <li>• 24/7 reliable service</li>
            <li>• WhatsApp booking system</li>
          </ul>
        </div>
      </div>

      {message && (
        <div className={`mb-4 p-3 rounded-lg text-sm ${
          message.type === 'error' 
            ? 'bg-red-50 border border-red-200 text-red-700' 
            : 'bg-green-50 border border-green-200 text-green-700'
        }`}>
          {message.text}
        </div>
      )}

      <button
        onClick={handlePurchase}
        disabled={loading || !session}
        className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center space-x-2"
      >
        {loading ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Processing...</span>
          </>
        ) : (
          <>
            <CreditCard className="w-4 h-4" />
            <span>Book Now</span>
          </>
        )}
      </button>

      {!session && (
        <p className="text-center text-sm text-gray-500 mt-3">
          Sign in to book your ride
        </p>
      )}
    </div>
  );
};