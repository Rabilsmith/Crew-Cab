// Dynamic Pricing Engine for Crew Cab
import { GoogleMapsAPI } from './GoogleMapsAPI';
import { CareemPriceAPI } from './CareemPriceAPI';

interface PriceCalculation {
  careemPrice: number;
  crewCabPrice: number;
  platformFee: number;
  driverPayout: number;
  savings: number;
  savingsPercentage: number;
}

interface LocationData {
  address: string;
  lat: number;
  lng: number;
  area: string;
}

class PricingEngine {
  private static readonly PLATFORM_FEE = 10; // AED 10 fixed platform fee
  private static readonly DISCOUNT_RATE = 0.20; // 20% discount
  private static readonly EMIRATES_HQ_COORDS = { lat: 25.2532, lng: 55.3657 };

  // Fallback price zones when APIs are unavailable
  private static readonly FALLBACK_ZONES = new Map([
    ['marina', { careemPrice: 75, distance: 15 }],
    ['downtown', { careemPrice: 65, distance: 12 }],
    ['deira', { careemPrice: 45, distance: 8 }],
    ['jumeirah', { careemPrice: 85, distance: 18 }],
    ['business bay', { careemPrice: 55, distance: 10 }],
    ['bur dubai', { careemPrice: 50, distance: 9 }],
    ['al barsha', { careemPrice: 70, distance: 16 }],
    ['dubai hills', { careemPrice: 80, distance: 20 }],
    ['jlt', { careemPrice: 65, distance: 14 }],
    ['dubai south', { careemPrice: 60, distance: 35 }]
  ]);

  private googleMapsAPI: GoogleMapsAPI;
  private careemPriceAPI: CareemPriceAPI;

  constructor(googleMapsAPIKey: string, careemAPIKey?: string) {
    this.googleMapsAPI = new GoogleMapsAPI(googleMapsAPIKey);
    this.careemPriceAPI = new CareemPriceAPI(careemAPIKey);
  }

  /**
   * Calculate price for a ride from pickup location to Emirates HQ
   */
  async calculatePrice(pickupAddress: string, dropoffAddress: string = 'Emirates HQ'): Promise<PriceCalculation> {
    try {
      // Get location data
      const pickupLocation = await this.geocodeAddress(pickupAddress);
      const dropoffLocation = dropoffAddress === 'Emirates HQ' 
        ? { ...PricingEngine.EMIRATES_HQ_COORDS, address: 'Emirates HQ', area: 'emirates_hq' }
        : await this.geocodeAddress(dropoffAddress);

      // Get distance and duration
      const distanceData = await this.getDistanceMatrix(pickupLocation, dropoffLocation);
      
      // Get Careem price (with fallback)
      const careemPrice = await this.getCareemPrice(pickupLocation, dropoffLocation, distanceData);
      
      // Calculate Crew Cab price
      const crewCabPrice = Math.round(careemPrice * (1 - PricingEngine.DISCOUNT_RATE));
      const driverPayout = crewCabPrice - PricingEngine.PLATFORM_FEE;
      const savings = careemPrice - crewCabPrice;
      const savingsPercentage = Math.round((savings / careemPrice) * 100);

      return {
        careemPrice,
        crewCabPrice,
        platformFee: PricingEngine.PLATFORM_FEE,
        driverPayout: Math.max(0, driverPayout), // Ensure non-negative
        savings,
        savingsPercentage
      };

    } catch (error) {
      console.error('Error calculating price:', error);
      // Fallback to zone-based pricing
      return this.getFallbackPrice(pickupAddress);
    }
  }

  /**
   * Calculate bundle pricing for multiple rides
   */
  calculateBundlePrice(rides: Array<{ pickupAddress: string, dropoffAddress: string }>, bundleType: 'weekly' | 'monthly' | 'custom'): Promise<{
    totalPrice: number;
    pricePerRide: number;
    totalSavings: number;
    rides: PriceCalculation[];
  }> {
    // This would calculate bundle pricing with additional discounts
    // Implementation would depend on business rules
    return Promise.resolve({
      totalPrice: 0,
      pricePerRide: 0,
      totalSavings: 0,
      rides: []
    });
  }

  /**
   * Get surge pricing multiplier based on demand
   */
  private async getSurgePricing(pickupLocation: LocationData, pickupTime: Date): Promise<number> {
    // Factors affecting surge pricing:
    // 1. Time of day (early morning flights = higher demand)
    // 2. Weather conditions
    // 3. Special events
    // 4. Number of available drivers
    
    const hour = pickupTime.getHours();
    let surgeMultiplier = 1.0;

    // Early morning surge (3-6 AM)
    if (hour >= 3 && hour <= 6) {
      surgeMultiplier = 1.2;
    }

    // Late night surge (11 PM - 2 AM)
    if (hour >= 23 || hour <= 2) {
      surgeMultiplier = 1.1;
    }

    // Airport area surge during peak hours
    if (this.isAirportArea(pickupLocation.area)) {
      surgeMultiplier *= 1.1;
    }

    return surgeMultiplier;
  }

  /**
   * Geocode address to get coordinates and area
   */
  private async geocodeAddress(address: string): Promise<LocationData> {
    try {
      const result = await this.googleMapsAPI.geocode(address);
      return {
        address: result.formatted_address,
        lat: result.geometry.location.lat,
        lng: result.geometry.location.lng,
        area: this.extractAreaFromAddress(result.formatted_address)
      };
    } catch (error) {
      throw new Error(`Failed to geocode address: ${address}`);
    }
  }

  /**
   * Get distance and duration between two points
   */
  private async getDistanceMatrix(origin: LocationData, destination: LocationData): Promise<{
    distance: number;
    duration: number;
    trafficDuration: number;
  }> {
    try {
      const result = await this.googleMapsAPI.getDistanceMatrix(
        `${origin.lat},${origin.lng}`,
        `${destination.lat},${destination.lng}`
      );

      return {
        distance: result.distance.value / 1000, // Convert to km
        duration: result.duration.value / 60,   // Convert to minutes
        trafficDuration: result.duration_in_traffic?.value / 60 || result.duration.value / 60
      };
    } catch (error) {
      throw new Error('Failed to get distance matrix');
    }
  }

  /**
   * Get Careem price for comparison
   */
  private async getCareemPrice(origin: LocationData, destination: LocationData, distanceData: any): Promise<number> {
    try {
      // Try to get real-time Careem pricing
      const careemPrice = await this.careemPriceAPI.getPrice(origin, destination);
      if (careemPrice) {
        return careemPrice;
      }
    } catch (error) {
      console.warn('Careem API unavailable, using fallback pricing');
    }

    // Fallback to zone-based pricing
    const zone = PricingEngine.FALLBACK_ZONES.get(origin.area.toLowerCase());
    if (zone) {
      return zone.careemPrice;
    }

    // Ultimate fallback: distance-based calculation
    return this.calculateDistanceBasedPrice(distanceData.distance);
  }

  /**
   * Calculate price based on distance when other methods fail
   */
  private calculateDistanceBasedPrice(distanceKm: number): number {
    // Base fare + distance rate
    const baseFare = 5; // AED 5 base fare
    const ratePerKm = 3; // AED 3 per km
    const minimumFare = 25; // AED 25 minimum

    const calculatedPrice = baseFare + (distanceKm * ratePerKm);
    return Math.max(minimumFare, Math.round(calculatedPrice));
  }

  /**
   * Extract area name from full address
   */
  private extractAreaFromAddress(address: string): string {
    const addressLower = address.toLowerCase();
    
    // Check for known areas
    for (const [area] of PricingEngine.FALLBACK_ZONES) {
      if (addressLower.includes(area)) {
        return area;
      }
    }

    // Try to extract from address components
    const addressParts = address.split(',');
    if (addressParts.length >= 2) {
      return addressParts[1].trim().toLowerCase();
    }

    return 'unknown';
  }

  /**
   * Check if location is near airport
   */
  private isAirportArea(area: string): boolean {
    const airportAreas = ['dubai south', 'al garhoud', 'emirates hq'];
    return airportAreas.some(airportArea => area.toLowerCase().includes(airportArea));
  }

  /**
   * Fallback pricing when APIs are unavailable
   */
  private getFallbackPrice(pickupAddress: string): PriceCalculation {
    const addressLower = pickupAddress.toLowerCase();
    let careemPrice = 60; // Default price

    // Check against known zones
    for (const [area, zoneData] of PricingEngine.FALLBACK_ZONES) {
      if (addressLower.includes(area)) {
        careemPrice = zoneData.careemPrice;
        break;
      }
    }

    const crewCabPrice = Math.round(careemPrice * (1 - PricingEngine.DISCOUNT_RATE));
    const driverPayout = crewCabPrice - PricingEngine.PLATFORM_FEE;
    const savings = careemPrice - crewCabPrice;
    const savingsPercentage = Math.round((savings / careemPrice) * 100);

    return {
      careemPrice,
      crewCabPrice,
      platformFee: PricingEngine.PLATFORM_FEE,
      driverPayout: Math.max(0, driverPayout),
      savings,
      savingsPercentage
    };
  }

  /**
   * Get pricing for popular routes (cached for performance)
   */
  static getPopularRoutes(): Array<{
    name: string;
    pickup: string;
    dropoff: string;
    estimatedPrice: number;
    estimatedDuration: string;
  }> {
    return [
      {
        name: 'Marina to Emirates HQ',
        pickup: 'Dubai Marina',
        dropoff: 'Emirates HQ',
        estimatedPrice: 60,
        estimatedDuration: '25-30 mins'
      },
      {
        name: 'Downtown to Emirates HQ',
        pickup: 'Downtown Dubai',
        dropoff: 'Emirates HQ',
        estimatedPrice: 52,
        estimatedDuration: '20-25 mins'
      },
      {
        name: 'Deira to Emirates HQ',
        pickup: 'Deira',
        dropoff: 'Emirates HQ',
        estimatedPrice: 36,
        estimatedDuration: '15-20 mins'
      },
      {
        name: 'Jumeirah to Emirates HQ',
        pickup: 'Jumeirah',
        dropoff: 'Emirates HQ',
        estimatedPrice: 68,
        estimatedDuration: '30-35 mins'
      }
    ];
  }
}

export default PricingEngine;