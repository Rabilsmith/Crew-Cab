// Stripe Payment Integration for Crew Cab

interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: 'requires_payment_method' | 'requires_confirmation' | 'succeeded' | 'canceled';
  client_secret: string;
}

interface PaymentMethod {
  id: string;
  type: 'card';
  card: {
    brand: string;
    last4: string;
    exp_month: number;
    exp_year: number;
  };
}

interface Booking {
  id: string;
  crewId: string;
  amount: number;
  currency: 'AED';
  description: string;
  metadata?: Record<string, string>;
}

interface BundlePackage {
  id: string;
  name: string;
  rides: number;
  price: number;
  discount: number;
  validityDays: number;
}

class StripePaymentService {
  private apiKey: string;
  private webhookSecret: string;
  private baseUrl = 'https://api.stripe.com/v1';

  constructor(apiKey: string, webhookSecret: string) {
    this.apiKey = apiKey;
    this.webhookSecret = webhookSecret;
  }

  /**
   * Create payment intent for single ride
   */
  async createRidePaymentIntent(booking: Booking): Promise<{
    paymentIntent: PaymentIntent;
    checkoutUrl: string;
  }> {
    try {
      const response = await fetch(`${this.baseUrl}/payment_intents`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          amount: (booking.amount * 100).toString(), // Convert to cents
          currency: booking.currency.toLowerCase(),
          description: booking.description,
          'metadata[booking_id]': booking.id,
          'metadata[crew_id]': booking.crewId,
          'metadata[type]': 'single_ride'
        })
      });

      if (!response.ok) {
        throw new Error(`Payment intent creation failed: ${response.status}`);
      }

      const paymentIntent = await response.json();
      
      // Create checkout session
      const checkoutUrl = await this.createCheckoutSession(paymentIntent.id, booking);
      
      return {
        paymentIntent,
        checkoutUrl
      };
    } catch (error) {
      console.error('Error creating payment intent:', error);
      throw error;
    }
  }

  /**
   * Create checkout session for bundle purchase
   */
  async createBundleCheckoutSession(crewId: string, bundlePackage: BundlePackage, rides: Array<{
    pickupLocation: string;
    dropoffLocation: string;
    scheduledTime: string;
  }>): Promise<string> {
    try {
      const response = await fetch(`${this.baseUrl}/checkout/sessions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          'payment_method_types[]': 'card',
          'line_items[0][price_data][currency]': 'aed',
          'line_items[0][price_data][product_data][name]': bundlePackage.name,
          'line_items[0][price_data][product_data][description]': `${bundlePackage.rides} rides - Valid for ${bundlePackage.validityDays} days`,
          'line_items[0][price_data][unit_amount]': (bundlePackage.price * 100).toString(),
          'line_items[0][quantity]': '1',
          mode: 'payment',
          success_url: `${process.env.REACT_APP_BASE_URL}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: `${process.env.REACT_APP_BASE_URL}/payment/cancel`,
          'metadata[crew_id]': crewId,
          'metadata[bundle_id]': bundlePackage.id,
          'metadata[type]': 'bundle_purchase',
          'metadata[rides_count]': bundlePackage.rides.toString()
        })
      });

      if (!response.ok) {
        throw new Error(`Checkout session creation failed: ${response.status}`);
      }

      const session = await response.json();
      return session.url;
    } catch (error) {
      console.error('Error creating bundle checkout session:', error);
      throw error;
    }
  }

  /**
   * Create simple checkout session for single ride
   */
  private async createCheckoutSession(paymentIntentId: string, booking: Booking): Promise<string> {
    try {
      const response = await fetch(`${this.baseUrl}/checkout/sessions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          'payment_method_types[]': 'card',
          'line_items[0][price_data][currency]': 'aed',
          'line_items[0][price_data][product_data][name]': 'Crew Cab Ride',
          'line_items[0][price_data][product_data][description]': booking.description,
          'line_items[0][price_data][unit_amount]': (booking.amount * 100).toString(),
          'line_items[0][quantity]': '1',
          mode: 'payment',
          success_url: `${process.env.REACT_APP_BASE_URL}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: `${process.env.REACT_APP_BASE_URL}/payment/cancel`,
          'metadata[payment_intent_id]': paymentIntentId,
          'metadata[booking_id]': booking.id,
          'metadata[crew_id]': booking.crewId
        })
      });

      if (!response.ok) {
        throw new Error(`Checkout session creation failed: ${response.status}`);
      }

      const session = await response.json();
      return session.url;
    } catch (error) {
      console.error('Error creating checkout session:', error);
      throw error;
    }
  }

  /**
   * Handle webhook events from Stripe
   */
  async handleWebhookEvent(payload: string, signature: string): Promise<void> {
    try {
      // Verify webhook signature
      const event = await this.verifyWebhookSignature(payload, signature);
      
      switch (event.type) {
        case 'payment_intent.succeeded':
          await this.handlePaymentSucceeded(event.data.object);
          break;
        
        case 'payment_intent.payment_failed':
          await this.handlePaymentFailed(event.data.object);
          break;
        
        case 'checkout.session.completed':
          await this.handleCheckoutCompleted(event.data.object);
          break;
        
        default:
          console.log(`Unhandled event type: ${event.type}`);
      }
    } catch (error) {
      console.error('Webhook handling error:', error);
      throw error;
    }
  }

  /**
   * Verify webhook signature
   */
  private async verifyWebhookSignature(payload: string, signature: string): Promise<any> {
    // In a real implementation, you would verify the signature using Stripe's library
    // For now, we'll parse the payload directly
    try {
      return JSON.parse(payload);
    } catch (error) {
      throw new Error('Invalid webhook payload');
    }
  }

  /**
   * Handle successful payment
   */
  private async handlePaymentSucceeded(paymentIntent: any): Promise<void> {
    const bookingId = paymentIntent.metadata?.booking_id;
    const crewId = paymentIntent.metadata?.crew_id;
    const type = paymentIntent.metadata?.type;

    if (type === 'single_ride') {
      // Update booking status to confirmed
      await this.updateBookingStatus(bookingId, 'confirmed');
      
      // Assign driver
      await this.assignDriver(bookingId);
      
      // Send confirmation to crew member
      await this.sendPaymentConfirmation(crewId, bookingId);
    } else if (type === 'bundle_purchase') {
      // Add prepaid rides to crew member's account
      await this.addPrepaidRides(crewId, paymentIntent.metadata?.rides_count);
      
      // Send bundle confirmation
      await this.sendBundleConfirmation(crewId, paymentIntent.metadata?.bundle_id);
    }
  }

  /**
   * Handle failed payment
   */
  private async handlePaymentFailed(paymentIntent: any): Promise<void> {
    const bookingId = paymentIntent.metadata?.booking_id;
    const crewId = paymentIntent.metadata?.crew_id;

    // Update booking status to payment_failed
    await this.updateBookingStatus(bookingId, 'payment_failed');
    
    // Send failure notification to crew member
    await this.sendPaymentFailureNotification(crewId, bookingId);
  }

  /**
   * Handle checkout session completed
   */
  private async handleCheckoutCompleted(session: any): Promise<void> {
    const type = session.metadata?.type;
    
    if (type === 'bundle_purchase') {
      const crewId = session.metadata?.crew_id;
      const bundleId = session.metadata?.bundle_id;
      
      // Process bundle purchase
      await this.processBundlePurchase(crewId, bundleId, session.amount_total / 100);
    }
  }

  /**
   * Create refund for a ride
   */
  async createRefund(paymentIntentId: string, amount?: number, reason?: string): Promise<any> {
    try {
      const body = new URLSearchParams({
        payment_intent: paymentIntentId
      });

      if (amount) {
        body.append('amount', (amount * 100).toString());
      }

      if (reason) {
        body.append('reason', reason);
      }

      const response = await fetch(`${this.baseUrl}/refunds`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body
      });

      if (!response.ok) {
        throw new Error(`Refund creation failed: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error creating refund:', error);
      throw error;
    }
  }

  /**
   * Get payment method details
   */
  async getPaymentMethod(paymentMethodId: string): Promise<PaymentMethod> {
    try {
      const response = await fetch(`${this.baseUrl}/payment_methods/${paymentMethodId}`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`
        }
      });

      if (!response.ok) {
        throw new Error(`Payment method retrieval failed: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error retrieving payment method:', error);
      throw error;
    }
  }

  /**
   * Generate WhatsApp payment link message
   */
  generateWhatsAppPaymentMessage(checkoutUrl: string, amount: number, description: string): string {
    return `💳 *Payment Required*\n\n${description}\nAmount: AED ${amount}\n\n🔗 Click here to pay securely:\n${checkoutUrl}\n\n✅ Your driver will be assigned after payment confirmation.\n\n🔒 Secure payment powered by Stripe`;
  }

  /**
   * Generate bundle purchase message
   */
  generateBundlePaymentMessage(checkoutUrl: string, bundlePackage: BundlePackage): string {
    return `🎯 *${bundlePackage.name}*\n\n✈️ ${bundlePackage.rides} rides included\n💰 Total: AED ${bundlePackage.price}\n🎉 Save AED ${bundlePackage.discount}\n⏰ Valid for ${bundlePackage.validityDays} days\n\n🔗 Click here to purchase:\n${checkoutUrl}\n\n🔒 Secure payment powered by Stripe`;
  }

  // Mock methods for database operations
  private async updateBookingStatus(bookingId: string, status: string): Promise<void> {
    // Database update logic
    console.log(`Updating booking ${bookingId} status to ${status}`);
  }

  private async assignDriver(bookingId: string): Promise<void> {
    // Driver assignment logic
    console.log(`Assigning driver to booking ${bookingId}`);
  }

  private async sendPaymentConfirmation(crewId: string, bookingId: string): Promise<void> {
    // WhatsApp notification logic
    console.log(`Sending payment confirmation to crew ${crewId} for booking ${bookingId}`);
  }

  private async sendPaymentFailureNotification(crewId: string, bookingId: string): Promise<void> {
    // WhatsApp notification logic
    console.log(`Sending payment failure notification to crew ${crewId} for booking ${bookingId}`);
  }

  private async addPrepaidRides(crewId: string, ridesCount: string): Promise<void> {
    // Add prepaid rides to crew member's account
    console.log(`Adding ${ridesCount} prepaid rides to crew ${crewId}`);
  }

  private async sendBundleConfirmation(crewId: string, bundleId: string): Promise<void> {
    // Send bundle purchase confirmation
    console.log(`Sending bundle confirmation to crew ${crewId} for bundle ${bundleId}`);
  }

  private async processBundlePurchase(crewId: string, bundleId: string, amount: number): Promise<void> {
    // Process bundle purchase
    console.log(`Processing bundle purchase for crew ${crewId}, bundle ${bundleId}, amount ${amount}`);
  }
}

export default StripePaymentService;