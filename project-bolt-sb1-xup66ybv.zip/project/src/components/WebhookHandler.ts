// WhatsApp Webhook Handler for Crew Cab
// This would be implemented as a separate service/API

interface WhatsAppMessage {
  from: string;
  body: string;
  timestamp: string;
  messageType: 'text' | 'image' | 'document';
}

interface CrewMember {
  phoneNumber: string;
  name: string;
  crewId: string;
  homeAddress?: string;
  prepaidBalance: number;
}

interface Driver {
  phoneNumber: string;
  name: string;
  carModel: string;
  plateNumber: string;
  isApproved: boolean;
  preferredAreas: string[];
}

interface Booking {
  id: string;
  crewPhoneNumber: string;
  pickupLocation: string;
  dropoffLocation: string;
  pickupTime: string;
  price: number;
  status: 'pending_payment' | 'confirmed' | 'driver_assigned' | 'in_progress' | 'completed';
  driverPhoneNumber?: string;
  paymentLink?: string;
  isFromRoster: boolean;
}

class CrewCabWebhookHandler {
  private priceZones = new Map([
    ['marina', { careemPrice: 75, crewCabPrice: 60 }],
    ['downtown', { careemPrice: 65, crewCabPrice: 52 }],
    ['deira', { careemPrice: 45, crewCabPrice: 36 }],
    ['jumeirah', { careemPrice: 85, crewCabPrice: 68 }],
    ['business bay', { careemPrice: 55, crewCabPrice: 44 }]
  ]);

  async handleIncomingMessage(message: WhatsAppMessage): Promise<void> {
    const phoneNumber = message.from;
    const messageBody = message.body.toLowerCase().trim();

    // Check if it's a crew member or driver
    const crewMember = await this.getCrewMember(phoneNumber);
    const driver = await this.getDriver(phoneNumber);

    if (crewMember) {
      await this.handleCrewMessage(crewMember, messageBody, message);
    } else if (driver) {
      await this.handleDriverMessage(driver, messageBody, message);
    } else {
      await this.handleNewUser(phoneNumber, messageBody);
    }
  }

  private async handleCrewMessage(crew: CrewMember, messageBody: string, message: WhatsAppMessage): Promise<void> {
    // Roster upload flow
    if (messageBody.includes('upload roster') || messageBody.includes('roster upload')) {
      await this.sendMessage(crew.phoneNumber, this.getTemplate('roster_upload_request'));
      return;
    }

    // Manual booking flow
    if (messageBody.includes('pickup from') || messageBody.includes('pickup at')) {
      await this.handleManualBooking(crew, messageBody);
      return;
    }

    // Bundle pricing inquiry
    if (messageBody.includes('bundle') || messageBody.includes('pricing')) {
      await this.sendMessage(crew.phoneNumber, this.getTemplate('bundle_pricing'));
      return;
    }

    // Image upload (roster)
    if (message.messageType === 'image') {
      await this.processRosterImage(crew, message);
      return;
    }

    // Default help message
    await this.sendMessage(crew.phoneNumber, this.getTemplate('crew_help'));
  }

  private async handleDriverMessage(driver: Driver, messageBody: string, message: WhatsAppMessage): Promise<void> {
    // Pickup confirmation
    if (messageBody.startsWith('crewcab#pickup#')) {
      const rideId = messageBody.split('#')[2];
      await this.confirmPickup(driver, rideId);
      return;
    }

    // Dropoff confirmation
    if (messageBody.startsWith('crewcab#dropoff#')) {
      const rideId = messageBody.split('#')[2];
      await this.confirmDropoff(driver, rideId);
      return;
    }

    // Status update
    if (messageBody.includes('status') || messageBody.includes('rides')) {
      await this.sendDriverStatus(driver);
      return;
    }

    // Default driver help
    await this.sendMessage(driver.phoneNumber, this.getTemplate('driver_help'));
  }

  private async handleNewUser(phoneNumber: string, messageBody: string): Promise<void> {
    if (messageBody.includes('join driver') || messageBody.includes('driver join')) {
      await this.startDriverOnboarding(phoneNumber);
    } else {
      await this.sendMessage(phoneNumber, this.getTemplate('welcome_new_user'));
    }
  }

  private async handleManualBooking(crew: CrewMember, messageBody: string): Promise<void> {
    // Parse booking details from message
    const bookingDetails = this.parseBookingMessage(messageBody);
    
    if (!bookingDetails) {
      await this.sendMessage(crew.phoneNumber, this.getTemplate('booking_format_error'));
      return;
    }

    // Calculate price
    const price = this.calculatePrice(bookingDetails.pickupArea);
    
    // Create booking
    const booking: Booking = {
      id: this.generateBookingId(),
      crewPhoneNumber: crew.phoneNumber,
      pickupLocation: bookingDetails.pickupLocation,
      dropoffLocation: bookingDetails.dropoffLocation,
      pickupTime: bookingDetails.pickupTime,
      price: price,
      status: 'pending_payment',
      isFromRoster: false
    };

    await this.saveBooking(booking);

    // Generate Stripe payment link
    const paymentLink = await this.generatePaymentLink(booking);
    booking.paymentLink = paymentLink;

    // Send payment request
    await this.sendMessage(crew.phoneNumber, this.getTemplate('payment_request', {
      route: `${bookingDetails.pickupLocation} → ${bookingDetails.dropoffLocation}`,
      price: price,
      paymentLink: paymentLink
    }));
  }

  private async processRosterImage(crew: CrewMember, message: WhatsAppMessage): Promise<void> {
    try {
      // Download image and process with OCR
      const imageUrl = await this.downloadWhatsAppImage(message);
      const rosterData = await this.processRosterWithOCR(imageUrl);
      
      // Generate rides from roster
      const rides = this.generateRidesFromRoster(rosterData, crew);
      
      // Calculate bundle price
      const totalPrice = rides.reduce((sum, ride) => sum + ride.price, 0);
      const bundlePrice = Math.floor(totalPrice * 0.9); // 10% discount
      
      // Create bundle payment link
      const paymentLink = await this.generateBundlePaymentLink(rides, bundlePrice);
      
      await this.sendMessage(crew.phoneNumber, this.getTemplate('roster_processed', {
        rideCount: rides.length,
        totalPrice: bundlePrice,
        paymentLink: paymentLink
      }));
      
    } catch (error) {
      await this.sendMessage(crew.phoneNumber, this.getTemplate('roster_processing_error'));
    }
  }

  private async confirmPickup(driver: Driver, rideId: string): Promise<void> {
    const booking = await this.getBooking(rideId);
    if (!booking) {
      await this.sendMessage(driver.phoneNumber, 'Ride not found. Please check the ride ID.');
      return;
    }

    booking.status = 'in_progress';
    await this.saveBooking(booking);

    // Notify crew member
    const crewMember = await this.getCrewMember(booking.crewPhoneNumber);
    if (crewMember) {
      await this.sendMessage(crewMember.phoneNumber, `✅ ${driver.name} has picked you up. Have a safe journey!`);
    }

    await this.sendMessage(driver.phoneNumber, `✅ Pickup confirmed for ride ${rideId}. Don't forget to confirm dropoff when complete.`);
  }

  private async confirmDropoff(driver: Driver, rideId: string): Promise<void> {
    const booking = await this.getBooking(rideId);
    if (!booking) {
      await this.sendMessage(driver.phoneNumber, 'Ride not found. Please check the ride ID.');
      return;
    }

    booking.status = 'completed';
    await this.saveBooking(booking);

    // Calculate driver payout (price - platform fee)
    const driverPayout = booking.price - 10;
    await this.addDriverPayout(driver.phoneNumber, driverPayout);

    // Notify crew member
    const crewMember = await this.getCrewMember(booking.crewPhoneNumber);
    if (crewMember) {
      await this.sendMessage(crewMember.phoneNumber, '🎉 Ride completed! Thank you for using Crew Cab.');
    }

    await this.sendMessage(driver.phoneNumber, `✅ Ride ${rideId} completed. AED ${driverPayout} added to your pending payout.`);
  }

  private parseBookingMessage(message: string): { pickupLocation: string, dropoffLocation: string, pickupTime: string, pickupArea: string } | null {
    // Simple parsing logic - in production, use more sophisticated NLP
    const pickupMatch = message.match(/pickup from (.+?) at (.+?)(?:\s|$)/i);
    if (!pickupMatch) return null;

    const pickupLocation = pickupMatch[1].trim();
    const pickupTime = pickupMatch[2].trim();
    const pickupArea = this.extractAreaFromLocation(pickupLocation);

    return {
      pickupLocation,
      dropoffLocation: 'Emirates HQ',
      pickupTime,
      pickupArea
    };
  }

  private extractAreaFromLocation(location: string): string {
    const lowerLocation = location.toLowerCase();
    for (const area of this.priceZones.keys()) {
      if (lowerLocation.includes(area)) {
        return area;
      }
    }
    return 'marina'; // Default area
  }

  private calculatePrice(area: string): number {
    const zonePrice = this.priceZones.get(area);
    return zonePrice ? zonePrice.crewCabPrice : 60; // Default price
  }

  private generateBookingId(): string {
    return 'RIDE' + Date.now().toString().slice(-6);
  }

  private getTemplate(templateName: string, params?: any): string {
    const templates = {
      roster_upload_request: `📋 *Upload Your Roster*\n\nPlease upload your monthly schedule as a JPG screenshot.\n\nI'll automatically schedule your rides and send you a bundle payment link.\n\n💰 Save 10% with prepaid bundles!`,
      
      payment_request: `💳 *Payment Required*\n\nRoute: ${params?.route}\nYour price: AED ${params?.price} (20% cheaper than Careem)\n\nClick here to pay: ${params?.paymentLink}\n\nDriver will be assigned after payment.`,
      
      bundle_pricing: `💰 *Bundle Pricing Options*\n\n📦 *10-Ride Bundle*\n• 5x Home → HQ + 5x HQ → Home\n• AED 500 (Save 10%)\n• Average AED 50 per ride\n\n🎯 *Monthly Bundle*\n• Unlimited rides for 30 days\n• AED 1,200 (Save 25%)\n• Best for frequent flyers\n\nReply with "10 rides" or "monthly" to purchase.`,
      
      booking_format_error: `❌ *Booking Format Error*\n\nPlease use this format:\n"Pickup from [Location] at [Time]"\n\nExample:\n"Pickup from Marina at 03:30AM"`,
      
      roster_processed: `✅ *Roster Processed!*\n\n${params?.rideCount} rides detected\nBundle price: AED ${params?.totalPrice}\n\nClick to pay: ${params?.paymentLink}\n\nAll rides will be automatically scheduled!`,
      
      crew_help: `🚕 *Crew Cab Commands*\n\n• "Upload roster" - Schedule rides from your roster\n• "Pickup from [location] at [time]" - Manual booking\n• "Bundle pricing" - View bundle options\n• "My rides" - View upcoming rides\n\nNeed help? Reply with "support"`,
      
      driver_help: `🚗 *Driver Commands*\n\n• CrewCab#pickup#RIDEID - Confirm pickup\n• CrewCab#dropoff#RIDEID - Confirm dropoff\n• "Status" - View your stats\n• "Rides" - View assigned rides\n\nNeed help? Reply with "support"`,
      
      welcome_new_user: `👋 *Welcome to Crew Cab!*\n\nPremium airport rides for cabin crew.\n\n✈️ For Crew Members:\nReply with "crew signup" to register\n\n🚗 For Drivers:\nReply with "join driver" to apply\n\n20% cheaper than Careem • Private • Reliable`
    };

    return templates[templateName] || 'Command not recognized. Reply with "help" for available commands.';
  }

  // Mock methods - these would be implemented with actual database and API calls
  private async getCrewMember(phoneNumber: string): Promise<CrewMember | null> {
    // Database lookup
    return null;
  }

  private async getDriver(phoneNumber: string): Promise<Driver | null> {
    // Database lookup
    return null;
  }

  private async getBooking(rideId: string): Promise<Booking | null> {
    // Database lookup
    return null;
  }

  private async saveBooking(booking: Booking): Promise<void> {
    // Database save
  }

  private async sendMessage(phoneNumber: string, message: string): Promise<void> {
    // WhatsApp API call
  }

  private async generatePaymentLink(booking: Booking): Promise<string> {
    // Stripe API call
    return 'https://checkout.stripe.com/...';
  }

  private async generateBundlePaymentLink(rides: any[], price: number): Promise<string> {
    // Stripe API call for bundle
    return 'https://checkout.stripe.com/...';
  }

  private async processRosterWithOCR(imageUrl: string): Promise<any> {
    // OCR processing
    return {};
  }

  private async downloadWhatsAppImage(message: WhatsAppMessage): Promise<string> {
    // Download WhatsApp image
    return '';
  }

  private generateRidesFromRoster(rosterData: any, crew: CrewMember): any[] {
    // Generate rides from roster data
    return [];
  }

  private async addDriverPayout(phoneNumber: string, amount: number): Promise<void> {
    // Add to driver payout queue
  }

  private async startDriverOnboarding(phoneNumber: string): Promise<void> {
    await this.sendMessage(phoneNumber, `🚗 *Driver Onboarding*\n\nWelcome to Crew Cab Driver Network.\n\nPlease reply with:\n1️⃣ Your full name\n2️⃣ A clear photo of your driver's license\n3️⃣ Your car model and plate number\n4️⃣ A profile photo (will be shown to crew)\n5️⃣ Preferred pickup areas (e.g., Marina, Deira)\n\nSend each item in separate messages.`);
  }

  private async sendDriverStatus(driver: Driver): Promise<void> {
    const stats = await this.getDriverStats(driver.phoneNumber);
    await this.sendMessage(driver.phoneNumber, `📊 *Your Stats*\n\n🚗 Total Rides: ${stats.totalRides}\n⭐ Rating: ${stats.rating}\n💰 Pending Payout: AED ${stats.pendingPayout}\n📅 This Month: ${stats.monthlyRides} rides\n\nStatus: ${driver.isApproved ? '✅ Active' : '⏳ Pending Approval'}`);
  }

  private async getDriverStats(phoneNumber: string): Promise<any> {
    // Get driver statistics
    return {
      totalRides: 0,
      rating: 0,
      pendingPayout: 0,
      monthlyRides: 0
    };
  }
}

export default CrewCabWebhookHandler;