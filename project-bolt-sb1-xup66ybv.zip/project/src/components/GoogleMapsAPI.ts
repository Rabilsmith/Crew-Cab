// Google Maps API integration for Crew Cab

interface GeocodeResult {
  formatted_address: string;
  geometry: {
    location: {
      lat: number;
      lng: number;
    };
  };
  address_components: Array<{
    long_name: string;
    short_name: string;
    types: string[];
  }>;
}

interface DistanceMatrixResult {
  distance: {
    text: string;
    value: number;
  };
  duration: {
    text: string;
    value: number;
  };
  duration_in_traffic?: {
    text: string;
    value: number;
  };
  status: string;
}

class GoogleMapsAPI {
  private apiKey: string;
  private baseUrl = 'https://maps.googleapis.com/maps/api';

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  /**
   * Geocode an address to get coordinates
   */
  async geocode(address: string): Promise<GeocodeResult> {
    const url = `${this.baseUrl}/geocode/json`;
    const params = new URLSearchParams({
      address,
      key: this.apiKey,
      region: 'ae', // United Arab Emirates
      components: 'country:AE' // Restrict to UAE
    });

    const response = await fetch(`${url}?${params}`);
    const data = await response.json();

    if (data.status !== 'OK' || !data.results || data.results.length === 0) {
      throw new Error(`Geocoding failed: ${data.status}`);
    }

    return data.results[0];
  }

  /**
   * Get distance matrix between origin and destination
   */
  async getDistanceMatrix(origin: string, destination: string): Promise<DistanceMatrixResult> {
    const url = `${this.baseUrl}/distancematrix/json`;
    const params = new URLSearchParams({
      origins: origin,
      destinations: destination,
      key: this.apiKey,
      units: 'metric',
      mode: 'driving',
      traffic_model: 'best_guess',
      departure_time: 'now'
    });

    const response = await fetch(`${url}?${params}`);
    const data = await response.json();

    if (data.status !== 'OK' || !data.rows || data.rows.length === 0) {
      throw new Error(`Distance matrix failed: ${data.status}`);
    }

    const element = data.rows[0].elements[0];
    if (element.status !== 'OK') {
      throw new Error(`Distance calculation failed: ${element.status}`);
    }

    return element;
  }

  /**
   * Generate checkpoint image for pickup location verification
   */
  async generateCheckpointImage(lat: number, lng: number, zoom: number = 18): Promise<string> {
    const params = new URLSearchParams({
      center: `${lat},${lng}`,
      zoom: zoom.toString(),
      size: '400x400',
      maptype: 'satellite',
      markers: `color:red|${lat},${lng}`,
      key: this.apiKey
    });

    return `${this.baseUrl}/staticmap?${params}`;
  }

  /**
   * Generate Emirates HQ checkpoint with specific pickup points
   */
  async generateEmiratesHQCheckpoint(): Promise<{
    mainEntrance: string;
    crewEntrance: string;
    terminalPickup: string;
  }> {
    const emiratesHQCoords = { lat: 25.2532, lng: 55.3657 };
    
    return {
      mainEntrance: await this.generateCheckpointImage(
        emiratesHQCoords.lat, 
        emiratesHQCoords.lng, 
        19
      ),
      crewEntrance: await this.generateCheckpointImage(
        emiratesHQCoords.lat + 0.001, 
        emiratesHQCoords.lng + 0.001, 
        19
      ),
      terminalPickup: await this.generateCheckpointImage(
        emiratesHQCoords.lat - 0.001, 
        emiratesHQCoords.lng - 0.001, 
        19
      )
    };
  }

  /**
   * Validate pickup location with visual confirmation
   */
  async validatePickupLocation(address: string): Promise<{
    isValid: boolean;
    coordinates: { lat: number; lng: number };
    checkpointImage: string;
    suggestions?: string[];
  }> {
    try {
      const geocodeResult = await this.geocode(address);
      const coords = geocodeResult.geometry.location;
      
      // Generate checkpoint image
      const checkpointImage = await this.generateCheckpointImage(coords.lat, coords.lng);
      
      // Validate if it's in Dubai
      const isDubai = geocodeResult.address_components.some(component => 
        component.types.includes('administrative_area_level_1') && 
        (component.long_name.includes('Dubai') || component.long_name.includes('دبي'))
      );

      return {
        isValid: isDubai,
        coordinates: coords,
        checkpointImage,
        suggestions: isDubai ? undefined : ['Please provide a Dubai address', 'Try: Dubai Marina, Downtown Dubai, etc.']
      };
    } catch (error) {
      return {
        isValid: false,
        coordinates: { lat: 0, lng: 0 },
        checkpointImage: '',
        suggestions: ['Address not found', 'Please provide a more specific location']
      };
    }
  }

  /**
   * Get nearby landmarks for location context
   */
  async getNearbyLandmarks(lat: number, lng: number): Promise<Array<{
    name: string;
    distance: number;
    type: string;
  }>> {
    const url = `${this.baseUrl}/place/nearbysearch/json`;
    const params = new URLSearchParams({
      location: `${lat},${lng}`,
      radius: '500',
      type: 'point_of_interest',
      key: this.apiKey
    });

    const response = await fetch(`${url}?${params}`);
    const data = await response.json();

    if (data.status !== 'OK') {
      return [];
    }

    return data.results.slice(0, 3).map((place: any) => ({
      name: place.name,
      distance: this.calculateDistance(lat, lng, place.geometry.location.lat, place.geometry.location.lng),
      type: place.types[0]
    }));
  }

  /**
   * Calculate distance between two points
   */
  private calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 6371; // Earth's radius in km
    const dLat = this.toRadians(lat2 - lat1);
    const dLng = this.toRadians(lng2 - lng1);
    
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
              Math.sin(dLng / 2) * Math.sin(dLng / 2);
    
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }
}

export { GoogleMapsAPI };