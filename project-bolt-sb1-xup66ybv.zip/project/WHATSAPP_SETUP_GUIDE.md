# 🚀 WhatsApp Business API Setup Guide - IMMEDIATE INTEGRATION

## 🎯 **FASTEST PATH TO LIVE WHATSAPP (5 MINUTES)**

### **Option 1: Meta WhatsApp Business API (FREE - RECOMMENDED)**

#### **Step 1: Get Meta Business Account**
1. Go to [business.facebook.com](https://business.facebook.com)
2. Create/login to Meta Business Account
3. Go to **WhatsApp Business API** section

#### **Step 2: Get Your Credentials**
1. **Phone Number ID**: Found in WhatsApp Business API dashboard
2. **Access Token**: Generate permanent token (not temporary)
3. **Webhook Verify Token**: Create your own (e.g., "crew_cab_verify_123")

#### **Step 3: Configure Environment**
```bash
# Edit crew-cab-backend/.env file with your Meta credentials:
WHATSAPP_PROVIDER=meta
META_ACCESS_TOKEN=your_actual_access_token_here
META_PHONE_NUMBER_ID=your_phone_number_id_here
META_WEBHOOK_VERIFY_TOKEN=crew_cab_verify_123
```

#### **Step 4: Expose Server Publicly**
```bash
# Install ngrok
npm install -g ngrok

# Expose your server
ngrok http 3001

# Copy the HTTPS URL (e.g., https://abc123.ngrok.io)
```

#### **Step 5: Configure Webhook in Meta**
1. In Meta Business dashboard, go to **Webhooks**
2. **Webhook URL**: `https://your-ngrok-url.ngrok.io/api/whatsapp/webhook`
3. **Verify Token**: `crew_cab_verify_123` (same as in .env)
4. **Subscribe to**: `messages`

#### **Step 6: Test Immediately**
```bash
# Test connection
curl http://localhost:3001/api/whatsapp/test-connection

# Send test message to your WhatsApp Business number
# Message: "join driver"
# Expected: Full driver onboarding flow starts
```

---

### **Option 2: Gallabox (FASTEST SETUP - 2 MINUTES)**

#### **Step 1: Sign Up**
1. Go to [gallabox.com](https://gallabox.com)
2. Sign up and verify your WhatsApp Business number

#### **Step 2: Get API Credentials**
1. Go to **Settings → API**
2. Copy **API Key** and **Channel ID**

#### **Step 3: Configure**
```bash
# Edit .env file:
WHATSAPP_PROVIDER=gallabox
GALLABOX_API_KEY=your_api_key_here
GALLABOX_CHANNEL_ID=your_channel_id_here
```

#### **Step 4: Set Webhook**
1. In Gallabox dashboard: **Settings → Webhooks**
2. **URL**: `https://your-ngrok-url.ngrok.io/api/whatsapp/webhook`
3. **Events**: Message Received, Message Status

---

## 🧪 **TESTING CHECKLIST**

### **Immediate Tests (Once Connected):**

1. **Driver Onboarding Flow:**
   ```
   Send: "join driver"
   Expected: 6-step onboarding as specified
   ```

2. **Crew Booking Flow:**
   ```
   Send: "I have a flight tomorrow at 06:10"
   Expected: AI asks for pickup location
   ```

3. **Natural Language:**
   ```
   Send: "Pickup from Marina at 3:30AM"
   Expected: Complete booking flow
   ```

4. **Memory Test:**
   ```
   Send: "Same place as last time"
   Expected: AI remembers previous location
   ```

### **API Test Endpoints:**
```bash
# Test AI directly
curl -X POST http://localhost:3001/api/whatsapp/test-ai \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "+971501234567", "message": "join driver"}'

# Test WhatsApp sending
curl -X POST http://localhost:3001/api/whatsapp/test-message \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "+971501234567", "message": "Test message"}'
```

---

## 🚨 **TROUBLESHOOTING**

### **Common Issues:**

1. **"Webhook verification failed"**
   - Check verify token matches exactly
   - Ensure ngrok URL is HTTPS
   - Verify webhook URL format

2. **"Access token invalid"**
   - Generate new permanent token (not temporary)
   - Check token permissions include messaging

3. **"Messages not sending"**
   - Verify phone number is verified in Meta
   - Check rate limits
   - Ensure proper phone number format

### **Debug Commands:**
```bash
# Check server status
curl http://localhost:3001/health

# Check WhatsApp connection
curl http://localhost:3001/api/whatsapp/test-connection

# View conversation context
curl http://localhost:3001/api/whatsapp/context/+971501234567
```

---

## 🎯 **SUCCESS CRITERIA**

### **✅ WhatsApp Integration Complete When:**
1. Server responds to webhook verification
2. Incoming messages trigger AI responses
3. AI responses are sent back to WhatsApp
4. Driver onboarding flow works end-to-end
5. Crew booking flow works end-to-end
6. Context memory persists across messages

### **📱 Test Number Access:**
Once setup is complete, you'll have:
- Live WhatsApp Business number for testing
- Real-time conversation logs
- Full AI chatbot functionality
- All onboarding flows working

---

## 🚀 **NEXT STEPS AFTER WHATSAPP IS LIVE:**

1. **Validate All Flows** - Test every conversation path
2. **Performance Testing** - Response times, memory usage
3. **Error Handling** - Fallback behaviors
4. **Feature Completion** - Calendar sync, voice messages, etc.
5. **Admin Dashboard** - Connect backend to frontend

**Let's get WhatsApp connected first - everything else builds on this foundation!** 🚗💨