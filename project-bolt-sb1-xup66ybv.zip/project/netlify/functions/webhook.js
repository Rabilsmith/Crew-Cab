const express = require('express');
const serverless = require('serverless-http');

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS headers
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  next();
});

// WhatsApp webhook verification (GET)
app.get('/', (req, res) => {
  console.log('🔍 WhatsApp webhook verification request');
  console.log('Query params:', req.query);
  
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  
  const VERIFY_TOKEN = 'crew_cab_webhook_token_2024';
  
  console.log('Mode:', mode);
  console.log('Token received:', token);
  console.log('Expected token:', VERIFY_TOKEN);
  console.log('Challenge:', challenge);

  if (mode === 'subscribe' && token === VERIFY_TOKEN) {
    console.log('✅ Webhook verified successfully!');
    return res.status(200).send(challenge);
  } else {
    console.log('❌ Webhook verification failed');
    return res.status(403).send('Forbidden');
  }
});

// WhatsApp webhook for incoming messages (POST)
app.post('/', (req, res) => {
  console.log('📱 WhatsApp webhook message received');
  console.log('Body:', JSON.stringify(req.body, null, 2));
  
  const body = req.body;
  
  // Verify this is a WhatsApp Business webhook
  if (body.object === 'whatsapp_business_account') {
    console.log('✅ WhatsApp Business Account webhook confirmed');
    
    // Process each entry
    body.entry?.forEach(entry => {
      console.log('Processing entry:', entry.id);
      
      // Process each change
      entry.changes?.forEach(change => {
        console.log('Processing change:', change.field);
        
        if (change.field === 'messages') {
          const value = change.value;
          console.log('Message value:', value);
          
          // Process messages
          value.messages?.forEach(message => {
            console.log('📨 New message:', message);
            
            const phoneNumber = message.from;
            const messageId = message.id;
            
            // Handle different message types
            if (message.type === 'text') {
              const messageText = message.text.body;
              console.log(`📱 Text from ${phoneNumber}: ${messageText}`);
              
              // Process the message with AI chatbot
              processIncomingMessage(phoneNumber, messageText, messageId);
            } else if (message.type === 'image') {
              console.log(`📸 Image from ${phoneNumber}`);
              // Handle image messages (roster uploads)
            } else if (message.type === 'audio') {
              console.log(`🎤 Audio from ${phoneNumber}`);
              // Handle voice messages
            }
          });
        }
      });
    });
    
    // Always respond with 200 OK
    return res.status(200).send('EVENT_RECEIVED');
  } else {
    console.log('❌ Not a WhatsApp Business Account webhook');
    return res.status(404).send('Not Found');
  }
});

// Process incoming messages
async function processIncomingMessage(phoneNumber, messageText, messageId) {
  console.log(`🤖 Processing message from ${phoneNumber}: ${messageText}`);
  
  try {
    // Simple response logic for testing
    let response = '';
    
    if (messageText.toLowerCase().includes('join driver')) {
      response = `🚗 *Welcome to Crew Cab Driver Network!*\n\nLet's get you started:\n\n1️⃣ What's your full name?\n2️⃣ What car do you drive?\n3️⃣ What's your license plate?\n\nReply with your details to continue.`;
    } else if (messageText.toLowerCase().includes('flight') || messageText.toLowerCase().includes('pickup')) {
      response = `✈️ *Crew Cab Booking*\n\nI can help you book a ride!\n\nWhere should we pick you up from?\n📍 (e.g., Marina, Downtown, Deira)`;
    } else if (messageText.toLowerCase().includes('help')) {
      response = `👋 *Welcome to Crew Cab!*\n\n🚗 For Drivers: Reply "join driver"\n✈️ For Crew: Tell me about your flight\n📋 For Support: Reply "support"\n\nHow can I help you today?`;
    } else {
      response = `👋 Hello! I'm your Crew Cab assistant.\n\n✈️ Need a ride? Tell me about your flight\n🚗 Want to drive? Reply "join driver"\n❓ Need help? Reply "help"`;
    }
    
    console.log(`🤖 Would send response: ${response}`);
    
    // Here you would call the WhatsApp Business API to send the response
    // await sendWhatsAppMessage(phoneNumber, response);
    
  } catch (error) {
    console.error('Error processing message:', error);
  }
}

// Health check
app.get('/health', (req, res) => {
  res.status(200).json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    webhook_ready: true,
    verify_token: 'crew_cab_webhook_token_2024'
  });
});

module.exports.handler = serverless(app);