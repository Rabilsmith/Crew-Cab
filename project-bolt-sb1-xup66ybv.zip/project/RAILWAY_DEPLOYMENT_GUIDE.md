# 🚀 Railway Deployment Guide for Crew Cab Webhook

## **Step 1: Deploy to Railway**

1. **Go to [railway.app](https://railway.app)**
2. **Click "Start a New Project"**
3. **Choose "Deploy from GitHub repo" or "Empty Project"**

## **Step 2: Upload Files**

Upload these files to your Railway project:
- `server.js` (the main webhook server)
- `package.json` (dependencies)
- `.env` (environment variables)

## **Step 3: Set Environment Variables**

In Railway dashboard, go to **Variables** and set:

```
PORT=3001
VERIFY_TOKEN=crew_cab_webhook_token_2024
```

## **Step 4: Deploy**

Railway will automatically:
- Install dependencies (`npm install`)
- Start the server (`npm start`)
- Give you a public HTTPS URL

## **Step 5: Get Your Webhook URL**

Railway will provide a URL like:
```
https://your-project-name.up.railway.app
```

Your webhook endpoints will be:
- **Webhook URL**: `https://your-project-name.up.railway.app/webhook`
- **Health Check**: `https://your-project-name.up.railway.app/health`

## **Step 6: Configure Meta WhatsApp**

Use these exact values in Meta Business Manager:

**Callback URL:**
```
https://your-project-name.up.railway.app/webhook
```

**Verify Token:**
```
crew_cab_webhook_token_2024
```

## **Step 7: Test**

1. Visit `https://your-project-name.up.railway.app/health`
2. Should return: `{"status":"OK","webhook_ready":true}`
3. Then configure in Meta Business Manager

## **Need Help?**

If you get stuck, share:
1. Your Railway project URL
2. Any error messages
3. Screenshots of the Railway dashboard

**This should take 5-10 minutes total!** 🚀